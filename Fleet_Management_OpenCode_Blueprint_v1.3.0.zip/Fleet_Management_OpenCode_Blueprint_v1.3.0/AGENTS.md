# Fleet Management – OpenCode Project Instructions

## Mission
Build a production-grade, self-hostable, company-wide fleet management platform. The repository must remain clean, modular, testable and extensible. Never silently remove or weaken requirements to make implementation easier.

## Read first
Before architecture or implementation work, read in this order:
1. `docs/00_PRODUCT_SCOPE.md`
2. `docs/01_SYSTEM_ARCHITECTURE.md`
3. `docs/02_MODULES_AND_WORKFLOWS.md`
4. `docs/03_DATA_MODEL.md`
5. `docs/05_SECURITY_IDENTITY_PRIVACY.md`
6. `docs/06_DESIGN_UI_UX.md`
7. `docs/10_TESTING_AND_ACCEPTANCE.md`
8. `config/system_config.json`
9. the complete design kit in `design/DeepBlue_Liquid_Glass_Kit.zip`
10. the relevant `.opencode/rules/*` files for the task.

## Non-negotiable architecture
- Modular monolith first; no premature microservices.
- TypeScript backend: NestJS + Fastify; PostgreSQL + Prisma.
- Separate background worker and separate OCR worker.
- React/TypeScript web app; Tauri Windows desktop shell; native Kotlin/Jetpack Compose Android app.
- Keycloak is the identity broker/local IdP. Support local users, OIDC/SAML and LDAP/Active Directory federation.
- PostgreSQL-backed jobs/outbox are preferred so native Windows Server/Linux installs do not require Redis.
- Files use a storage abstraction: local/server filesystem by default, Windows/UNC or Linux-mounted paths where permitted, and S3-compatible storage optional. Storage roots/path templates are centralized configuration, never feature-code constants.
- All public APIs are versioned. Cross-module writes must use public module APIs, commands or domain events, not hidden table access.
- Product plugins never receive direct access to core database tables.

## Configuration
- All non-secret system parameters live in `config/system_config.json` and its schema.
- Secrets are environment variables referenced by the centralized configuration layer only.
- Feature code must never read `process.env` directly.
- Do not hard-code company names, URLs, colors, email addresses, file paths, limits, timeout values, role IDs or feature switches in feature code.


## Administration and settings
- Treat settings as a typed platform subsystem. Read `docs/23_ADMIN_SETTINGS_SYSTEM.md` before implementing any settings screen or configurable feature.
- Resolve settings through the documented precedence: hard deployment policy → deployment config → organization → site → user.
- Every runtime-editable setting needs a registered definition, validation, scope, permissions, effective-source metadata and documentation.
- Settings changes are versioned/audited and use optimistic concurrency. Dangerous changes may require reason + re-authentication; storage/provider changes may require migration rather than direct mutation.
- Never return secret plaintext after save. Clients see redacted/configured state only.
- No feature may create a private ad-hoc settings table or read deployment configuration directly.

## Document Management System
- Treat documents as a central DMS domain, not ad-hoc attachment columns. A document may be generic or linked to multiple entities.
- Persist immutable document versions; replacing a file creates a new version.
- Vehicle papers, workshop invoices, receipts and arbitrary company documents all use the same DMS primitives.
- Authorized downloads return copies only. Support original source, selected version, ZIP bundles and generated registration-certificate PDF copies. Generated registration copies must be clearly marked as copies/non-official.
- Never expose filesystem paths, UNC paths, S3 keys or internal storage identifiers to normal clients. Reject path traversal and validate storage templates. Existing-file relocation uses an explicit journaled checksum-verified migration job.

## Security and privacy
- Deny by default.
- Enforce authorization server-side on every protected operation; UI hiding is not authorization.
- Driver licenses, vehicle documents, invoices, receipts and user data are sensitive documents.
- Use encrypted transport, auditable access, configurable retention, least privilege and secure file handling.
- OCR output is untrusted input and must be validated.
- Driver-license OCR can extract data, but does not prove document authenticity. Preserve `AUTO_VALIDATED`, `REVIEW_REQUIRED`, `VERIFIED`, `REJECTED`, `EXPIRED` style states.
- Re-check driver eligibility at booking save, approval and handover.

## Digital Zulassungsbescheinigung Teil I
- Implement a structured digital representation, not merely an image viewer.
- Field identifiers and explanations follow the current German FZV Anlage 6 model.
- Persist source image, normalized field value, raw OCR value, confidence, bounding box, extraction version, review state and reviewer correction.
- Render front, back and front-only modes with tooltips.
- Always label the rendering clearly as a digital/internal view; never imitate security features or claim that it replaces an official document.

## Design
- `design/DeepBlue_Liquid_Glass_Kit.zip` is a binding design specification.
- Dark-first DeepBlue Liquid Glass: navy surfaces, controlled blur, layered depth, electric-blue accents, large radii, restrained glow, strong hierarchy.
- Reuse shared design tokens and semantic component names across web, desktop and Android.
- No generic dashboard template, random gradients or ad-hoc radii/colors.
- Every UI must work keyboard-first on web/desktop and touch-first on Android; accessibility and reduced-motion states are mandatory.

## Quality
- Prefer generated/shared contracts over duplicated DTO definitions.
- No copy/paste business logic between apps.
- Every feature includes tests appropriate to its risk: unit, integration, contract, E2E and security tests.
- Database invariants belong in the database where possible; e.g. booking overlap protection needs a database-level constraint in addition to service validation.
- Migrations are forward reviewed, backward-aware and tested.
- Avoid `TODO` placeholders in completed phases. If work is genuinely deferred, create a tracked issue and document the dependency.
- Run formatter, lint, type-check and relevant tests before declaring a task done.

## Documentation
- Update docs in the same change as behavior.
- Every setting needs: key, type, default, valid values, scope, restart requirement and security impact.
- Every API change updates OpenAPI/contracts and examples.
- Every product plugin extension point updates the plugin SDK docs.
- Wiki source is version-controlled under `wiki/` and synchronized by CI.

## Git workflow
- Small, coherent commits using Conventional Commits.
- Never rewrite shared history without explicit instruction.
- Never push, publish a release, rotate secrets, alter production or run destructive database operations without explicit approval.
- CI is the source of truth for reproducible builds.

## Definition of done
A feature is done only when implementation, database changes, validation, authorization, audit behavior, tests, docs, configuration, responsive UI states, loading/empty/error states and migration/upgrade effects are covered.


## OpenCode workflow
- Use the built-in **Plan** primary agent before any multi-module or architecture-sensitive change; switch to **Build** only after the plan is accepted.
- Use project skills from `.opencode/skills/` on demand instead of loading large workflows into every prompt.
- Delegate focused reviews to the project subagents in `.opencode/agents/` when useful.
- Use Context7 for version-sensitive framework/library documentation.
- Use Playwright MCP only for browser/E2E work; keep it disabled otherwise to conserve context.
- Prefer local Git/`gh` CLI through bash for normal repository work. Enable GitHub MCP only when its richer API tools are materially useful.
- Before marking a phase complete, run the project review, security, simplification, test and documentation gates defined by the relevant skills/commands.
