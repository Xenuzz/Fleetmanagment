# Fleet Management Platform – OpenCode Blueprint v1.3.0

This package is the complete planning and execution basis for building the Fleet Management platform with **OpenCode**. Product scope remains based on Blueprint v1.2.0; v1.3.0 is the OpenCode-native development-agent edition.

## OpenCode project layer
- `AGENTS.md` – persistent repository instructions
- `opencode.json` – project instructions, permissions, LSP and MCP configuration
- `.opencode/rules/` – mandatory architecture/database/design/security/testing/documentation rules
- `.opencode/agents/` – specialist subagents
- `.opencode/skills/` – on-demand development/review/security/design/release workflows
- `.opencode/commands/` – repeatable project commands
- `project-context/PROJECT_KNOWLEDGE.md` – durable product facts
- `project-context/CUSTOM_KNOWLEDGE.md` – durable working rules

## First start
1. Copy the contents of this folder into the Git repository root.
2. Start OpenCode from that root.
3. Do **not** run `/init`; this package already supplies a curated `AGENTS.md`.
4. Check `opencode mcp list`. Context7 is enabled; Playwright is configured but disabled.
5. In the TUI press Tab until the built-in **Plan** agent is selected.
6. Run `/project-bootstrap`.
7. Review the report before any implementation.

Then follow `prompts/START_HERE.md` and `docs/24_OPENCODE_WORKFLOW.md`.

## Product scope
The platform includes vehicle management, digital German registration certificate, DMS/storage, workshop/parts/service, booking/handover, driver-license OCR and eligibility, trip/work-time, notifications, RBAC/SSO/AD, organizations/sites, full settings framework, product plugin SDK, Web/Windows/Android clients, Docker/Linux/Windows Server deployments, GitHub Actions and complete documentation.

The DeepBlue Liquid Glass kit under `design/` remains the binding visual specification.
