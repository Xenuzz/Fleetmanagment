# Start Here – OpenCode

## Einmalige Projektvorbereitung
1. Neues/leeres GitHub-Repository bzw. lokalen Repository-Ordner verwenden.
2. Den kompletten Inhalt dieses Blueprint-Ordners in den Repository-Root kopieren.
3. Das DeepBlue Design Kit in `design/` unverändert behalten.
4. `AGENTS.md`, `opencode.json`, `.opencode/` und `project-context/` im Repository behalten.
5. OpenCode aus dem Repository-Root starten.
6. **Nicht `/init` ausführen**: eine kuratierte `AGENTS.md` ist bereits vorhanden.
7. `opencode mcp list` prüfen; Context7 soll verbunden sein, Playwright bleibt am Anfang deaktiviert.
8. Im OpenCode-TUI per Tab auf den eingebauten **Plan**-Agent wechseln.
9. `/project-bootstrap` ausführen.
10. Den Bericht prüfen und erst danach die erste Phase freigeben.

## Danach
- Planung: `/phase-plan <phase>`
- Umsetzung: Build-Agent + `feature-dev`/`implement-module` Skill
- Review: `/review-change`
- Abschluss-Gate: `/finish-phase <phase>`

Siehe `docs/13_OPENCODE_TOOLS_MCP_SKILLS.md` und `docs/24_OPENCODE_WORKFLOW.md`.
