# 15 – Risk Analysis, Failure Sources and Optimization

## 1. Highest technical risks

### OCR accuracy

Risk:

- document photos vary greatly
- license/reg certificate field errors can affect eligibility and vehicle data

Mitigation:

- confidence per field
- parser validation
- manual review
- no silent overwrite
- synthetic/redacted fixture suite
- provider abstraction

### Booking race conditions

Risk:

- two users book same vehicle simultaneously

Mitigation:

- service conflict check
- database exclusion constraint
- transaction
- concurrency E2E/integration tests

### Permission leakage

Risk:

- site/organization isolation failures expose personal/license data

Mitigation:

- centralized policy engine
- repository/service scope patterns
- negative tests
- dedicated restricted DTOs
- audit

### Cross-platform drift

Risk:

- Android, web and desktop end with inconsistent capabilities

Mitigation:

- one API/OpenAPI contract
- parity matrix
- shared domain vocabulary
- desktop reuses web code
- phase 14 parity audit

### Native Windows Server complexity

Risk:

- Linux-centric dependencies make Windows deployment fragile

Mitigation:

- PostgreSQL-backed jobs rather than mandatory Redis
- filesystem/S3 abstraction
- Caddy cross-platform
- explicit Windows CI/install smoke testing

### Plugin security

Risk:

- arbitrary third-party code becomes equivalent to core admin access

Mitigation:

- out-of-process model
- scoped capability tokens
- no direct DB access
- explicit grants
- sandboxed UI

## 2. Product risks

### License “automatic verification” expectation

OCR can extract and validate consistency/expiry, but it does not inherently prove authenticity.

Mitigation:

- distinguish auto validation from human verification
- configurable booking acceptance policy
- clear UI state

### LKW legal calculations

Driving/rest-time law can change and may depend on details outside a basic trip log.

Mitigation:

- versioned rule packs
- retain raw activity data
- distinguish time calculation from legal determination
- document rule-pack version in every compliance export

## 3. Performance risks

### Large media/document volume

Mitigation:

- thumbnails
- streaming uploads/downloads
- retention
- S3 option
- async OCR

### Dashboard query explosion

Mitigation:

- dedicated query services
- aggregate queries
- caching only after measurement
- indexes

### Glass UI rendering

Mitigation:

- limit blur layers
- no full-screen nested blur
- profile Android/desktop
- reduced-motion/fallback material

## 4. Operational risks

- backup not tested
- SMTP misconfiguration
- expired identity certificates
- full filesystem
- OCR worker down
- failed migrations

Admin health dashboard and deployment docs must provide visible diagnostics for all of these.

## 5. Optimization priorities

1. correctness/authorization
2. deployment reliability
3. workflow completion
4. client parity
5. query/index performance
6. visual polish
7. advanced analytics

Do not prematurely microservice the system.

