# 13 – OpenCode Tools, MCPs, LSP, Skills and Agents

This project targets **OpenCode**, OpenCode-native. Keep the agent/tool surface intentionally small because local coding models benefit from lower tool-schema/context overhead.

## Required project-native capabilities

### 1. AGENTS.md
`AGENTS.md` is the authoritative repository instruction file and must stay committed. Do not replace it with `/init` output. If `/init` is ever used later, review its proposed changes manually.

### 2. Project instructions
`opencode.json` loads:
- `project-context/PROJECT_KNOWLEDGE.md`
- `project-context/CUSTOM_KNOWLEDGE.md`
- `.opencode/rules/*.md`

### 3. LSP
`lsp: true` is enabled in `opencode.json`. OpenCode can use built-in integrations for TypeScript, Kotlin, Prisma and other languages when their prerequisites exist. Pyright requires its dependency; Rust requires `rust-analyzer`. Do not install separate LSP plugins when OpenCode already provides the integration.

### 4. Context7 MCP – enabled
Use for current, version-specific framework documentation. It is the default external documentation tool for NestJS, Prisma, React, Vite, Tauri, Kotlin/Compose and related libraries.

### 5. Playwright MCP – configured but disabled initially
Enable only during browser/E2E/visual-flow work. It is intentionally off at project bootstrap to save context. The configured local command is `npx -y @playwright/mcp@latest`.

### 6. GitHub
Normal Git and GitHub workflow should initially use local `git` and `gh` CLI through OpenCode's bash tool. This is more token-efficient than exposing a large GitHub MCP catalog.

Optional: enable GitHub's official MCP only when issue/PR/workflow API tooling materially improves the task. Keep write operations approval-gated.

### 7. Built-in OpenCode tools
Use `read`, `glob`, `grep`, `bash`, `websearch`, `webfetch`, `lsp`, `skill` and subagents as appropriate. Do not install filesystem/git/web MCP duplicates for capabilities OpenCode already provides.

## Project skills
The repository includes on-demand skills:
- `feature-dev`
- `implement-module`
- `code-review`
- `code-simplify`
- `security-review`
- `design-qa`
- `docs-sync`
- `release-check`

Skills are preferred over always-on workflow plugins because they load only when needed.

## Project subagents
- `backend-architect`
- `database-reviewer`
- `security-reviewer`
- `android-engineer`
- `design-reviewer`
- `docs-writer`

Review agents are read-only or approval-gated where practical.

## Optional MCPs later
- Official GitHub MCP: issues/PRs/actions/releases when `gh` CLI is insufficient.
- Grep by Vercel (`https://mcp.grep.app`): external GitHub code examples when Context7 documentation is insufficient.
- Sentry MCP only if Sentry is actually adopted.

## Do not install at bootstrap
Do not add random community OpenCode plugins, filesystem MCP, generic Git MCP, database MCP with production credentials, Supabase/Vercel/Firebase tooling, or broad autonomous-loop plugins. Add a tool only for a concrete project phase and review its permissions/network/credentials first.

## Security rule
Any npm OpenCode plugin or MCP server is developer software with code/tool execution capability. Review source, permissions, environment variables, endpoints and data exposure before enabling it.
