# 22 – Vehicle and General Document Management System (DMS)

## 1. Purpose

The platform includes a first-class document management system, not only attachment fields. It must store, classify, search, preview, version, link, download and audit documents throughout the fleet platform.

Documents may be linked to one or more business entities or may exist as completely general company documents with no vehicle relation.

Examples include:

- vehicle registration certificates and other vehicle papers
- insurance documents
- inspection/TÜV/AU reports
- leasing, purchase and sale contracts
- workshop invoices, quotations, repair reports and external workshop documents
- parts invoices and delivery notes
- fuel receipts
- accident/damage documents
- photos and evidence files
- manuals, certificates, correspondence, policies, forms and arbitrary company documents
- user-created custom document categories

## 2. DMS model

The DMS is entity-agnostic. A document can be linked to zero, one or many entities such as vehicle, workshop order, invoice, damage, booking, driver, site, organization, supplier, part, service event or trip.

Required concepts:

- `DocumentRecord`: logical document metadata
- `DocumentVersion`: immutable file version
- `DocumentLink`: typed many-to-many business-entity link
- `DocumentCategory`: configurable category/tree entry
- `DocumentTag`: searchable labels
- `DocumentReminder`: optional validity/renewal reminder
- `FileObject`: physical object in storage
- optional OCR extraction and indexed full text

A logical document may have multiple versions. Replacing a file must not destroy the previous version. Users with permission can inspect version history and restore a previous version as a new current version.

## 3. Metadata

Every document supports at minimum:

- organization and optional site
- title
- description
- category
- document type
- tags
- original filename
- current version
- issue/document date
- valid-from and valid-until dates
- optional issuer/vendor/counterparty
- optional document/reference/invoice number
- confidentiality level
- retention policy
- OCR/indexing state
- created/updated by and timestamps
- linked entities
- custom metadata fields

Custom categories and metadata fields are configurable without schema changes.

## 4. Virtual folders and categories

Users work with a virtual DMS structure. Virtual folders/categories are not required to match physical storage paths.

Support:

- global organization document root
- per-site views
- per-vehicle document view
- workshop/invoice/receipt views
- custom category trees
- favorites/recent documents
- saved filters
- full-text and metadata search

Permissions can be assigned to document categories in addition to normal entity permissions.

## 5. Vehicle document center

Each vehicle has a dedicated document center showing all linked documents, grouped at least into:

- registration/papers
- inspection
- insurance
- ownership/leasing
- workshop and repair
- invoices/costs
- damage/accident
- manuals/certificates
- other/custom

The same document must not be duplicated when it is also visible in a workshop order or invoice. Use links to one logical DMS record.

## 6. Digital registration certificate downloads

For a German Zulassungsbescheinigung Teil I, authorized users can download copies in several forms:

1. original uploaded front image/PDF
2. original uploaded rear image/PDF
3. combined source copy as PDF containing all uploaded sides/pages
4. generated structured digital copy as PDF
5. optional complete vehicle-paper bundle as ZIP/PDF package

The generated structured copy must be clearly marked, for example:

`KOPIE / DIGITALE INTERNE ANSICHT – KEIN AMTLICHES ORIGINAL`

It must never imitate security features or imply legal equivalence to the physical document.

Downloads always return a copy. Downloading never moves, renames or mutates the stored master document.

## 7. Generic document downloads and exports

Authorized users can:

- preview a document
- download the original file
- download a selected historical version
- download a generated PDF copy when a renderer exists
- download multiple selected documents as a ZIP bundle
- export a document index as CSV/XLSX/PDF where appropriate

Use safe `Content-Disposition` filenames. Physical `storage_key` values and server paths are never exposed to clients.

Every sensitive preview/download is authorization checked and auditable.

## 8. Storage providers and configurable paths

Storage is accessed exclusively through a storage abstraction.

Supported baseline providers:

- local/server filesystem
- Windows local paths
- Windows UNC/network shares when the service account has access
- Linux mounted filesystems/NFS/SMB mounts through normal filesystem paths
- S3-compatible object storage

The administration UI must expose storage settings permitted by deployment policy, including:

- active storage provider
- filesystem base/root path
- temporary-processing path
- generated-export path
- archive path
- optional quarantine path
- S3 endpoint/bucket/region/prefix
- per-document-category logical path templates
- storage health test
- free-space/capacity information when available
- migration/copy job between storage profiles

Physical file placement uses validated templates rather than raw user-supplied paths. Example template:

`{organizationId}/{category}/{yyyy}/{entityType}/{entityId}`

Recommended category mappings:

- `vehicle_documents`
- `registration_certificates`
- `workshop_documents`
- `invoices`
- `fuel_receipts`
- `driver_licenses`
- `general_documents`
- `generated_exports`

Path-template rules:

- prevent `..` traversal and forbidden path characters
- normalize separators per platform
- never use untrusted original filenames as storage paths
- generate random/opaque physical object names
- do not expose absolute/UNC/S3 storage paths through APIs
- validate that filesystem destinations remain inside an approved storage root or approved share
- require an explicit migration job when changing provider/root for existing objects

Machine/deployment-level roots are configured in `config/system_config.json`; runtime-editable organization/category behavior is stored as validated settings only where allowed by the deployment policy.

## 9. File lifecycle and integrity

For every uploaded file:

- MIME and magic-byte validation
- configurable size limit
- SHA-256 checksum
- duplicate detection hints
- malware scan when enabled
- immutable physical file object once accepted
- version record rather than destructive replacement
- optional OCR/full-text extraction
- retention/legal-hold support
- soft-delete/trash state before physical purge when policy allows
- scheduled purge with audit trail

## 10. Permissions

Suggested permission keys:

- `documents.read`
- `documents.upload`
- `documents.update_metadata`
- `documents.version.create`
- `documents.version.read`
- `documents.download`
- `documents.download_sensitive`
- `documents.delete`
- `documents.restore`
- `documents.category.manage`
- `documents.retention.manage`
- `documents.storage.configure`
- `vehicle_documents.read`
- `vehicle_documents.download`
- `registration_certificate.download_copy`

Confidential categories such as driver licenses can require separate permissions even when the user can read the related driver or vehicle.

## 11. API requirements

Provide versioned endpoints for at least:

- document list/search/filter
- create/upload
- metadata update
- create/read version
- link/unlink entities
- category management
- preview
- download original/current/specific version
- multi-document ZIP bundle
- registration-certificate combined/source/generated copy
- retention/legal-hold operations
- storage health and migration jobs for admins

Downloads should use short-lived authorized streams or signed URLs where supported. Signed URLs must be short lived and permission checked before issuance.

## 12. Client requirements

Web, Windows and Android must provide the same DMS semantics.

Android specifically supports:

- camera capture
- multi-page upload
- file picker/share-to-app import where platform APIs allow
- offline upload queue for assigned operational workflows
- document preview
- download/save/share of authorized copies through Android system APIs
- background upload with retry
- visible sync state

## 13. Search and indexing

Support metadata search from the start and design for OCR/full-text indexing. Search filters include vehicle, site, category, document type, date range, validity, vendor, tags, uploader and linked entity.

A future search-engine provider may be plugged in, but PostgreSQL-backed metadata/full-text search should be sufficient for the initial deployment.

## 14. Backup and migration

Backup documentation must state that database and file storage form one consistency domain. A database backup without the corresponding file objects is incomplete.

Storage-provider/root changes use resumable migration jobs with:

- copy
- checksum verification
- progress
- retry
- failure report
- final cutover
- optional source retention period

Never silently rewrite all `storage_key` values without a migration journal.

## 15. Acceptance criteria

The DMS is complete only when tests prove:

- a general document can exist without a vehicle
- one document can be linked to several entities without duplicate file storage
- vehicle document center shows linked workshop invoices and arbitrary vehicle documents
- document versions are immutable and recoverable
- unauthorized users cannot preview or download sensitive documents
- storage paths are not leaked through APIs
- path traversal is rejected
- registration source and generated copies download successfully and remain clearly marked as copies
- changing storage root/provider requires a controlled migration path
- Android can upload, preview and download authorized documents
- audit records exist for sensitive document access and storage administration

## Settings integration

DMS/storage administration is surfaced through the central Settings subsystem. See `docs/23_ADMIN_SETTINGS_SYSTEM.md`. Storage provider/root changes that affect existing objects remain migration operations and cannot be applied as ordinary settings writes.
