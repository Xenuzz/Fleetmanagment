# 01 – System Architecture

## 1. Architecture style

Use a **modular monolith first** with strict domain boundaries and asynchronous jobs. Do not start with microservices.

Reasoning:

- the business domains are numerous but heavily transactional
- booking, workshop, service and vehicle status require consistent writes
- one deployment must run comfortably on a normal company server
- native Windows Server deployment becomes substantially easier
- a modular monolith can still expose independent module contracts and later split selected modules

The OCR worker is the primary exception because its runtime and dependencies are better isolated.

## 2. Recommended monorepo layout

```text
fleet-management-platform/
├─ apps/
│  ├─ api/                    # NestJS HTTP/WebSocket application
│  ├─ worker/                 # pg-boss job consumers, scheduled tasks, notifications
│  ├─ web/                    # React browser app
│  ├─ desktop/                # Tauri shell reusing web packages
│  ├─ android/                # Native Kotlin/Compose app
│  └─ ocr-worker/             # Python FastAPI worker/provider adapter
├─ packages/
│  ├─ api-contracts/          # OpenAPI-derived TS types + shared API conventions
│  ├─ domain-types/           # enums/value-object types with no runtime business logic
│  ├─ design-tokens/          # generated DeepBlue tokens for web/desktop
│  ├─ config-schema/          # JSON schema and loaders for system_config.json
│  ├─ event-contracts/        # integration event schemas
│  ├─ plugin-sdk/             # fleet product plugin SDK
│  ├─ reporting/              # report models/templates shared by server jobs
│  └─ test-utils/
├─ prisma/
│  ├─ schema.prisma
│  ├─ migrations/
│  ├─ seed/
│  └─ extensions/
├─ config/
│  ├─ system_config.json
│  └─ system_config.schema.json
├─ design/
│  └─ DeepBlue_Liquid_Glass_Kit/
├─ docs/
│  ├─ architecture/
│  ├─ modules/
│  ├─ api/
│  ├─ deployment/
│  ├─ security/
│  ├─ plugin-sdk/
│  └─ wiki/
├─ deploy/
│  ├─ docker/
│  ├─ linux/
│  ├─ windows-server/
│  ├─ caddy/
│  └─ keycloak/
├─ scripts/
├─ .opencode/
├─ .github/
├─ AGENTS.md
├─ package.json
├─ pnpm-workspace.yaml
└─ README.md
```

## 3. Backend stack

### 3.1 API runtime

- Node.js current LTS at initialization, version pinned in repo toolchain config
- TypeScript strict mode
- NestJS
- Fastify adapter
- Zod or generated OpenAPI validation at boundaries
- Prisma ORM
- PostgreSQL

### 3.2 Background jobs

Use `pg-boss` rather than Redis/BullMQ.

Jobs:

- reminder calculation
- email delivery
- push delivery
- report generation
- OCR submission/retry
- invoice/fuel parsing
- document thumbnail generation
- service recalculation
- plugin async events
- cleanup/retention
- backup metadata tasks

Benefits:

- PostgreSQL is already required
- one fewer stateful dependency
- works on Linux, Windows Server and Docker
- transactional job enqueue can be tied to domain state

### 3.3 Event architecture

Inside the monolith:

- domain events are in-process after transaction completion
- integration events are written to a transactional outbox table
- worker dispatches integration events
- PostgreSQL LISTEN/NOTIFY can wake processes, but the outbox remains the durable source

This prevents lost notifications when a process crashes after committing business data.

## 4. Database

### 4.1 PostgreSQL extensions

Recommended:

- `pg_trgm` for fuzzy search
- `citext` where case-insensitive uniqueness is needed
- optional `pgcrypto` for selected database-side functions

### 4.2 Prisma usage rules

- Prisma for normal CRUD and migrations
- raw SQL migration files are permitted for PostgreSQL features Prisma cannot express, e.g. exclusion constraints
- no ad-hoc SQL in controllers
- raw SQL must live in repository/data-access layer and be covered by integration tests

### 4.3 Booking overlap protection

Approved/reserved/active bookings must be protected by a database-level conflict rule where feasible.

Use a PostgreSQL exclusion constraint over a `tstzrange` or equivalent derived booking range for blocking states.

The service still performs a friendly conflict query first, but the database constraint is the final race-condition guard.

## 5. Identity and SSO

Use **Keycloak** as the default bundled identity platform.

Keycloak provides:

- local users
- password policy
- MFA support
- OIDC for the applications
- SAML identity brokering
- LDAP/Active Directory federation
- external OIDC providers such as Microsoft Entra ID

The fleet application stores an application user profile linked by OIDC subject (`sub`). It must not maintain a second password database.

### 5.1 Authentication flow

Web/Desktop:

- Authorization Code + PKCE
- browser/system browser login as appropriate
- short-lived access token
- refresh according to provider configuration

Android:

- Authorization Code + PKCE via AppAuth-compatible flow
- no embedded password form for SSO

### 5.2 Authorization

Authorization is application-owned and uses granular permissions. Identity provider realm roles can optionally map to application roles, but the application permission matrix is canonical.

## 6. File/document storage

Implement `StorageProvider` interface:

- `filesystem`
- `s3`

Default self-hosted install:

- filesystem driver on a dedicated data directory

High availability:

- S3-compatible object store or cloud S3

Metadata always lives in PostgreSQL:

- object ID
- checksum
- MIME type
- size
- original filename
- object category
- tenant/site linkage
- creator
- created timestamp
- encryption metadata where applicable

No feature module writes directly to filesystem paths.

The document layer is a first-class DMS. Logical documents and immutable versions are stored separately from physical `FileObject`s so one file/document can be linked to multiple business entities without duplication. General company documents may have no entity link. See `docs/22_DOCUMENT_MANAGEMENT_SYSTEM.md`.

Filesystem deployments support local/server paths, Linux-mounted network filesystems and Windows UNC/network shares when the service account has access. Provider roots, temp/export/archive/quarantine paths and category path templates are centralized validated configuration. Changing provider/root for existing objects is a resumable checksum-verified migration operation, never an ad-hoc path rewrite.

## 7. OCR architecture

Use an `OcrProvider` abstraction.

Preferred local provider:

- Python FastAPI worker
- PaddleOCR
- OpenCV preprocessing

Fallback:

- Tesseract

Optional provider plugins can integrate external services without changing core business logic.

OCR pipeline:

1. upload and validate file
2. store immutable original
3. normalize image
4. detect document type and side
5. run OCR
6. parse document-specific fields
7. assign confidence per field
8. validation rules
9. create review task when needed
10. map accepted values to domain entities
11. retain original extraction JSON for audit

## 8. Web application

Recommended stack:

- React
- TypeScript
- Vite
- React Router
- TanStack Query
- TanStack Table
- Zod for client-side form schemas where useful
- accessible headless primitives such as Radix UI where appropriate
- Apache ECharts for dense fleet analytics

State rules:

- server state: TanStack Query
- form state: local/form library
- app UI state: minimal Zustand or React context
- do not mirror server entities into a second global store

## 9. Windows desktop

Use Tauri.

The desktop app reuses the web UI packages and API client, while Tauri adds:

- native window
- OS notification integration
- secure local token/session storage where appropriate
- file open/save dialogs
- deep-link support
- auto-update support when configured
- optional background tray behavior

Do not fork a separate Windows UI codebase.

## 10. Android

Use native Kotlin + Jetpack Compose.

Recommended components:

- Material 3 semantics with custom DeepBlue theme
- Navigation Compose
- Hilt
- Room
- DataStore
- WorkManager
- OkHttp/Retrofit or generated OpenAPI-compatible client
- CameraX
- Coil
- encrypted local secrets through Android Keystore

### 10.1 Offline strategy

Android must be offline-capable for field workflows, not a full offline replica of the entire company database.

Offline-capable operations:

- view recently assigned bookings
- view assigned workshop orders
- vehicle handover draft
- vehicle return draft
- mileage/fuel/charge entry
- trip draft
- receipt/photo capture
- checklist completion

Writes are stored in an outbox with idempotency keys and synchronized by WorkManager.

Conflicts are resolved server-side; the app must surface a clear conflict state instead of silently overwriting server data.

## 11. Real-time updates

Use WebSocket for live application state where useful:

- notifications
- booking status changes
- workshop assignment/status
- vehicle status changes
- OCR review completion

Provide polling fallback.

Push notifications are not a substitute for source-of-truth API state.

## 12. Notifications

Define `NotificationChannelProvider`:

- in-app
- SMTP email
- FCM Android
- Windows desktop
- webhook/plugin

ICS calendar files are generated directly by the platform for approved bookings and cancellations.

Optional Microsoft Graph/Google integrations can be plugins later.

## 13. Reporting

Server-side report jobs produce:

- PDF
- XLSX
- CSV where appropriate

Recommended:

- `pdfmake` or another deterministic server PDF library
- `exceljs`

Report generation is asynchronous for large datasets.

Every generated report has:

- request owner
- permission snapshot/context
- creation time
- filter metadata
- expiry/retention date
- checksum

## 14. Search

Avoid Elasticsearch initially.

Use PostgreSQL:

- full text
- trigram
- indexed normalized columns
- typed filters

Global search can cover:

- vehicles
- users/drivers subject to permission
- bookings
- workshop orders
- parts
- invoices
- trips

## 15. Observability

Core:

- structured JSON logs
- correlation IDs
- request latency
- job metrics
- health endpoints
- audit events separated from application logs

Optional:

- OpenTelemetry
- Sentry self-hosted/cloud
- Prometheus/Grafana through deployment profile

## 16. Configuration and settings model

`config/system_config.json` is the single non-secret deployment configuration source. Runtime-editable business/UI settings are managed by the central Settings subsystem described in `docs/23_ADMIN_SETTINGS_SYSTEM.md`; feature modules must not create parallel configuration mechanisms.

Settings resolution is explicit and typed: hard policy → deployment → organization → site → user. The runtime resolver returns value, source, scope, schema metadata and change-safety flags. Settings writes use optimistic concurrency and immutable audit/revision records.

`config/system_config.json` remains authoritative for deployment-managed values.

Secrets remain environment variables:

- database password/URL
- Keycloak client secrets where required
- SMTP password
- FCM credentials
- S3 credentials
- encryption keys

Feature code must never read arbitrary environment variables directly. Only the central configuration bootstrap layer may resolve secrets and merge them into a validated runtime config object.

