# 08 – GitHub Repository and CI/CD

## 1. Branching

Recommended:

- `main` protected
- short-lived feature branches
- pull requests required
- semantic version tags `vX.Y.Z`

Avoid a permanent develop branch unless the team has a concrete release process that needs it.

## 2. Repository files

Required:

- `README.md`
- `LICENSE` chosen by owner before public release
- `SECURITY.md`
- `CONTRIBUTING.md`
- `CODE_OF_CONDUCT.md` if public/team policy requires
- `CHANGELOG.md`
- `.editorconfig`
- `.gitattributes`
- `.gitignore`
- PR template
- bug/feature issue templates
- Dependabot/Renovate configuration

## 3. Workflows

### `ci-backend.yml`

- install locked dependencies
- lint
- typecheck
- unit tests
- integration tests with PostgreSQL service
- Prisma schema validation
- migration test from clean DB
- OpenAPI generation diff check

### `ci-web.yml`

- lint
- typecheck
- unit/component tests
- build
- accessibility checks where automatable

### `ci-e2e.yml`

- start test stack
- Playwright E2E
- screenshot regression for selected design-critical screens
- permission matrix scenarios

### `ci-android.yml`

- Gradle validation
- ktlint/detekt
- unit tests
- Compose tests where practical
- assembleDebug
- upload APK artifact

### `ci-desktop.yml`

Runs on Windows runner:

- web build
- Rust check
- Tauri build
- installer smoke validation
- upload installer artifact

### `ci-security.yml`

- CodeQL
- dependency review
- Semgrep
- secret scan
- container scan when images exist
- SBOM generation

### `release.yml`

Triggered by signed/approved tag:

- all CI gates
- build server archives
- build Docker images
- build Windows desktop
- build Android
- generate checksums
- generate SBOM
- GitHub Release creation
- attach artifacts
- publish container images to GHCR

### `wiki-sync.yml`

Source of truth:

`docs/wiki/`

Workflow mirrors Markdown pages to the GitHub Wiki repository after main changes.

Because the Wiki is a separate Git repository, use a dedicated minimally-scoped deployment credential if `GITHUB_TOKEN` cannot satisfy the organization policy.

## 4. Required status checks

At minimum before merging to `main`:

- backend
- web
- E2E core smoke
- security fast scan
- Android compile

Before release:

- full backend integration
- full E2E
- Android tests/build
- desktop build
- Docker build
- security scans
- migration upgrade test

## 5. Release artifacts

GitHub Release should contain:

- server Linux archive
- server Windows archive/installer scripts
- Windows desktop installer
- Android APK
- optional Android AAB
- `docker-compose.yml` release bundle
- sample production config
- SHA256SUMS
- SBOM
- changelog/release notes

## 6. GitHub Actions Android expectation

The repository must make it possible to download an APK from every successful Android CI run and a signed APK/AAB from release runs when signing secrets are configured.

## 7. Documentation gate

Any PR that changes:

- public API
- configuration
- permissions
- plugin SDK
- deployment
- user-visible workflow

must update the relevant docs/Wiki page in the same PR.

