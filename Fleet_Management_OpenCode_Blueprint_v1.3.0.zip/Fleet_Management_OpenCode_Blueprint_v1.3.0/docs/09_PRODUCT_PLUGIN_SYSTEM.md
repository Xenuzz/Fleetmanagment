# 09 – Fleet Platform Plugin System

This document describes plugins for the fleet product itself, not OpenCode development tools.

## 1. Goals

- extend the platform without patching core code
- allow company-specific integrations
- keep core upgrades possible
- keep plugin permissions explicit
- prevent third-party code from receiving unrestricted DB access

## 2. Plugin package

Recommended package format: ZIP for manual installation and OCI/container reference for advanced deployments.

Manifest example:

```json
{
  "id": "com.example.telematics",
  "name": "Example Telematics",
  "version": "1.2.0",
  "apiVersion": "1",
  "publisher": "Example GmbH",
  "description": "Imports odometer and GPS metadata.",
  "entrypoint": {
    "type": "http",
    "health": "/health"
  },
  "capabilities": [
    "vehicles.read",
    "odometer.write",
    "events.subscribe:fleet.vehicle.updated.v1"
  ],
  "events": [
    "fleet.vehicle.created.v1"
  ],
  "settingsSchema": "settings.schema.json",
  "ui": {
    "slots": ["vehicle.detail.integration-card"]
  }
}
```

## 3. Lifecycle

States:

- UPLOADED
- VALIDATED
- INSTALLED
- ENABLED
- DISABLED
- ERROR
- UPDATE_AVAILABLE
- INCOMPATIBLE
- REMOVED

Lifecycle actions:

- validate package signature/checksum
- validate manifest
- compare API compatibility
- display requested capabilities
- admin grants permissions
- install isolated plugin data
- health check
- enable

## 4. Execution isolation

Preferred:

- plugin as separate process/container or remote HTTPS endpoint
- mutually authenticated/scoped token
- network allowlist configuration where needed

No in-process arbitrary JS module loading for third-party plugins in initial implementation.

## 5. Plugin API

Plugin token claims include:

- plugin installation ID
- organization
- capabilities
- expiry

Plugin API paths:

`/api/v1/plugin-runtime/...`

Examples:

- read vehicle summary
- create odometer observation
- post integration status
- create custom notification
- attach metadata

## 6. Event delivery

- event outbox
- at-least-once delivery
- event ID
- retry
- exponential backoff
- dead-letter state
- plugin must handle idempotency

## 7. Plugin data

Options:

1. core-managed key/value/JSON plugin store for simple plugins
2. dedicated PostgreSQL schema `plugin_<safe_slug>` managed through plugin migration service

Plugins never get credentials to the core application schema.

## 8. UI extensions

Safe initial strategy:

- declarative extension cards/actions where possible
- iframe sandbox for rich external UI
- explicit CSP
- short-lived scoped token from host to iframe
- no arbitrary direct React module federation for untrusted third-party code initially

UI slots:

- dashboard.widget
- vehicle.detail.integration-card
- workshop.order.sidebar
- booking.detail.action
- settings.integration

## 9. Plugin SDK

Repository package `packages/plugin-sdk` should provide:

- TypeScript types
- manifest schema
- event schemas
- API client
- signing/checksum helpers
- local development harness
- example plugin
- integration tests

## 10. Plugin developer documentation

Wiki must include:

- first plugin tutorial
- manifest reference
- permissions reference
- event catalogue
- API reference
- UI slots
- settings schema
- testing
- packaging
- signing
- publishing
- version compatibility
- migration rules
- security checklist

