# 20 – External Source Notes

These external sources are implementation references, not vendored specifications. Re-check them during implementation because software documentation and law can change.

## OpenCode
- Instructions / AGENTS.md: https://opencode.ai/docs/rules/
- Configuration: https://opencode.ai/docs/config/
- Agents: https://opencode.ai/docs/agents/
- Skills: https://opencode.ai/docs/skills/
- MCP servers: https://opencode.ai/docs/mcp-servers/
- LSP: https://opencode.ai/docs/lsp/
- Permissions: https://opencode.ai/docs/permissions/
- Commands: https://opencode.ai/docs/commands/


## German vehicle registration
- FZV Anlage 6 – Zulassungsbescheinigung Teil I: https://www.gesetze-im-internet.de/fzv_2023/anlage_6.html

## Source discipline
- Pin dependencies, but re-check security advisories and current versions during implementation.
- Legal/regulated features (driver hours, retention, license verification) require explicit rule-pack/version documentation and legal validation before being represented as compliance decisions.

- Administration/settings internal specification: `docs/23_ADMIN_SETTINGS_SYSTEM.md`
