# 16 – German Digital Zulassungsbescheinigung Teil I

## 1. Authoritative implementation source

The parser/template must be based on the current German FZV Anlage 6 (Zulassungsbescheinigung Teil I) and versioned in code.

Official source:

https://www.gesetze-im-internet.de/fzv_2023/anlage_6.html

## 2. Digital rendering rule

The product should provide a visually familiar structured digital representation, but it must not be presented as an official replacement document.

Display a persistent label such as:

`Digitale Ansicht – kein amtliches Originaldokument`

Do not attempt to reproduce anti-counterfeit security features.

## 3. Field catalogue

The template metadata must support at least the visible field identifiers present in the current form, including:

- A
- B
- C.1.1
- C.1.2
- C.1.3
- C.4c
- D.1
- D.2
- D.3
- E
- F.1
- F.2
- G
- H where applicable
- I
- J
- K
- L
- O.1
- O.2
- P.1
- P.2/P.4
- P.3
- Q
- R
- S.1
- S.2
- T
- U.1
- U.2
- U.3
- V.7
- V.9
- X
- 2
- 2.1
- 2.2
- 3
- 4
- 5
- 6
- 7.1
- 7.2
- 7.3
- 8.1
- 8.2
- 8.3
- 9
- 10
- 11
- 12
- 13
- 14
- 14.1
- 15.1
- 15.2
- 15.3
- 16
- 17
- 18
- 19
- 20
- 21
- 22

The actual parser must verify this list against the current official form at implementation time.

## 4. Template metadata structure

Store document metadata in a versioned file such as:

`packages/domain-types/document-templates/de/zb1/2023-07.json`

Each field record:

- key
- official_name
- short_description
- data_type
- unit optional
- side
- normalized_vehicle_target optional
- tooltip text
- sensitive flag
- OCR aliases/regex
- validation rule key

Screen coordinates should be a separate render-layout file so parser semantics are not tied to pixels.

## 5. Security-code handling

The platform should not require users to expose scratch-off/hidden security codes and should not normalize such codes into the normal vehicle profile.

If an uploaded original incidentally contains an exposed code, access to the original remains protected under document permissions and OCR parser rules should avoid promoting the code as a business field.

