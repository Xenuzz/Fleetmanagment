# 23 – Administration and Settings System

## 1. Purpose

The settings area is a first-class platform subsystem, not a collection of hard-coded forms. It must provide a consistent, auditable and permission-aware way to configure the whole product across Web, Windows desktop and Android.

The system distinguishes between:

1. **Deployment configuration** – machine/service-level values from `config/system_config.json`; usually changed by a system administrator and may require restart or migration.
2. **Organization settings** – company-wide business/UI settings stored in the application database where runtime editing is allowed.
3. **Site settings** – location-specific overrides for keys explicitly marked site-overridable.
4. **User preferences** – personal UI/notification preferences for keys explicitly marked user-overridable.
5. **Plugin settings** – namespaced settings registered by installed product plugins.

No feature module may invent its own hidden setting store.

## 2. Effective-value precedence

For every setting key the effective value is resolved in this order, highest priority first:

1. hard security/deployment policy that cannot be overridden
2. deployment value from `config/system_config.json`
3. organization override when permitted
4. site override when permitted
5. user preference when permitted
6. plugin-specific scoped override when applicable and explicitly permitted by the plugin contract

The Settings UI must always be able to show:

- effective value
- inherited/default value
- source of the effective value
- allowed scopes
- whether the current user may edit it
- whether restart is required
- whether a storage/data migration is required
- security/privacy impact classification
- last editor and last change timestamp where applicable
- validation state

## 3. Settings registry

Every setting is registered through a typed `SettingDefinition`; screens are rendered from the registry plus dedicated rich editors for complex settings.

Each definition contains at minimum:

- stable key, e.g. `bookings.approvalRequired`
- category and subcategory
- display label and help text
- data type
- default value
- allowed scopes
- constraints and enum values
- permission required to read/edit
- secret/redaction classification
- restart requirement
- migration requirement
- dangerous-change flag
- audit sensitivity
- availability by platform/deployment mode
- optional feature dependency
- optional validation/test handler
- documentation anchor

Supported types include:

- boolean
- integer/decimal
- string
- enum
- multi-select
- duration
- date/time/timezone
- color/design token
- asset reference
- path/path-template
- URL/host/port
- structured JSON with schema
- template text
- secret reference (never the secret value itself)

## 4. Settings navigation

The Admin Settings shell uses a searchable left navigation on web/desktop and adaptive list/detail navigation on Android/tablet.

Mandatory top-level groups:

### 4.1 Overview

- configuration health summary
- unsaved/pending changes
- settings requiring restart
- pending storage migrations
- failed diagnostics
- identity/SMTP/OCR/storage health
- recent settings changes
- effective scope selector: system / organization / site
- direct links to high-impact sections

### 4.2 Organization

- organization display name
- legal company name
- company/contact metadata
- default locale
- default timezone
- default currency
- first day of week
- default units where configurable
- main site
- company-level contact information
- feature/business defaults that are organization-scoped

### 4.3 Sites / locations

- create/edit/deactivate site
- code/name
- postal address
- contacts
- timezone override
- site-specific branding override where allowed
- site-specific booking/workshop/document defaults where allowed
- assigned users/roles
- assigned vehicles
- inherited-vs-overridden setting indicator
- reset override to organization value

Deleting a site with dependencies is prohibited; use deactivation or an explicit migration/reassignment flow.

### 4.4 Branding & appearance

- company logo
- dark/light logo variants where needed
- app/report/email logo usage
- company name
- accent/primary color within design-system constraints
- DeepBlue Liquid Glass theme options exposed by design tokens only
- dark mode default
- login branding
- favicon/app-icon source assets where deployment pipeline supports generation
- report header/footer branding
- email header/footer branding
- live preview for web/desktop/mobile surfaces

The DeepBlue Liquid Glass design kit remains the baseline. Runtime branding may alter approved semantic tokens, not bypass the component system.

### 4.5 Users, onboarding and identity

- local account enablement policy
- first-login wizard enablement
- mandatory profile fields
- license-upload requirement
- account activation/deactivation policy
- MFA policy for administrators
- session idle/absolute timeout display and managed state
- OIDC provider definitions
- SAML provider definitions
- LDAP/Active Directory federation settings
- domain/group-to-role mapping
- identity sync options
- login-provider ordering/visibility
- authentication diagnostics/test connection

Secrets are entered through secure secret-management mechanisms and must never be returned to the client after save. The UI may only show `configured/not configured` plus secret-reference metadata.

### 4.6 Roles & permissions

- role templates
- custom roles
- permission matrix grouped by module
- organization/site scope
- user-role assignments
- default role after onboarding
- temporary role validity windows
- sensitive-document permissions shown separately
- preview/evaluate effective permissions for a selected user
- clone role
- compare roles

All authorization decisions remain server-side.

### 4.7 Vehicles

- default vehicle status
- vehicle categories/classes
- required master-data fields
- custom field definitions
- custom-field order/group
- vehicle number/code template
- image limits
- distance/odometer display preferences
- hour-meter support defaults
- registration-certificate review policy
- vehicle status catalogue and transition rules where configurable
- default document categories for vehicles

### 4.8 Bookings & handover

- booking approval required
- allowed approver roles
- driver required
- overlap prevention (cannot be disabled in a way that permits data corruption)
- booking lead time
- maximum advance-booking period
- minimum/maximum duration
- buffers before/after booking
- cancellation deadline/policy
- waitlist enablement
- calendar invite behavior
- reminder schedule
- default handover checklist template
- default return checklist template
- mandatory odometer/fuel/photos fields
- damage confirmation behavior
- vehicle/driver eligibility policy
- booking status display/order

Settings that affect already-active bookings must define whether changes apply only to new bookings or also to future existing bookings.

### 4.9 Drivers & licenses

- first-login license upload requirement
- OCR extraction enablement
- manual verification requirement
- verifier role/permission policy
- expiry warning thresholds
- revalidation points: booking, approval, handover
- heavy-vehicle verified-state requirement
- supported license-class catalogue/rule mapping
- reminder recipients/escalation
- retention/access policy links

No setting may convert OCR extraction alone into legal/authenticity proof.

### 4.10 Workshop, service & parts

- work-order numbering template
- priorities/status catalogues
- default workshop site
- checklist templates
- task templates
- QA closeout requirement
- part-catalog enablement
- part rating scale
- supplier defaults
- service warning thresholds by days/km/engine-hours
- overdue escalation rules
- auto-create work order option
- labor-time entry behavior
- default document categories for invoices/workshop files

### 4.11 Documents & storage

Includes the complete DMS configuration from `docs/22_DOCUMENT_MANAGEMENT_SYSTEM.md`:

- DMS enablement
- general documents
- versioning
- virtual folders
- full-text indexing
- categories/tags/custom metadata definitions
- document validity/reminder defaults
- trash retention
- allowed download forms
- sensitive-download audit behavior
- upload size and MIME allowlists
- EXIF stripping
- SHA-256
- malware-scan provider/policy
- storage provider
- filesystem main/temp/export/archive/quarantine roots
- Windows UNC support
- Linux mount paths
- S3 endpoint/bucket/region/prefix/secret references
- path template
- category path mappings
- storage health check
- write/read/delete probe using disposable test object
- current storage utilization
- migration-required indicator
- resumable migration jobs with progress/error journal

Changing a populated storage root/provider never performs a blind path rewrite.

### 4.12 OCR & document processing

- OCR provider
- fallback provider
- languages
- confidence thresholds
- source preservation
- bounding-box storage
- image preprocessing options
- queue/concurrency limits where deployment-managed
- OCR diagnostic with sample fixture
- last successful worker heartbeat
- parser/template version information
- review-queue thresholds

### 4.13 Notifications & communication

- global enablement per channel: in-app, email, push, desktop, webhook
- notification event catalogue
- event-to-channel defaults
- organization/site recipient rules
- escalation recipients
- reminder schedules
- template editor with preview
- locale-specific templates
- sender name/address where runtime-editable
- SMTP host/port/TLS state where deployment policy permits
- SMTP secret-reference state
- send test email
- FCM/push state and diagnostic
- webhook allowlist/policy
- digest defaults
- user-level quiet hours/preferences where permitted

### 4.14 Reports & exports

- PDF enablement
- XLSX enablement
- default paper size
- locale
- timezone
- report header/footer
- logo usage
- filename templates
- generated-export retention
- CSV delimiter/encoding if CSV export is later enabled
- default date/time/number formats
- optional report watermark rules

### 4.15 Trips, logbook and working time

- trip log enablement
- required start/end odometer
- required job/reference fields
- work-time tracking
- break tracking
- active compliance/rule pack
- editable/correction policy
- correction reason requirement
- reminder/escalation behavior
- export defaults

Legal/compliance rule packs are versioned separately. A configurable business preference must never silently override a mandatory legal rule encoded by the selected rule pack.

### 4.16 Integrations

- calendar/ICS behavior
- outbound webhooks
- API/webhook credentials as secret references
- allowed callback hosts
- external system identifiers/mappings
- integration health/last sync
- enable/disable per integration
- retry/backoff parameters within safe limits

Future connectors must register their settings through the same settings registry.

### 4.17 Plugins

- installed plugin list
- enable/disable/update/uninstall
- compatibility state
- granted capabilities
- network grants
- plugin-specific settings schema/editor
- plugin health
- logs/diagnostics
- signature status
- isolated data/storage usage

Plugin settings are namespaced and cannot shadow core keys.

### 4.18 Privacy, retention & audit

- soft-delete defaults
- trash retention
- category-specific retention policies where allowed
- sensitive document read/download auditing
- audit retention
- audit hash-chain status
- privacy/export tooling policy
- purge-job status
- legal-hold support hook for future implementation

Changes reducing retention or audit coverage are dangerous changes and require explicit confirmation, permission and re-authentication when configured.

### 4.19 Backup, restore & maintenance

- backup status
- last successful backup
- configured backup target/status
- manual backup action
- scheduled backup policy if enabled by deployment
- retention count/days
- encryption configured state
- restore validation workflow
- maintenance mode
- database migration status
- storage migration status
- cleanup jobs

Restore is never a one-click destructive action without explicit confirmation, validation and permission checks.

### 4.20 System, diagnostics & observability

- application/build version
- environment/deployment mode
- database health/pool state
- API/worker/OCR health
- queue/backlog state
- filesystem/S3 health
- SMTP/push health
- metrics/tracing enablement display
- log level where runtime-editable
- health endpoint state
- active jobs
- failed jobs/retry action
- update/release information
- system information export with secrets redacted

### 4.21 Feature flags

- core feature enablement only for features designed to be toggleable
- feature dependency display
- organization/site scope where supported
- experimental flag marker
- rollout state
- audit history

A feature flag must not be used as a substitute for authorization or data migrations.

### 4.22 Personal settings

Available without system-admin access for allowed user-scoped keys:

- display name/profile details where locally managed
- language
- preferred timezone
- theme preference within approved themes
- preferred/home site
- dashboard layout preferences
- table density/page size
- notification preferences
- quiet hours
- email/push channel preference where policy permits
- default export format
- accessibility preferences

### 4.23 Android device settings

Device-local preferences are stored in Android DataStore, not the server settings DB unless they represent an account preference:

- biometric app lock
- offline cache policy/size
- sync over Wi-Fi only
- background synchronization
- upload quality/compression where server minimum quality remains enforced
- camera defaults
- notification permission/status
- local download/share behavior

Android must use platform-safe storage APIs. Do not expose arbitrary server filesystem paths and do not rely on unrestricted legacy external-storage access.

## 5. Settings UI behavior

Every settings screen must provide consistent behavior:

- search by setting name, key and help text
- category/subcategory navigation
- scope selector when the user has access to multiple scopes
- inherited/effective value badge
- `Reset to inherited` action
- inline validation
- help text and documentation link
- dirty-state tracking
- sticky save/apply bar
- discard changes
- leave-page warning for unsaved changes
- optimistic-concurrency token/version
- batch save of related settings in one transaction
- success/failure summary
- partial update is forbidden for an atomic settings batch unless explicitly modeled
- keyboard accessibility on web/desktop
- responsive/adaptive layout on Android/tablet

## 6. Change safety classes

Each setting has one of these change classes:

- `NORMAL` – applies immediately.
- `RESTART_REQUIRED` – saved but not fully effective until affected service restarts.
- `REAUTH_REQUIRED` – requires the current administrator to re-authenticate before apply.
- `MIGRATION_REQUIRED` – creates a controlled migration job; never applies by direct mutation.
- `DANGEROUS` – requires explicit confirmation, reason and re-authentication.
- `MANAGED_READ_ONLY` – shown for transparency but cannot be changed from the app.

A setting may have multiple flags, e.g. dangerous + restart-required.

## 7. Settings history and rollback

Every runtime setting mutation creates an immutable revision record containing:

- revision/change-set id
- timestamp
- actor
- organization/site/user scope
- changed keys
- previous effective/source values where non-secret
- new values where non-secret
- redacted markers for secret-related changes
- reason where required
- correlation id
- client/source
- validation result
- restart/migration flags

The UI exposes a history timeline and diff view.

Rollback:

- creates a new forward revision; it never deletes history
- revalidates current schema and permissions
- cannot restore secret plaintext that is not stored
- cannot bypass migrations or current security policy
- may require re-authentication/confirmation

## 8. Import/export

Administrators may export a portable settings package if deployment policy allows it.

Export contains:

- schema version
- application version
- organization/site scope
- settings keys/values permitted for export
- plugin setting namespaces
- no secret plaintext
- secret references only where safe
- checksums/metadata

Import is always two-stage:

1. validate and preview diff
2. explicitly apply

Import must report unknown/deprecated keys and incompatible schema versions. It cannot silently create privileged users, role grants, secrets or storage migrations.

## 9. Diagnostics

Complex settings provide `Test` actions without forcing the user to save an invalid configuration first when technically possible.

Mandatory diagnostics:

- database read/connectivity status (read-only diagnostics)
- storage provider connectivity + disposable object read/write/delete
- SMTP connection + test email
- OCR worker + sample processing
- push provider state/test device when available
- LDAP/Active Directory connection/bind/search test
- OIDC/SAML metadata/connectivity validation
- webhook target validation according to network policy
- plugin health checks

Diagnostic results are auditable, redact secrets and have timeouts.

## 10. Data model

### SettingDefinition

- `key` stable unique key
- `namespace` core or plugin id
- `category`
- `subcategory`
- `data_type`
- `schema_json`
- `default_value_json`
- `allowed_scopes`
- `read_permission`
- `write_permission`
- `secret_classification`
- `restart_required`
- `migration_required`
- `dangerous_change`
- `runtime_editable`
- `deprecated_at` optional
- `replacement_key` optional
- `documentation_anchor`

Core definitions may be code-registered/generated rather than user-created, but their effective registry is queryable.

### SettingValue

- `id`
- `key`
- `scope_type`: ORGANIZATION | SITE | USER | PLUGIN
- `scope_id`
- `value_json`
- `version`
- `created_at`
- `updated_at`
- `updated_by_user_id`

Unique: `(key, scope_type, scope_id)`.

### SettingsChangeSet

- `id`
- `scope_type`
- `scope_id`
- `actor_user_id`
- `reason` optional/required by policy
- `correlation_id`
- `client_type`
- `created_at`
- `result`

### SettingsRevisionItem

- `id`
- `change_set_id`
- `key`
- `old_value_json_redacted`
- `new_value_json_redacted`
- `old_source`
- `new_source`
- `schema_version`
- `restart_required`
- `migration_required`

### SettingsDiagnosticRun

- `id`
- `diagnostic_type`
- `scope_type`
- `scope_id`
- `requested_by_user_id`
- `started_at`
- `finished_at`
- `status`
- `result_summary_json_redacted`
- `correlation_id`

## 11. API contract

Minimum endpoints under `/api/v1`:

- `GET /settings/catalog`
- `GET /settings/effective?scopeType=&scopeId=`
- `GET /settings/values?scopeType=&scopeId=`
- `PATCH /settings/values`
- `POST /settings/validate`
- `GET /settings/history?scopeType=&scopeId=`
- `GET /settings/history/:changeSetId`
- `POST /settings/history/:changeSetId/rollback`
- `GET /settings/export?scopeType=&scopeId=`
- `POST /settings/import/validate`
- `POST /settings/import/apply`
- `POST /settings/diagnostics/:diagnosticType`
- `GET /settings/diagnostics/:id`
- `POST /settings/branding/preview`

Mutation endpoints require optimistic concurrency and return the resulting effective values/source metadata.

## 12. Permissions

At minimum:

- `settings.read`
- `settings.write`
- `settings.write_sensitive`
- `settings.history.read`
- `settings.rollback`
- `settings.import`
- `settings.export`
- `settings.diagnostics.run`
- `settings.deployment.read`
- `settings.feature_flags.manage`
- `settings.storage.configure`
- `settings.storage.migrate`
- `settings.identity.manage`
- `settings.notification.manage`
- `settings.retention.manage`
- `settings.backup.manage`
- `branding.manage`
- `site.settings.manage`
- `user.preferences.write`

Permissions are scope-aware. `SYSTEM_ADMIN` is not a shortcut around sensitive-document read permissions.

## 13. Audit events

Emit at minimum:

- `settings.changed`
- `settings.rollback_requested`
- `settings.rolled_back`
- `settings.import_validated`
- `settings.import_applied`
- `settings.diagnostic_started`
- `settings.diagnostic_completed`
- `settings.restart_required`
- `settings.migration_requested`
- `branding.changed`
- `site.settings_changed`
- `user.preferences_changed`

Do not emit secret plaintext in event payloads.

## 14. Testing

Mandatory automated coverage:

- precedence resolution tests
- organization/site/user isolation tests
- permission matrix tests
- invalid type/range/enum tests
- optimistic-concurrency conflict tests
- inherited/reset behavior tests
- revision/diff/rollback tests
- secret redaction tests
- restart-required state tests
- dangerous-change re-authentication tests
- settings import validation tests
- plugin namespace collision tests
- storage migration gate tests
- SMTP/storage/OCR/identity diagnostic tests with fakes/fixtures
- responsive settings navigation tests
- Android settings instrumentation tests

## 15. Acceptance criteria

The settings subsystem is complete only when:

1. Every runtime-editable product setting has a registered definition.
2. Every key in `config/system_config.json` is documented as deployment-only or runtime-overridable.
3. The UI shows effective value and source.
4. Site/user overrides can be reset to inherited values.
5. Dangerous settings cannot be changed without the required confirmation/re-authentication.
6. Settings changes are atomic, versioned and auditable.
7. Rollback creates a new revision and never destroys history.
8. Secret values are never returned to clients or logs.
9. Diagnostics exist for storage, SMTP, OCR and configured identity providers.
10. Web, Windows and Android expose equivalent settings semantics where the setting is applicable to that platform.
11. All settings are documented in the Wiki with key, type, default, scope, permission, restart/migration requirement and impact.
