# 06 – UI/UX Mapping to DeepBlue Liquid Glass

The provided `DeepBlue_Liquid_Glass_Kit` is a binding design source.

## 1. Core visual direction

Mandatory characteristics from the kit:

- dark-first deep navy/ink background
- electric blue as primary interaction color
- strongly rounded cards and floating surfaces
- selective liquid-glass material rather than blur everywhere
- clear data hierarchy
- subtle depth and strokes
- morphing/floating navigation behavior where platform-appropriate
- restrained semantic colors
- smooth spatial transitions
- reduced-motion support

The provided token files must become machine-readable source inputs for Web/Desktop and must be mapped to Compose theme tokens for Android.

## 2. No copied sample content

Reference screenshots are visual-only. Do not copy:

- example app names
- financial values
- labels unrelated to fleet management
- hardware frame elements

## 3. Web/Desktop information architecture

Primary navigation:

- Dashboard
- Vehicles
- Bookings
- Workshop
- Drivers
- Trips
- Reports
- More/Admin depending permission

Desktop/web should use a left floating navigation rail/sidebar on wide screens and morph into compact navigation at smaller widths. Do not force mobile bottom navigation onto a 1600px desktop viewport.

## 4. Android navigation

Phone:

- floating bottom navigation for primary destinations
- contextual FAB only where a genuine dominant action exists

Tablet:

- adaptive navigation rail / wide navigation
- master-detail layouts where useful

## 5. Screen patterns

### Dashboard

Hero zone:

- fleet status summary or currently relevant personal status

KPI cards:

- available vehicles
- active bookings
- vehicles in workshop
- service due soon
- role-dependent driver/license warnings

Sections:

- upcoming bookings
- workshop backlog
- service timeline
- recent activity

### Vehicle list

- search
- site/status/type filters
- card/table switch depending width
- clear status pill
- plate + fleet number + model hierarchy
- upcoming availability indication

### Vehicle detail

Hero:

- photo/vehicle identity/status

Tabs/sections:

- Overview
- Technical data
- Equipment
- Registration certificate
- Documents
- Service
- Workshop
- Bookings
- Costs
- Trips
- History

### Digital registration certificate

Two main modes:

1. **Document mode**
   - visually arranged normalized fields
   - front/rear toggle
   - digital, non-official styling
   - field hover/tap shows tooltip

2. **Data mode**
   - grouped technical and holder data
   - field key visible
   - source/confidence indicator for authorized users

Tooltip content:

- field key
- official field meaning
- concise explanation
- source value
- optional “show on original” action

### Booking calendar

- resource timeline on desktop
- agenda/day/week on mobile
- status chips
- conflict indications
- popup quick details
- booking editor in sheet/modal according to complexity

### Workshop order

- hero status/vehicle
- checklist task cards
- parts section
- labor section
- photos/documents
- timeline/activity
- status transition popup

### Driver/license view

- do not expose license image by default in broad lists
- show eligibility badge
- class chips
- expiry timeline
- restricted image viewer behind explicit permission

## 6. Popup-heavy interaction model

Use popups/sheets for:

- status changes
- quick booking preview
- filter selection
- part selection
- adding checklist task
- service completion
- notification actions

Use full pages for:

- complex vehicle editor
- workshop order editor with many sections
- driver/license review
- reporting builders
- plugin management

## 7. Design token pipeline

Source:

`design/DeepBlue_Liquid_Glass_Kit/02_DESIGN_SYSTEM/design_tokens.json`

Generate:

- CSS variables / TypeScript token object for web
- Tauri inherits web tokens
- Kotlin object/theme mapping for Compose

No feature component may invent a local hex color/radius/motion duration unless the design token set is deliberately expanded centrally.

## 8. Accessibility

- WCAG AA target
- 48dp minimum Android targets
- keyboard navigation on Web/Desktop
- visible focus states
- semantic labels
- screen reader labels
- status not encoded only by color
- font scaling
- reduced motion
- high-contrast fallback for glass surfaces

## 9. Performance

- avoid nested full-screen backdrop blur
- only 2–3 dominant blur layers at once
- virtualize long tables/lists
- thumbnail vehicle images
- lazy-load large source documents
- Android animations must remain smooth on mid-range devices

\n## Settings UX\n\nThe settings experience follows the DeepBlue Liquid Glass system but prioritizes clarity over decorative effects.\n\nWeb/Windows:\n- left category navigation + searchable settings index\n- content pane with grouped glass panels\n- sticky save/discard bar when dirty\n- effective-source badges (`System`, `Organisation`, `Standort`, `Benutzer`)\n- inline validation and help text\n- restart/migration/danger badges\n- dedicated confirmation modal for dangerous changes\n- diff modal before bulk import/apply\n- history drawer/timeline with rollback action\n- live branding preview\n- diagnostic result popovers/sheets\n\nAndroid phone:\n- settings category list → native detail screen\n- bottom sheets/dialogs for editors and confirmation\n- sticky bottom save action when a group is dirty\n- no desktop-style three-column form cramming\n\nAndroid tablet:\n- adaptive list/detail split pane when space allows\n- same settings semantics and permissions as web\n\nAll platforms:\n- inherited values are visually distinct but readable\n- disabled/managed settings explain why they cannot be edited\n- `Reset to inherited` is explicit\n- unsaved changes survive short navigation where appropriate, but never silently apply\n- keyboard/focus accessibility on web/desktop\n