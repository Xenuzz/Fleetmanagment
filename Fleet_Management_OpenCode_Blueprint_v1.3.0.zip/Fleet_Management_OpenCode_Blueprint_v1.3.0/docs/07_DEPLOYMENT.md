# 07 – Deployment Architecture

## 1. Supported server modes

### A. Docker Compose – recommended default

Services:

- `postgres`
- `keycloak`
- `api`
- `worker`
- `ocr-worker`
- `web`
- `caddy`
- optional `clamav`

Data volumes:

- postgres data
- keycloak data if not using same PostgreSQL database arrangement
- application files
- backup destination

### B. Native Linux

Target:

- Debian/Ubuntu first
- systemd units
- PostgreSQL native package
- Java runtime + Keycloak
- Node runtime or packaged application runtime
- Python OCR virtual environment
- Caddy or supported reverse proxy

Services:

- fleet-api.service
- fleet-worker.service
- fleet-ocr.service
- keycloak.service
- caddy.service

### C. Native Windows Server

Target:

- Windows Server 2022/2025-compatible packaging strategy
- PostgreSQL Windows service
- Keycloak Java service
- API and worker as Windows services using a stable service wrapper
- OCR worker as Windows service
- Caddy as Windows service/reverse proxy

Provide PowerShell installer scripts with:

- prerequisite checks
- directory creation
- ACL configuration
- service registration
- firewall rules opt-in
- config validation
- health verification
- upgrade mode
- rollback notes

## 2. Directory layout for native server

Linux example:

```text
/opt/fleet-platform/
  app/
  config/
  runtime/
/var/lib/fleet-platform/
  files/
  tmp/
  exports/
  archive/
  quarantine/
  reports/
  backups/
/var/log/fleet-platform/
```

Windows example:

```text
C:\Program Files\FleetPlatform\
  app\
  config\
  runtime\
C:\ProgramData\FleetPlatform\
  files\
  tmp\
  exports\
  archive\
  quarantine\
  reports\
  backups\
  logs\
```


### Network/object storage

The filesystem provider may point to a dedicated local volume, a Linux mount path, or an approved Windows UNC share. The Fleet services must run under an account with the required read/write/delete ACLs. Do not embed network-share credentials in `system_config.json`; use the operating-system/service-account mechanism. S3-compatible storage is the alternative object-storage provider.

Changing an existing root/provider is an administrative migration, not a simple string edit: copy objects, verify SHA-256, journal progress, cut over after verification and retain/clean the source according to policy. Database and file storage must be backed up as one consistency domain.

## 3. Reverse proxy

Caddy recommended because it supports Windows/Linux and simple TLS configuration.

Routes:

- `/` -> web
- `/api/*` -> API
- `/ws/*` -> API WebSocket
- `/auth/*` or dedicated host -> Keycloak depending deployment

## 4. Database schemas

Recommended separate databases or schemas:

- application database
- Keycloak database

Do not share application tables and Keycloak tables in the same schema.

## 5. Upgrade strategy

A release contains:

- application version
- DB migration set
- web bundle
- worker bundle
- OCR compatibility version
- config schema version
- plugin API version

Upgrade sequence:

1. backup
2. validate current version
3. download/verify checksum
4. maintenance mode when migration requires it
5. run migration
6. deploy backend/worker
7. deploy web
8. health checks
9. leave maintenance mode
10. record deployment event

## 6. Docker images

Build multi-architecture where practical:

- linux/amd64
- linux/arm64

Images:

- `fleet-api`
- `fleet-worker`
- `fleet-web`
- `fleet-ocr`

Pin base images by digest in release branches where reproducibility is required.

## 7. Backups

Built-in deployment scripts should support:

- PostgreSQL backup
- file storage backup
- config snapshot
- checksum manifest
- encrypted archive option
- retention rotation

Restore guide must include verification of:

- users can log in
- file links resolve
- booking/workshop data exists
- job worker runs
- OCR worker health

## 8. Desktop distribution

Windows desktop Tauri build:

- MSI and/or NSIS installer
- x64 minimum
- optional ARM64 when supported/tested
- automatic update channel configurable
- signed release when signing certificate is available

## 9. Android distribution

GitHub Actions produce:

- debug APK for CI/testing
- signed release APK where configured
- AAB for Play/internal distribution where configured

Signing secrets must be GitHub secrets, never committed.

## 10. Environment profiles

- development
- test
- staging
- production

Non-secret differences are expressed in `system_config.json` variants generated from validated overlays, not scattered code constants.

