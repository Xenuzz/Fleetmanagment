# 18 – Screen Inventory

## Shared shell
Login/SSO, first-login wizard, global search, command palette, notification center, profile, site switcher, help, offline/sync indicator, permission error and global settings navigation.

## Dashboard
Role-aware KPI cards, upcoming bookings, vehicles unavailable, service due/overdue, open workshop tasks, license expiries, alerts, quick actions and recent activity.

## Vehicles
Catalog/list/grid, map/location where applicable, vehicle detail overview, technical data, equipment, status/history, media gallery, documents, digital registration view, service timeline, workshop history, booking history, trips, costs and settings/custom fields.

## Booking
Availability search, calendar, booking wizard, approval inbox, booking detail, handover wizard, return wizard, conflict/eligibility dialog and booking policy admin.

## Drivers
Driver catalog, driver detail, license summary, original-document restricted viewer, OCR/review panel, class/expiry timeline and verifier queue.

## Workshop/parts/service
Workshop board, work-order detail, task/checklist view, time/parts/document panels, QA closeout, issue/backlog list, parts catalog, part detail/fitment experience, service-plan editor, due-service dashboard.

## Trips/work time
Trip list/detail, active trip workflow, activity timeline, break/work-time entry, correction dialog, driver timesheet, export/report wizard.

## Documents/DMS/costs
Global document library with virtual folder/category tree, search, saved filters, recent/favorites, upload/import, multi-file selection, document detail, metadata/tags/custom fields, linked entities, version history, preview, OCR review, validity/reminders, trash/restore, original/copy download and ZIP/PDF bundle actions. Each vehicle has a document center aggregating registration papers, inspection, insurance, ownership/leasing, workshop, invoices/costs, damage/accident, manuals/certificates and custom documents without duplicating the underlying file. Fuel receipt and invoice inboxes feed the same DMS.

## Administration / Settings
Dedicated settings home/health overview; searchable category navigation; scope selector; effective-value/source inspector; organization; sites; branding/live preview; users/onboarding/identity/SSO/SAML/LDAP/Active Directory; roles/permission matrix/effective permission preview; vehicles/custom fields/status catalogues; booking/handover policies; drivers/licenses; workshop/service/parts; DMS categories; storage provider/root/temp/export/archive/quarantine/path templates and migration jobs; OCR; notification templates/event rules/SMTP/push/webhooks; reports/exports; trips/work-time; integrations; plugins; privacy/retention/audit; backup/restore/maintenance; feature flags; system health/jobs/observability; settings history/diff/rollback; settings import/export preview; diagnostics.

## Personal settings
Profile, language/timezone, theme preference, preferred site, dashboard/table preferences, notification preferences/quiet hours, export preference and accessibility settings. Android additionally exposes device-local biometric lock, offline-cache/sync and upload/camera preferences.

Every screen must define web desktop, tablet and phone behavior; Android uses native screen/adaptive-pane patterns while preserving feature semantics.
