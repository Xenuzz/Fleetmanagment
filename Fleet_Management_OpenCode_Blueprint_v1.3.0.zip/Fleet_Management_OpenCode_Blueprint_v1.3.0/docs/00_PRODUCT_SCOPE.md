# 00 – Product Scope

## 1. Product goal

Build a self-hostable, enterprise-capable fleet management platform that can serve one company with multiple locations and can later be expanded to multiple organizations without rewriting the data model.

The platform must cover the complete operational lifecycle of vehicles, drivers, bookings, workshop work, documents, costs, trips, working time and notifications.

The system is not a single web dashboard. It is one backend platform with three first-class client surfaces:

- Web application
- Windows desktop application
- Android application optimized for both phone and tablet

All three use the same backend contracts, permission model and business rules.

## 2. Mandatory functional domains

### 2.1 Organization and locations

- organization profile
- company name
- legal display name
- logo
- theme colors
- language
- timezone
- date/time/number formats
- email sender configuration
- default booking policies
- default service policies
- retention policies
- one or more locations/sites
- site address and contact data
- site operating hours
- site-specific fleet ownership
- site-specific roles and approvals
- cross-site visibility rules
- optional site transfer of vehicles

### 2.2 User and role management

- local identities through Keycloak
- SSO through OIDC/SAML
- Active Directory / LDAP federation
- optional Kerberos/SPNEGO at identity-provider level
- user invitations
- first-login onboarding wizard
- profile data
- driver profile
- license upload and verification
- role memberships
- organization-wide and site-scoped permissions
- account activation/deactivation
- audit of administrative changes

### 2.3 Vehicle catalog and vehicle management

Each vehicle must support at minimum:

- internal fleet number
- registration plate
- VIN
- make
- model
- variant/version
- year
- first registration
- vehicle category
- body type
- fuel/energy type
- engine displacement
- power kW / PS display conversion
- transmission
- drivetrain
- emissions data
- vehicle dimensions
- axle data
- permitted masses
- towing values
- seats / standing places
- tire data
- color
- mileage
- operating hours where relevant
- tank / battery data where relevant
- inspection dates
- insurance metadata
- leasing/ownership metadata
- purchase date / acquisition cost
- cost center
- assigned site
- status
- equipment list
- photos
- documents
- notes
- tags
- custom fields
- lifecycle history

### 2.4 Digital vehicle registration certificate

The system must support a digital representation of German Zulassungsbescheinigung Teil I as a structured, interactive record.

Required behavior:

- upload one or more photos/scans
- detect document orientation and sides
- preserve original source images
- OCR the visible fields
- map extracted values to the vehicle record with confidence scores
- show a digital front view
- show a digital rear view
- show front only mode
- show structured data mode
- display field tooltips with field identifier, name and short explanation
- allow users to toggle between normalized value and source image crop
- allow manual correction of every OCR result
- store the correction history
- flag unresolved low-confidence fields
- clearly label the digital rendering as a non-official digital representation
- never reproduce or expose hidden/scratch-off security codes as normal business data
- protect holder/address data by permissions

For Germany, the document field catalogue must be based on the current FZV Anlage 6 and versioned so that template changes are maintainable.

### 2.4.1 Vehicle and general document management system (DMS)

The platform contains a full DMS as specified in `docs/22_DOCUMENT_MANAGEMENT_SYSTEM.md`. It is not limited to vehicle attachments. Documents may be vehicle-specific, linked to workshop/orders/invoices/receipts or completely general company documents. Required capabilities include configurable categories/virtual folders, metadata, tags, versioning, OCR/indexing, multi-entity linking, preview, audited downloads, ZIP/PDF bundles, retention and configurable storage paths/providers. Vehicle registration certificates and other vehicle papers must be downloadable by authorized users as source copies and, where applicable, generated clearly marked digital copies.

### 2.5 Driver and license management

- driver profile
- current employment/site assignment metadata
- driving license document upload
- front and back image capture
- OCR extraction
- document issue/expiry dates where present
- license classes
- class-specific valid-from and valid-until dates
- restriction/key numbers
- automatic validation checks
- confidence scoring
- manual verification state
- expiry reminders
- configurable verification recurrence
- configurable policy for whether auto-validated or only manually verified licenses may be used for booking
- full history when a new license replaces an old one

### 2.6 Driver eligibility engine

Every vehicle or vehicle class can define required driving-license classes and optional additional requirements.

When selecting a driver for a booking:

- only eligible drivers are shown by default
- server-side validation runs again on booking save
- validation runs again on approval
- validation runs again on vehicle handover
- expiry inside the booking time window must invalidate eligibility when the relevant license class expires before booking end
- admin override must require a reason and permission
- override must be audited

### 2.7 Vehicle status and availability

Canonical status values:

- AVAILABLE
- RESERVED
- IN_USE
- WORKSHOP
- OUT_OF_SERVICE
- CLEANING
- BLOCKED
- TRANSFER
- DECOMMISSIONED

Availability is not merely the status field. It is derived from:

- vehicle status
- approved/reserved booking windows
- workshop blocks
- maintenance blocks
- location policy
- optional manual blocks

### 2.8 Booking system

- booking request
- calendar view
- timeline/resource view
- vehicle search/filter
- driver selection
- booking purpose
- destination/order/project reference
- start/end location
- date/time
- passenger/load metadata if needed
- conflict detection
- approval workflow
- reject reason
- cancellation
- no-show
- check-out/handover
- active trip state
- return/check-in
- booking history
- comments
- attachments
- email notifications
- calendar invitations (.ics)
- in-app notifications
- Android notifications
- configurable reminder times

Canonical booking status:

- REQUESTED
- APPROVED
- REJECTED
- CANCELLED
- READY_FOR_HANDOVER
- IN_USE
- RETURNED
- COMPLETED
- NO_SHOW

### 2.9 Handover and return

For vehicle handover and return:

- assigned booking
- current mileage
- current fuel/charge level
- exterior/interior photos
- damage check
- cleanliness check
- required equipment check
- free-text notes
- signature/confirmation where company policy enables it
- timestamp
- user/device context
- checklist templates per vehicle class
- discrepancy flag
- new damage creation directly from handover
- offline draft support in Android

### 2.10 Workshop system

- create workshop order per vehicle
- planned vs unplanned work
- priority
- internal/external workshop
- responsible mechanic/team
- due date
- mileage/operating-hour trigger
- fault description
- diagnosis
- work instructions
- task checklist
- task statuses
- parts consumption
- labor time
- photos
- attachments
- invoices
- comments
- vehicle blocking during workshop
- reopen closed order with audit reason

Canonical workshop status:

- DRAFT
- OPEN
- PLANNED
- IN_PROGRESS
- WAITING_FOR_PARTS
- WAITING_EXTERNAL
- PAUSED
- READY_FOR_QA
- COMPLETED
- CANCELLED

### 2.11 Parts catalogue

Each part can include:

- manufacturer
- manufacturer part number
- OEM numbers
- supplier
- supplier SKU
- name
- category
- description
- purchase price history
- tax
- purchase URL
- barcode/GTIN if available
- stock metadata if stock management is enabled
- compatible vehicle models
- exact VIN compatibility notes
- installation notes
- images/documents

Part installation review must support:

- fit accuracy rating
- installation accuracy/quality rating
- installation ease rating
- general result rating
- free-text report
- installation time
- tools/special tools notes
- vehicle/model context
- author and date
- photos

### 2.12 Service intervals

Service schedules must support combined triggers:

- time based
- mileage based
- operating-hour based
- whichever comes first

Examples:

- oil service every X km or Y months
- inspection every X months
- custom statutory/operational checks
- tire change season/date policy

Each schedule supports:

- warning threshold in days
- warning threshold in km
- warning threshold in hours
- escalation threshold
- responsible role/user
- site policy
- auto-create workshop order option
- next due calculation
- completion reset logic
- manual correction with audit trail

### 2.13 Costs, fuel receipts and invoices

Fuel receipt workflow:

- upload photo/PDF
- OCR supplier/date/amount/liters/unit price/fuel type
- assign vehicle
- optional odometer
- validation of amount = quantity × unit price within rounding tolerance
- manual correction
- link to trip or booking optionally
- cost center

Invoice workflow:

- upload PDF/photo
- vendor
- invoice number
- invoice date
- net/tax/gross
- line items
- related workshop order
- related parts
- payment state metadata if desired
- duplicate detection by vendor + invoice number + amount/date

### 2.14 Trip log and driver work-time system

- vehicle
- driver
- booking/order/project reference
- start/end time
- start/end odometer
- start/end location
- route/purpose
- business/private/other classification if configured
- stops
- activity segments
- driving time
- other working time
- break time
- waiting/availability time
- notes
- attachments

Exports:

- single trip PDF
- monthly trip log PDF
- CSV
- XLSX
- individual timesheet PDF
- weekly/monthly timesheet XLSX

For truck-driver use, legal compliance rules must be implemented as a separately versioned and configurable rule pack. The UI must distinguish computed working/driving time from a legal compliance determination. Legal rule changes must not require rewriting trip storage.

### 2.15 Notifications

Channels:

- in-app notification center
- email
- Android push
- Windows desktop notification
- optional webhook/plugin channels

Events include:

- booking requested
- booking approved/rejected/cancelled
- upcoming booking
- vehicle ready for handover
- booking overdue/return overdue
- workshop order assigned
- workshop due
- service interval approaching/overdue
- license verification required
- license/license-class expiry approaching
- document OCR requires review
- invoice processing failed
- plugin/system error for administrators

### 2.16 Reports and exports

- fleet inventory
- vehicle lifecycle/cost summary
- workshop backlog
- service due report
- booking utilization
- driver eligibility/expiry report with strict permission controls
- fuel cost/consumption
- cost per vehicle/km
- trip log
- work-time sheet
- audit export
- vehicle dossier PDF

### 2.17 Admin dashboard and settings

The administration/settings area is a dedicated platform subsystem described in `docs/23_ADMIN_SETTINGS_SYSTEM.md`. It must not be implemented as disconnected feature forms.

Admin dashboard exposes at minimum:

- system/API/database/worker/OCR health
- job queues/backlog/failed jobs
- storage provider health, usage and migration status
- SMTP/push/identity-provider diagnostics
- pending driver-license reviews
- overdue service items and workshop backlog
- active bookings and fleet exceptions
- plugin health/signature/compatibility
- application/build version and update information
- pending restart-required settings
- recent settings changes and dangerous-change audit entries

Settings hierarchy:

- deployment/system policy
- organization
- site/location
- user preferences
- plugin namespaces

Settings capabilities:

- searchable settings navigation
- effective value + source/inheritance display
- reset-to-inherited
- typed validation and constraints
- atomic save with optimistic concurrency
- settings history and diff
- rollback as a new revision
- secret redaction/reference handling
- restart-required and migration-required indicators
- dangerous changes with confirmation/re-authentication/reason
- settings import/export with secret redaction and preview
- diagnostics/test actions for storage, SMTP, OCR, identity and plugins
- full audit trail

Mandatory settings groups:

- overview/health
- organization
- sites/locations
- branding/appearance
- users/onboarding/identity/SSO/SAML/LDAP/Active Directory
- roles/permissions
- vehicles/custom fields/status catalogues
- bookings/handover/return policies
- drivers/licenses/eligibility
- workshop/service/parts
- documents/DMS/storage paths/providers/migrations
- OCR/document processing
- notifications/email/push/webhooks/templates
- reports/exports
- trips/logbook/work time
- integrations
- product plugins
- privacy/retention/audit
- backup/restore/maintenance
- system/diagnostics/observability
- feature flags
- personal settings
- Android device-local settings where applicable

### 2.18 Product plugin system

The fleet platform itself must support plugins. This is independent of OpenCode development tools.

Core requirements:

- install
- validate
- enable
- disable
- upgrade
- uninstall
- permissions/capabilities
- health status
- version compatibility
- plugin settings
- plugin events
- plugin API tokens
- optional UI extension points
- isolated plugin data
- no direct unrestricted core DB access

## 3. Platform requirements

### 3.1 Server deployments

- Docker / Docker Compose distribution
- native Linux server distribution
- native Windows Server distribution

### 3.2 Clients

- Web
- Windows desktop
- Android phone
- Android tablet

### 3.3 GitHub deliverables

- complete repository
- README
- architecture docs
- Wiki source
- GitHub Wiki sync workflow
- issue templates
- PR template
- CODEOWNERS sample
- security policy
- contribution guide
- changelog
- release workflow
- Android APK/AAB artifacts
- Windows desktop installer artifacts
- server release archive
- Docker images
- SBOM/checksums

