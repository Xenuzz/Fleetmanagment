# 14 – Configuration Strategy

## 1. Rule

All non-secret **deployment-level** system parameters belong in:

`config/system_config.json`

Runtime-editable business/UI settings belong to the central Settings subsystem described in `docs/23_ADMIN_SETTINGS_SYSTEM.md`.

The main application code must not contain company-specific configuration, hidden feature constants or ad-hoc setting stores.

## 2. Secrets

Secrets are referenced by environment-variable/secret-reference names from the central configuration layer.

Feature modules receive validated runtime configuration/settings objects and do not call `process.env` directly.

After a secret is stored/configured, clients receive only redacted/configured-state metadata, never the secret plaintext.

## 3. Deployment config sections

- meta
- deployment
- organization
- branding
- identity
- database
- settings
- storage
- documents
- files
- ocr
- bookings
- licenses
- workshop
- service
- trips
- notifications
- email
- push
- reports
- audit
- retention
- plugins
- observability
- features

## 4. Validation

- JSON Schema committed
- startup fails fast on invalid values
- unknown keys are errors under the production strictness policy
- config schema has version
- migrations between config schema versions documented
- deployment values are normalized before feature modules consume them

## 5. Runtime settings engine

Runtime-editable settings are persisted in the application database only for keys registered as editable.

Precedence:

1. hard security constraints / managed deployment policy
2. deployment `system_config.json`
3. organization override for allowed keys
4. site override for allowed keys
5. user preference for allowed UI/notification keys

The resolver returns:

- effective value
- value source
- inherited value
- schema/validation metadata
- allowed scopes
- read/write permissions
- restart requirement
- migration requirement
- dangerous-change classification

No feature is allowed to implement a second precedence algorithm.

## 6. Admin UI

The Admin UI is specified in `docs/23_ADMIN_SETTINGS_SYSTEM.md` and must provide:

- settings search/navigation
- effective-value/source display
- reset-to-inherited
- validation
- atomic save + optimistic concurrency
- change history/diff/rollback
- dangerous-change confirmation/re-authentication
- restart/migration indicators
- diagnostics/test actions
- import/export with secret redaction

## 7. Storage and document path settings

Storage configuration is deployment-sensitive and is represented explicitly in the Admin UI with effective value, source and restart/migration requirements.

Support:

- filesystem roots
- Windows paths and UNC shares
- Linux mount paths
- S3-compatible storage
- primary root
- temporary-processing root
- export root
- archive root
- quarantine root
- object prefix
- category path templates

Never expose physical paths to normal clients. Existing files are moved only through a resumable checksum-verified storage migration job.

The `documents` section controls versioning, general-document support, copy downloads, bundle exports, virtual folders/categories, retention/trash behavior and audit requirements. See `docs/22_DOCUMENT_MANAGEMENT_SYSTEM.md`.

## 8. Settings bootstrap policy

The `settings` section of `system_config.json` defines whether runtime editing/history/import/rollback are permitted and how sensitive changes are protected. It does **not** contain every business setting value.

Default policy in this blueprint:

- runtime editing enabled
- organization/site/user scopes enabled where definitions permit them
- revision history enabled
- rollback enabled
- import/export enabled with secrets redacted
- dangerous changes require re-authentication and reason
- optimistic concurrency required
- effective source shown to administrators

## 9. Configuration documentation requirement

Every deployment config key and every runtime setting key must be documented with:

- key
- type
- default
- allowed values/range
- scope
- required permission
- secret classification
- runtime editable yes/no
- restart required yes/no
- migration required yes/no
- dangerous-change classification
- effect and dependencies
- example where useful
