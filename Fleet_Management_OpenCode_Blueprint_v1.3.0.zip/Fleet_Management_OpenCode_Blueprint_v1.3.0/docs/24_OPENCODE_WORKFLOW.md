# 24 – OpenCode Project Workflow

## Initial setup
1. Copy this blueprint content into the Git repository root.
2. Keep `AGENTS.md`, `opencode.json`, `.opencode/`, `project-context/`, `docs/`, `config/` and `design/` committed.
3. Start OpenCode from the repository root.
4. Do **not** run `/init` at bootstrap because the curated `AGENTS.md` already exists.
5. Verify MCP status with `opencode mcp list`. Context7 should connect. Playwright should remain disabled until UI/E2E work.
6. In the TUI select the built-in **Plan** primary agent using Tab.
7. Run `/project-bootstrap`.
8. Review the report before switching to Build.

## Per phase
1. `/phase-plan <phase>` under Plan.
2. Review/approve plan.
3. Switch to Build with Tab.
4. Load `feature-dev` or `implement-module` and implement the approved vertical slice.
5. Use specialist subagents where useful.
6. `/review-change`.
7. Fix blockers/high findings.
8. `/finish-phase <phase>`.
9. Commit only after gates pass; push only with explicit approval.

## Context discipline
- Start a fresh OpenCode session for each large phase or domain.
- Keep Context7 enabled; enable Playwright only when needed.
- Prefer `git`/`gh` CLI over GitHub MCP for routine work.
- Use skills on demand rather than pasting long workflow prompts repeatedly.
- Keep `docs/IMPLEMENTATION_STATUS.md` and requirement traceability current.
