# 10 – Testing and Acceptance

## 1. Test pyramid

### Unit

- domain calculations
- eligibility rules
- service due calculation
- notification policy
- OCR parser normalization
- permission policy helpers

### Integration

- PostgreSQL repositories
- transaction/outbox behavior
- booking conflict constraints
- Keycloak/OIDC boundary mocks or test realm
- file access authorization
- job execution

### Contract

- OpenAPI schema
- generated clients
- event schema compatibility

### E2E

- browser workflows through Playwright
- Android critical flows
- desktop smoke tests

## 2. Critical E2E scenarios

### Authentication/onboarding

- local user first login
- SSO user first login
- incomplete onboarding redirect
- license upload and review

### Vehicle

- create vehicle
- add equipment
- upload registration certificate
- accept/correct OCR field
- digital certificate tooltip

### Booking

- available vehicle booking
- overlapping booking denied
- ineligible driver hidden and server-rejected
- approval
- email/calendar job created
- handover
- return

### Workshop

- create order
- add tasks
- add parts
- complete checklist
- service schedule reset

### Service

- due by date
- due by mileage
- due by hours
- whichever-first behavior
- warning transitions

### Files/security

- unauthorized file download denied
- cross-site restricted object denied
- cross-organization object denied

### Offline Android

- open assigned booking offline
- capture return draft
- reconnect
- successful idempotent sync
- conflict shown to user when server changed

## 3. Authorization matrix tests

Each permission-sensitive endpoint must include tests for:

- no permission
- correct permission same site
- correct permission other site without cross-site scope
- organization admin
- inactive user

## 4. Booking race test

Two concurrent requests attempt overlapping approved bookings for the same vehicle.

Expected:

- one succeeds
- one returns deterministic conflict
- database contains one blocking booking only

## 5. OCR quality tests

Keep a legally usable test fixture set with synthetic/redacted documents.

Test:

- rotated image
- low light
- crop
- front/back swapped
- missing field
- OCR ambiguous digit/letter
- correction workflow

Never commit real employee licenses or sensitive production documents as test fixtures.

## 6. Design acceptance

For every client:

- DeepBlue token compliance
- dark-first navy background
- no scattered magic color values
- correct large corner radii
- popups/sheets motion
- reduced motion
- keyboard navigation web/desktop
- phone and tablet layouts Android
- small viewport web
- font scaling

## 7. Performance targets

Initial practical targets on representative hardware/network:

- common list API p95 under 400ms excluding large report/OCR jobs
- application shell interactive without loading entire datasets
- virtualized lists for >500 visible records
- image thumbnails rather than full originals in lists
- background report/OCR jobs non-blocking
- Android scroll/animation target 60fps on representative mid-range test device

These are product engineering targets, not contractual SLAs.

## 8. Definition of Done

A feature is done only when:

- backend business logic exists
- authorization exists
- API contract exists
- client UI exists on required surfaces or phase scope explicitly says otherwise
- tests pass
- audit behavior exists for sensitive changes
- loading/empty/error/permission states exist
- documentation is updated
- no TODO placeholder remains for the accepted feature scope

