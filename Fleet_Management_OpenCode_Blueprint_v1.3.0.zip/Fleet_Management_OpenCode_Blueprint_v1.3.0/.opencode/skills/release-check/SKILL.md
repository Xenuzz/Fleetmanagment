---
name: release-check
description: Perform a release-readiness gate for backend, web, Windows desktop, Android, deployment images and documentation.
---
# Release Check

Verify clean git status, version/changelog, migration safety, generated-contract consistency, full CI matrix, security scans, SBOM/checksums, Docker images, Linux/Windows Server installers, Windows desktop artifact, Android APK/AAB signing state, Wiki sync, backup/restore docs, upgrade notes and known issues. Never publish or push a release without explicit approval.
