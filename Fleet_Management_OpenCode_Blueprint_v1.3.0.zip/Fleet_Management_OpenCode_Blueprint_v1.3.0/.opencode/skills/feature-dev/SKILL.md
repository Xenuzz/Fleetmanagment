---
name: feature-dev
description: Plan and implement one Fleet Management feature as a controlled vertical slice.
---
# Feature Development
1. Read the relevant product, architecture, data, security, design and test specifications.
2. Explore the existing implementation before proposing new abstractions.
3. Produce an impact map: owning module, invariants, DB/migrations, API/contracts, permissions/audit, jobs/events, web/desktop, Android/offline, config, tests and docs.
4. Identify risks and acceptance criteria before edits.
5. Implement the smallest complete vertical slice. Do not create disconnected placeholder layers.
6. Run formatter, lint, type-check, tests and migration/contract checks relevant to the slice.
7. Update documentation and requirement traceability in the same change.
8. Summarize changed files, verification run, remaining risks and intentionally deferred work.
