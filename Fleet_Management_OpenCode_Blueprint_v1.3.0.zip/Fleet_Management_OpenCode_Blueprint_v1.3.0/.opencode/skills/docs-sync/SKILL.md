---
name: docs-sync
description: Update Fleet Management operator, admin, user, developer, API and plugin documentation after behavior changes.
---
# Documentation Sync
Determine which docs/wiki/config/API references are affected by the change. Update them in the same change. Every new setting documents key, type, default, scopes, validation, permissions, restart/migration needs and security impact. Every API change updates OpenAPI/contracts/examples. Every plugin extension updates SDK docs.
