---
name: implement-module
description: Implement or extend one Fleet Management domain module end-to-end with architecture, security, tests and docs.
---
# Implement Module

1. Read the product scope, architecture, module workflow, data model, security, design and testing docs relevant to the requested module.
2. Produce a short impact map: domain ownership, database, API, events/jobs, permissions, UI surfaces, Android/offline impact, configuration and docs.
3. Implement vertical slices rather than disconnected layers.
4. Add or update migrations, generated contracts, authorization, auditing and validation before UI completion.
5. Add tests for domain rules plus at least one end-to-end happy path and one authorization/error path.
6. Update Wiki/docs/config reference in the same change.
7. Run formatting, lint, type-check and relevant tests. Report changed files, commands executed, unresolved risks and any issue intentionally deferred.
