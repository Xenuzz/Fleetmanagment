---
name: design-qa
description: Audit a completed screen or flow against DeepBlue Liquid Glass, responsiveness and accessibility.
---
# Design QA

Use the reference images and design tokens as the baseline. Inspect desktop, tablet and phone sizes; keyboard/focus flow; touch targets; modal/sheet/popover behavior; reduced motion; contrast; loading/empty/error/permission states; and visual consistency. Use Playwright screenshots where applicable. Return blocking issues first, then polish issues, with exact component/token changes.
