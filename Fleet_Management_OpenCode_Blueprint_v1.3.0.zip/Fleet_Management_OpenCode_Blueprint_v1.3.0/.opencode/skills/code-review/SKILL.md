---
name: code-review
description: Review a Fleet Management change for correctness, regressions, architecture, security, tests and documentation.
---
# Code Review
Review the diff plus directly affected code. Rank findings: BLOCKER, HIGH, MEDIUM, LOW. Check module ownership, data integrity, authorization/tenancy, audit, concurrency, API contracts, Android/offline effects, DMS/storage safety, settings rules, tests, migration safety and docs. Give exact file/line evidence when possible. Do not modify files unless explicitly asked.
