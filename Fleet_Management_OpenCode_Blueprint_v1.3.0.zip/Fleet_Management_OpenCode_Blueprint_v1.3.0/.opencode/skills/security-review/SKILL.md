---
name: security-review
description: Threat-model and review changes involving identity, authorization, uploads, documents, storage, plugins or external integrations.
---
# Security Review
Check broken object authorization, organization/site leakage, privilege escalation, upload/MIME/path attacks, SSRF, injection, XSS/CSRF/CORS/CSP, secret exposure, OAuth/OIDC/SAML/LDAP assumptions, OCR/import trust boundaries, audit gaps, retention, download controls, plugin capabilities and storage migration safety. Give exploit path, impact, and concrete remediation.
