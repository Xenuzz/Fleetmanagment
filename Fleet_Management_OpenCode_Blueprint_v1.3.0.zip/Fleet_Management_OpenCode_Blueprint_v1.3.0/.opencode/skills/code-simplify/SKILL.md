---
name: code-simplify
description: Simplify freshly changed code without weakening behavior, tests, security or architecture.
---
# Code Simplification
Inspect only the changed area and nearby abstractions. Remove duplication, dead indirection, needless wrappers and over-generalization. Preserve public contracts, behavior, audit/security checks and test coverage. Prefer clear domain names and existing shared primitives. Re-run relevant tests after simplification.
