---
description: Validate the Fleet Management v1.3.0 blueprint and propose the first implementation phase without coding.
agent: plan
---
You are starting the Fleet Management project from the OpenCode Blueprint v1.3.0.

Do not implement product code in this command.

1. Confirm that `AGENTS.md`, `opencode.json`, project context, `.opencode/rules`, skills, agents, docs, config schema and the DeepBlue design kit are present and readable.
2. Read the core specifications: `docs/00_PRODUCT_SCOPE.md`, `01_SYSTEM_ARCHITECTURE.md`, `02_MODULES_AND_WORKFLOWS.md`, `03_DATA_MODEL.md`, `05_SECURITY_IDENTITY_PRIVACY.md`, `06_DESIGN_UI_UX.md`, `10_TESTING_AND_ACCEPTANCE.md`, `21_REQUIREMENT_TRACEABILITY.md`, `22_DOCUMENT_MANAGEMENT_SYSTEM.md`, `23_ADMIN_SETTINGS_SYSTEM.md`, plus `config/system_config.json` and schema.
3. Verify coverage of vehicles, digital registration certificate, DMS/storage, workshop/parts/service, bookings, driver-license OCR/eligibility, trip/work-time, notifications, settings, RBAC/SSO/AD, plugins, Web/Windows/Android, deployment, CI/CD and documentation.
4. Classify each main area as complete / partial / missing / contradictory.
5. Identify architecture, security, data-integrity, Android/offline, DMS/storage and settings risks.
6. Propose the smallest sensible first implementation phase with acceptance criteria and dependencies.
7. Report which built-in tools, project skills, subagents, LSP or MCPs you actually used.

Output exactly these sections:
1. Loaded project context
2. Architecture understood
3. Modules understood
4. Requirement coverage
5. Missing/partial specifications
6. Contradictions
7. Architecture risks
8. Security risks
9. Data/DMS/Storage risks
10. Android/offline risks
11. Settings/admin risks
12. Recommended pre-development corrections
13. Proposed first implementation phase
14. Tools/skills/agents/MCPs actually used
15. STOP – implementation approval required

Stop after the report.
