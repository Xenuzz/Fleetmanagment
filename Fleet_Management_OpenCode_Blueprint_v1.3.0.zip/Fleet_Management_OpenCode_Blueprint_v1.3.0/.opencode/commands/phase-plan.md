---
description: Plan one approved implementation phase without changing product code.
agent: plan
---
Read the relevant requirements, architecture, data, security, design, testing, DMS/settings documents and existing implementation for the requested phase: $ARGUMENTS

Produce: scope, ownership, dependencies, DB/migrations, API/contracts, permissions/audit, jobs/events, Web/Windows/Android impacts, offline/sync impacts, config/settings, tests, docs, risks, acceptance criteria, and ordered implementation steps. Do not edit product code.
