---
description: Review current changes using project review and security standards.
agent: plan
---
Review the current git diff and affected code. Load the `code-review` and `security-review` skills. Delegate to the relevant database, security, Android or design subagents when their domains are affected. Do not modify files. Return findings by severity with evidence and a pass/fail release recommendation.
