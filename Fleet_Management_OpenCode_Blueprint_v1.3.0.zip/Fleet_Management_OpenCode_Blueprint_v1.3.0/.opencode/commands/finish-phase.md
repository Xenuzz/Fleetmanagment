---
description: Run the completion gate for an implementation phase.
agent: build
---
For the completed phase described by $ARGUMENTS, load `code-review`, `code-simplify`, `security-review`, `docs-sync` and `release-check` as applicable. Run formatter, lint, type-check, targeted unit/integration/contract/E2E tests, migration checks and documentation/traceability checks. Do not push or publish. Report failures before proposing completion.
