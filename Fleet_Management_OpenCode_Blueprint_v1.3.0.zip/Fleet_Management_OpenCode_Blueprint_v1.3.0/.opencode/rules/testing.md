# Testing rules

- Unit test domain rules and calculations.
- Integration test PostgreSQL constraints, transactions, outbox/jobs, storage adapters and Keycloak authorization boundaries.
- Contract test OpenAPI-generated clients and version compatibility.
- Playwright covers critical web/desktop user journeys and visual regressions.
- Android instrumentation tests cover first-login, uploads, booking handover/return, offline queue and push/deep-link flows.
- Security tests cover broken-object authorization, upload attacks, role/site leakage, token misuse and plugin capability boundaries.
- Test booking races with concurrent requests, not only sequential happy paths.
- OCR tests use redacted/synthetic fixtures and assert field confidence/review behavior.
- CI must fail on lint, formatting, type errors, test failures, broken migrations or generated-contract drift.
