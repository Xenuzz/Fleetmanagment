# Security rules

- Authentication is delegated to Keycloak/identity providers; application authorization remains in the API.
- Permission checks use organization/site/resource context; never trust role names alone.
- All document download endpoints require authorization and generate audit records for sensitive classes.
- Uploads: magic-byte/MIME validation, size limits, randomized storage keys, SHA-256, EXIF stripping when applicable, optional malware scan, no executable serving.
- Never place access tokens, passwords, signing keys or connection strings in source, logs, fixtures, screenshots or issue text.
- Apply CSRF protections where cookie auth is used, strict CORS, CSP, secure headers and rate limits.
- Normalize/validate OCR, CSV/XLSX imports and plugin payloads as hostile input.
- Product plugins get capability-scoped credentials and network-deny by default.
- Security-sensitive actions require immutable audit events with actor, target, before/after summary, request correlation and source.
