# Architecture rules

- Keep the core as a modular monolith until measured load or organizational boundaries justify extraction.
- A domain module owns its tables, invariants, application services and events.
- Other modules may read/write only through documented module contracts. Do not import another module's Prisma repository.
- Use UUIDv7 or equivalent sortable opaque IDs consistently.
- All mutable aggregates carry optimistic concurrency/version metadata where concurrent editing is plausible.
- Use transactional outbox for reliable domain-event publication.
- Use idempotency keys for externally retryable commands and mobile synchronization.
- Background jobs must be retry-safe and observable.
- OCR is isolated because it has different runtime/dependency characteristics and processes untrusted binary input.
- The web app and desktop shell share the same frontend package; platform-specific adapters sit behind interfaces.
- Android shares API contracts and design semantics, not UI implementation code.
