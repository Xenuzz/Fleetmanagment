# Database rules

- PostgreSQL is authoritative; Prisma is the application ORM.
- Use explicit migrations committed to source control. Never use schema push in production.
- Model organization/site tenancy explicitly; every tenant-scoped query must carry its scope.
- Add database constraints for uniqueness, state invariants and booking overlap protection where PostgreSQL supports them.
- Money uses decimal/fixed precision plus ISO currency, never floating point.
- Distances, odometer, engine hours and quantities use explicit units and precision.
- Store timestamps as UTC and retain the originating time zone where legal/business meaning depends on it.
- Soft deletion is not a substitute for retention/deletion policy; sensitive data lifecycle is explicit.
- Audit/event tables are append-only from application code.
