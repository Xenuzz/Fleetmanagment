# Design rules

- Read and follow the design kit before creating or changing UI.
- Use semantic design tokens; no raw hex/radius/spacing values in feature components unless adding a documented token.
- Default background is near-black navy (`#06101E`); primary accent is electric blue (`#2E7CFF`) per the supplied kit.
- Typical card radius is 26px, hero 30px, floating navigation/modal 34px; translate to Android dp using shared semantic names.
- Glass blur is selective, never applied to every surface; clarity beats visual effect.
- Popovers/dialogs/sheets must preserve focus, escape/back behavior and reduced-motion alternatives.
- Responsive breakpoints must include phone, tablet, laptop and wide desktop. Windows desktop must remain usable at 1280x720 and common DPI scaling.
- Every screen has loading, empty, error, permission-denied and offline/degraded states where applicable.
- Charts must remain readable without relying on color alone.
