# Documentation rules

- Documentation is part of the implementation, not a final cleanup step.
- Keep operator docs, admin docs, user docs and developer/plugin docs separate.
- Every screen and every setting needs a Wiki entry.
- Configuration examples must use safe fake values.
- Upgrade notes list migrations, breaking changes, required manual steps and rollback considerations.
- Architecture decisions that materially constrain future development get an ADR.
- Generated OpenAPI/reference docs may be automated, but conceptual docs must explain behavior and constraints.
