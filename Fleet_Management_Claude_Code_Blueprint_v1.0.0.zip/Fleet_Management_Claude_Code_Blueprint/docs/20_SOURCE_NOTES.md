# 20 – External Source Notes

These external sources are implementation references, not vendored specifications. Re-check them during implementation because software documentation and law can change.

## Claude / Claude Code
- Claude Code plugins: https://code.claude.com/docs/en/discover-plugins
- Claude Code plugin reference: https://code.claude.com/docs/en/plugins-reference
- Claude Code settings: https://code.claude.com/docs/en/settings
- Official plugin repository: https://github.com/anthropics/claude-plugins-official
- Claude Projects / project knowledge: https://support.claude.com/en/articles/9519177-how-can-i-create-and-manage-projects

## German vehicle registration
- FZV Anlage 6 – Zulassungsbescheinigung Teil I: https://www.gesetze-im-internet.de/fzv_2023/anlage_6.html

## Source discipline
- Pin dependencies, but re-check security advisories and current versions during implementation.
- Legal/regulated features (driver hours, retention, license verification) require explicit rule-pack/version documentation and legal validation before being represented as compliance decisions.
