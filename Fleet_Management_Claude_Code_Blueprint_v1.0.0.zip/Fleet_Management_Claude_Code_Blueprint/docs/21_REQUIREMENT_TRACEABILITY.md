# 21 – Requirement Traceability

This matrix prevents requirements from disappearing during implementation. Claude Code must keep it current and link implemented epics/issues/PRs to each row.

| Requirement | Primary specification | Planned phase | Mandatory verification |
|---|---|---:|---|
| Complete vehicle master/technical/equipment data | 02, 03, 18 | 2 | CRUD + validation + history tests |
| Vehicle images/documents | 02, 03, 05 | 2 | authorization/upload/security tests |
| Digital registration front/back/front-only | 16, 18 | 3 | OCR fixtures + visual/E2E tests |
| Tooltips for registration fields | 16 | 3 | metadata coverage test |
| Workshop orders/open issues/tasks/checklists | 02, 03 | 6 | lifecycle + checklist E2E |
| Parts catalog + compatibility | 02, 03 | 6 | fitment/integrity tests |
| Part fit/ease/installation/general experience | 02, 03 | 6 | rating validation + history |
| Local users | 01, 05 | 1 | Keycloak local login E2E |
| SSO OIDC/SAML | 01, 05 | 1 | provider integration tests/docs |
| Windows domain / Active Directory | 05, 07 | 1/13 | LDAP federation test guide |
| Roles/permissions | 05, 17 | 1 | table-driven authorization suite |
| Multiple sites/organization | 02, 03 | 1 | cross-site isolation tests |
| Logo/name/colors/branding | 06, 14 | 1+ | token/runtime settings tests |
| Popup-heavy Liquid Glass UX | 06 + design kit | all | visual/accessibility QA |
| Notifications | 02, 04 | 10 | retry/delivery/preference tests |
| Vehicle bookings | 02, 03 | 5 | concurrency overlap tests |
| Email reminders + calendar | 02, 04 | 5/10 | SMTP + ICS tests |
| Approval/availability/status | 02, 03 | 5 | state/permission tests |
| First-login setup wizard | 02 | 4 | resumable onboarding E2E |
| Driver-license OCR/classes/expiry | 02, 05 | 4 | OCR + review-state tests |
| Eligible-driver filtering | 02, 03 | 5 | server validation + expiry edge cases |
| Service intervals/reminders | 02, 03 | 7 | date/km/hour whichever-first suite |
| Fuel receipts | 02 | 8 | upload/OCR/review tests |
| Workshop invoices/attachments | 02 | 6/8 | authorization/accounting tests |
| Trip log/routes/jobs | 02, 03 | 9 | chronology + correction audit |
| Working hours/breaks | 02, 03 | 9 | deterministic calculation suite |
| PDF/XLSX/timesheets | 02, 08 | 9 | snapshot/export validation |
| Docker deployment | 07 | 13 | clean-host installation test |
| Native Linux deployment | 07 | 13 | systemd installer/upgrade test |
| Native Windows Server deployment | 07 | 13 | PowerShell/service test |
| Web UI | 01, 06, 18 | all | browser/E2E/parity matrix |
| Windows desktop app | 01, 06, 07 | all/13 | Windows build + native integration |
| Android phone/tablet | 01, 06, 18 | all/8 | adaptive UI + instrumentation |
| Android handover/photos/km/logbook | 02, 18 | 5/8/9 | offline/online E2E |
| Android notifications | 02 | 10 | FCM/deep-link test |
| GitHub repository hygiene | 08, 19 | 0+ | branch/PR/CI checks |
| GitHub Actions Android artifact | 08 | 0/13 | APK artifact on CI |
| Complete Wiki | 12 | all/13 | link/content coverage check |
| Product plugin system | 09 | 11 | capability/isolation tests |
| Settings/admin dashboard | 14, 18 | 12 | permission/effective-value tests |
| Project knowledge text | claude-project/PROJECT_KNOWLEDGE.md | setup | pasted/uploaded to Claude project |
| Custom knowledge/instructions text | claude-project/CUSTOM_KNOWLEDGE.md | setup | pasted into project instructions |
| Claude Code repository context | CLAUDE.md + .claude | setup | `/memory`/settings verification |
| Central configuration file | config/system_config.json | 0 | JSON Schema + startup validation |

No row may be deleted because implementation is difficult. If scope changes, record the decision and reason in an ADR and in this matrix.
