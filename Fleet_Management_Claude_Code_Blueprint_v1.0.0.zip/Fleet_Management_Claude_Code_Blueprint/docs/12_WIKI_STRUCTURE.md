# 12 – GitHub Wiki Structure

`docs/wiki/` is the source of truth and should be synchronized to GitHub Wiki.

## Home

- product overview
- architecture image
- supported platforms
- quick links

## Installation

- Docker quick start
- Linux native install
- Windows Server native install
- reverse proxy/TLS
- upgrades
- backup/restore

## Initial setup

- first admin
- company profile
- sites
- branding
- email
- Keycloak
- Active Directory
- Entra/OIDC/SAML

## Users and permissions

- onboarding
- roles
- permission matrix
- site scopes
- local users
- SSO users

## Vehicle management

- create/edit vehicle
- technical data
- equipment
- images
- status
- odometer
- documents

## Digital registration certificate

- upload
- OCR
- front/rear view
- tooltips
- corrections
- field catalogue
- security/privacy notes

## Drivers and licenses

- upload
- verification
- class mapping
- expiry
- booking eligibility
- manual overrides

## Bookings

- request
- approval
- calendar
- conflicts
- driver selection
- reminders
- handover
- return

## Workshop

- orders
- tasks/checklists
- damages
- parts
- labor
- invoices
- completion

## Parts

- part creation
- compatibility
- ratings
- suppliers

## Service intervals

- templates
- date/km/hours
- reminders
- escalation
- auto work orders

## Expenses/documents

- fuel receipts
- invoices
- OCR review

## Trips and time

- trip log
- activities
- breaks
- timesheets
- exports
- rule packs

## Reports

- report catalogue
- permissions
- filters
- PDF/XLSX

## Notifications

- channels
- preferences
- SMTP
- Android push
- desktop
- troubleshooting

## Admin

- system dashboard
- health
- job queues
- storage
- OCR
- audit
- retention

## Configuration reference

Every key in `config/system_config.json` must be documented with:

- type
- default
- allowed values
- restart required yes/no
- security implications

## API

- auth
- versioning
- errors
- endpoints
- OpenAPI download
- WebSocket events

## Plugin development

- architecture
- quick start
- manifest
- permissions
- events
- API
- UI slots
- example plugin
- packaging
- versioning
- security

## Development

- repo layout
- local setup
- tests
- migrations
- coding standards
- design system
- adding a module
- adding a setting
- adding a permission
- adding a report
- adding a document parser

## Troubleshooting

- login
- LDAP/AD
- email
- OCR
- file storage
- Android sync
- Windows desktop
- service startup
- migrations

