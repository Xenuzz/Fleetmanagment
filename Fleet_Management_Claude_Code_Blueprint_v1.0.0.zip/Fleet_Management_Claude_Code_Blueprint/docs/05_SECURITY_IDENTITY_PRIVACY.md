# 05 – Security, Identity and Privacy

## 1. Security model

This platform processes:

- identity data
- driver-license documents
- vehicle holder data
- movement/trip data
- potentially employee work-time data
- invoices and financial data

Therefore security controls are core architecture, not optional polish.

## 2. Authentication

Default identity provider: Keycloak.

Supported identity sources:

- local Keycloak users
- Microsoft Active Directory via LDAP federation
- OIDC identity providers
- SAML identity providers
- Microsoft Entra ID through OIDC/SAML brokering

Application clients use OIDC.

## 3. RBAC model

Recommended built-in roles:

- SYSTEM_ADMIN
- ORGANIZATION_ADMIN
- SITE_ADMIN
- FLEET_MANAGER
- DISPATCHER
- WORKSHOP_MANAGER
- MECHANIC
- DRIVER
- AUDITOR
- READ_ONLY

Roles are templates. Final authorization is permission-based.

### Permission namespace

Examples:

- `organization.read`
- `organization.write`
- `sites.manage`
- `users.read`
- `users.manage`
- `roles.manage`
- `vehicles.read`
- `vehicles.write`
- `vehicles.status.change`
- `vehicle_documents.read`
- `vehicle_documents.manage`
- `driver_licenses.read`
- `driver_licenses.verify`
- `driver_licenses.override`
- `bookings.create`
- `bookings.read.all`
- `bookings.approve`
- `bookings.cancel.any`
- `handovers.perform`
- `workshop.orders.read`
- `workshop.orders.manage`
- `workshop.tasks.complete`
- `parts.manage`
- `service.manage`
- `expenses.read`
- `expenses.manage`
- `trips.read.self`
- `trips.read.all`
- `timesheets.read.self`
- `timesheets.read.all`
- `reports.generate`
- `audit.read`
- `plugins.manage`
- `system.manage`

Every permission decision also evaluates organization/site scope.

## 4. Sensitive data separation

Driver-license images and detailed fields are not returned in general user endpoints.

Use dedicated DTOs:

- public driver availability summary
- restricted license summary
- privileged license detail

Booking eligibility normally needs only:

- eligible yes/no
- reason category safe for the requester

It does not need to expose the full license image or document number.

## 5. OCR trust model

OCR extraction has states:

- PROCESSING
- PARSED
- AUTO_VALIDATED
- REVIEW_REQUIRED
- VERIFIED
- REJECTED

Per-field state:

- OK
- LOW_CONFIDENCE
- INVALID_FORMAT
- CONFLICT
- MISSING
- MANUALLY_CORRECTED

Automatic OCR is a data extraction tool, not a guarantee of document authenticity.

The organization config decides whether booking eligibility accepts:

- VERIFIED only
- VERIFIED or AUTO_VALIDATED

Default recommended policy: VERIFIED for regulated/heavy vehicle classes; configurable for normal passenger-car use.

## 6. Document security

Required controls:

- content length limits
- allowlisted MIME types
- magic-byte validation
- decode/re-encode uploaded images before presentation where possible
- strip unnecessary EXIF metadata
- SVG uploads disabled by default
- malware scan provider interface
- quarantined state until scan completes if scanner is configured
- no user-supplied filename used as filesystem path
- random object keys
- SHA-256 checksum

## 7. Secrets

Never store secrets in:

- `system_config.json`
- Git
- application database in plaintext
- logs

Secrets come from environment variables or OS secret store and are resolved centrally.

Examples:

- `DATABASE_URL`
- `OIDC_CLIENT_SECRET`
- `SMTP_PASSWORD`
- `S3_SECRET_KEY`
- `FCM_SERVICE_ACCOUNT_JSON`
- `APP_DATA_ENCRYPTION_KEY`

## 8. Encryption

- TLS required outside explicit localhost development mode
- database disk encryption handled by server/storage platform
- sensitive selected application fields can use application-level envelope encryption
- backups encrypted before off-host storage
- Android secrets in Keystore-backed storage
- desktop secrets in OS credential vault through Tauri plugin/secure integration

## 9. Audit

Audit all sensitive actions:

- login/account linkage events where appropriate
- user/role changes
- license view/download by privileged users if policy requires
- license verification/rejection
- booking approval/override
- vehicle status override
- odometer correction
- workshop reopen/close
- invoice edits
- plugin permission changes
- settings changes
- retention/deletion actions

Audit records are append-only through application APIs.

## 10. CSRF/XSS/CSP

Web:

- bearer-token/OIDC design must avoid unsafe token exposure
- strict CSP
- no unsafe inline script unless generated nonce policy requires it
- sanitize rich text; prefer plain text/controlled markdown
- encode all user content by default
- protect any cookie-backed endpoints with SameSite/CSRF measures

## 11. API security

- rate limiting for login-adjacent/public endpoints
- request size limits
- schema validation
- permission checks at service boundary
- parameterized queries/ORM
- idempotency where duplicate actions are dangerous
- optimistic concurrency for sensitive edits
- consistent 404/403 behavior to avoid existence leaks where relevant

## 12. Plugin security

Product plugins must not be loaded as arbitrary code into the core API process by default.

Preferred model:

- out-of-process plugin worker/container
- scoped plugin token
- manifest-declared capabilities
- event subscriptions
- HTTP/RPC API
- optional iframe UI with CSP sandbox

Plugin cannot:

- read core database directly
- read raw secrets
- access arbitrary files
- subscribe to sensitive events without permission

## 13. Privacy and retention

Configurable retention categories:

- original license documents
- expired/replaced license images
- vehicle documents
- handover photos
- invoices
- trip logs
- work-time records
- audit logs
- generated reports

Retention must support legal/company policy without embedding one unchangeable period in code.

Deletion pipeline:

1. mark scheduled deletion
2. verify legal hold / active reference
3. delete object bytes
4. redact/remove metadata according to policy
5. write audit event

## 14. Backups

Backup set includes:

- PostgreSQL dump/base backup strategy
- file storage
- Keycloak realm/config export where appropriate
- system_config
- version metadata

Restore must be tested in CI/staging procedure, not only documented.

## 15. Security CI gates

- dependency audit
- Semgrep or equivalent SAST
- secret scanning
- CodeQL where available
- container image scan
- SBOM
- test for authorization matrix
- test for horizontal organization/site access
- test for file download access
- test for booking override permissions

