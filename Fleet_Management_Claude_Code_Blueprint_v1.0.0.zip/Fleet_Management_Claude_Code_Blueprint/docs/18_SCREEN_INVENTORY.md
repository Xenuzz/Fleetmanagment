# 18 – Screen Inventory

## Shared shell
Login/SSO, first-login wizard, global search, command palette, notification center, profile, site switcher, help, offline/sync indicator, permission error and global settings navigation.

## Dashboard
Role-aware KPI cards, upcoming bookings, vehicles unavailable, service due/overdue, open workshop tasks, license expiries, alerts, quick actions and recent activity.

## Vehicles
Catalog/list/grid, map/location where applicable, vehicle detail overview, technical data, equipment, status/history, media gallery, documents, digital registration view, service timeline, workshop history, booking history, trips, costs and settings/custom fields.

## Booking
Availability search, calendar, booking wizard, approval inbox, booking detail, handover wizard, return wizard, conflict/eligibility dialog and booking policy admin.

## Drivers
Driver catalog, driver detail, license summary, original-document restricted viewer, OCR/review panel, class/expiry timeline and verifier queue.

## Workshop/parts/service
Workshop board, work-order detail, task/checklist view, time/parts/document panels, QA closeout, issue/backlog list, parts catalog, part detail/fitment experience, service-plan editor, due-service dashboard.

## Trips/work time
Trip list/detail, active trip workflow, activity timeline, break/work-time entry, correction dialog, driver timesheet, export/report wizard.

## Documents/costs
Fuel receipt inbox, invoice inbox, OCR review queue, cost ledger/report, document detail with audit access.

## Administration
Organization/branding, sites, users, roles/permissions, identity/SSO/LDAP, notification templates, SMTP/push, storage/OCR, feature flags, retention/audit, plugin manager, system health/jobs, configuration effective-value inspector and audit log.

Every screen must define web desktop, tablet and phone behavior; Android uses native screen/adaptive-pane patterns while preserving feature semantics.
