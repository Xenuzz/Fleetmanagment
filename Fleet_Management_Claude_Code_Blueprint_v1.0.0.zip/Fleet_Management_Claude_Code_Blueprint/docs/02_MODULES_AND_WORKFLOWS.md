# 02 – Modules and Workflows

## 1. Module boundary rules

Each backend domain module owns:

- its entities/data-access methods
- its application services/use cases
- its authorization checks for domain actions
- its REST handlers
- its event publications
- its tests

Cross-module reads occur through explicit services/query interfaces, not direct repository imports whenever business semantics are involved.

## 2. Core modules

### 2.1 organization

Responsibilities:

- organizations
- sites
- branding
- organization preferences
- site policies
- site contacts

Important rule: every business entity carries `organization_id`; site-owned entities also carry `site_id` when meaningful.

### 2.2 identity

Responsibilities:

- OIDC subject linkage
- local application profile
- onboarding state
- identity-provider metadata
- synchronization of key display fields from IdP where configured

No passwords.

### 2.3 authorization

Responsibilities:

- roles
- permissions
- role assignments
- site-scoped memberships
- policy evaluation

### 2.4 vehicles

Responsibilities:

- fleet records
- technical specifications
- equipment
- status
- odometer/hour-meter readings
- photos
- lifecycle
- vehicle categories
- custom fields

### 2.5 vehicle-documents

Responsibilities:

- registration certificate
- insurance documents
- inspection documents
- leasing/ownership files
- document type catalogue
- OCR extraction association

### 2.6 drivers

Responsibilities:

- driver profile
- license documents
- license classes
- restrictions
- verification
- eligibility query

### 2.7 bookings

Responsibilities:

- request/approval
- conflicts
- vehicle availability
- driver eligibility integration
- reminders
- booking calendar

### 2.8 handovers

Responsibilities:

- pickup/return process
- checklists
- photos
- mileage/fuel/charge
- discrepancy/damage links

### 2.9 damages

Recommended separate module even if not explicitly required because handovers and workshop depend on it.

Responsibilities:

- damage records
- severity
- location on vehicle
- photos
- discovered during handover/workshop
- repair state
- related workshop order

### 2.10 workshop

Responsibilities:

- work orders
- tasks
- labor entries
- diagnostic notes
- external/internal workshop
- order status
- vehicle availability blocks

### 2.11 parts

Responsibilities:

- parts catalogue
- suppliers
- compatibility
- part reviews
- work-order part consumption
- optional stock ledger later

### 2.12 service

Responsibilities:

- interval templates
- per-vehicle schedules
- due calculation
- reminders
- automatic work-order creation
- statutory/operational inspection schedules

### 2.13 expenses

Responsibilities:

- fuel receipts
- invoices
- generic vehicle expenses
- OCR mapping
- cost allocation

### 2.14 trips

Responsibilities:

- trip log
- route/purpose
- odometer consistency
- booking linkage
- driver linkage

### 2.15 time-tracking

Responsibilities:

- shifts
- activity segments
- breaks
- calculated durations
- timesheet periods
- legal rule-pack evaluation interface

### 2.16 notifications

Responsibilities:

- notification templates
- notification records
- preferences
- delivery jobs
- read/unread state
- escalation

### 2.17 reporting

Responsibilities:

- report definitions
- export requests
- job execution
- generated-file retention

### 2.18 documents

Generic technical module:

- file metadata
- access checks
- signed download URLs where applicable
- thumbnails
- virus scan result
- checksum
- retention

### 2.19 OCR

Technical module:

- OCR request
- provider result
- extraction schema
- confidence
- review state
- retry/dead-letter

### 2.20 audit

- append-only audit trail
- before/after summaries
- actor
- impersonation/admin context
- correlation ID

### 2.21 plugins

- plugin catalog
- install state
- capabilities
- settings
- plugin auth
- event dispatch
- health checks

### 2.22 system

- system info
- health
- version
- job statistics
- configuration status
- update information

## 3. End-to-end workflows

### 3.1 First user login / driver onboarding

1. User authenticates via Keycloak.
2. API creates/updates application profile from OIDC claims.
3. If onboarding is incomplete, all normal navigation is restricted to onboarding-safe routes.
4. Wizard collects required profile fields.
5. If role/policy allows or requires driving, wizard requests license front/back.
6. Images upload to document service.
7. OCR job runs.
8. OCR extracts document fields and license classes.
9. Validation engine evaluates dates and confidence.
10. User reviews extracted values.
11. If policy requires human verification, status becomes `REVIEW_REQUIRED` and authorized staff receive a task.
12. Once required onboarding steps are satisfied, profile becomes active for normal use.

### 3.2 Vehicle registration certificate upload

1. Fleet manager selects vehicle.
2. Uploads front/back images or multi-page PDF.
3. System detects DE ZB I template.
4. OCR parses all visible supported fields.
5. Extraction screen shows source crop next to normalized value.
6. Low-confidence values are highlighted.
7. User accepts/corrects.
8. Accepted values can update vehicle technical data via an explicit diff review.
9. Digital certificate view becomes available.
10. Original and extraction revision remain auditable.

Important: OCR must never silently overwrite an already-maintained vehicle value with a conflicting value.

### 3.3 Booking request

1. User chooses time range and site.
2. API returns available vehicles matching filters.
3. User selects vehicle.
4. System computes required driver requirements.
5. API returns eligible drivers.
6. User selects self or another eligible driver according to permission.
7. Server validates booking conflicts and eligibility.
8. Booking enters REQUESTED or APPROVED according to policy.
9. Approvers are notified when required.
10. On approval, calendar invite and reminders are scheduled.

### 3.4 Booking handover

1. User opens booking on Android/Web/Desktop.
2. API verifies booking status, time tolerance and driver eligibility again.
3. Checklist loads from vehicle-class template.
4. User records mileage, fuel/charge and photos.
5. Existing damage list is shown.
6. New discrepancies can create damage records.
7. Completion changes booking to IN_USE and vehicle to derived IN_USE status.
8. Audit event and notifications are created.

### 3.5 Booking return

1. Return checklist.
2. Mileage/fuel/charge/photos.
3. Optional trip completion.
4. New damage/cleanliness issue.
5. Vehicle returns to AVAILABLE only if no workshop/block condition exists.
6. Booking becomes RETURNED then COMPLETED after policy-defined checks.

### 3.6 Workshop order

1. Order created manually, from damage, or from service interval.
2. Vehicle may be blocked immediately or from planned date.
3. Tasks are added.
4. Required parts are added/reserved.
5. Mechanics complete checklist tasks.
6. Labor and parts are recorded.
7. Invoice/attachments can be added.
8. QA task is completed if configured.
9. Order closes.
10. Related service interval completion resets next due values.
11. Vehicle block is removed only when no other blocking condition remains.

### 3.7 Service calculation

For every schedule:

- compute next date due
- compute next mileage due
- compute next hour due
- compute most urgent trigger
- calculate warning status

Status:

- OK
- DUE_SOON
- DUE
- OVERDUE
- SUSPENDED

Recalculation triggers:

- new odometer reading
- new operating-hour reading
- service completion
- schedule edit
- nightly background job

### 3.8 Receipt OCR

1. Upload receipt.
2. OCR identifies vendor/date/amount/line values.
3. Validation checks arithmetic.
4. User selects/accepts vehicle.
5. If odometer is extracted, outlier validation runs against last known reading.
6. Accepted receipt creates expense/fuel record.
7. Original file remains attached.

### 3.9 Trip and timesheet

1. Trip starts or is created from booking.
2. Driver logs start odometer/time/location.
3. Activity segments can be recorded.
4. Breaks are distinct segments.
5. Trip ends with end odometer/time.
6. Server validates chronology and distance.
7. Timesheet aggregates selected date period.
8. Optional legal rule-pack evaluator creates warnings.
9. PDF/XLSX export can be generated.

## 4. Cross-cutting invariants

- organization boundary must always be enforced server-side
- site scope must always be enforced server-side
- permissions must be checked in application services, not only routes
- a vehicle cannot have decreasing accepted odometer readings unless an authorized correction event exists
- booking conflicts are blocked in the database and service layer
- a driver must be revalidated at handover time
- file access always goes through document authorization
- all manual overrides require a reason where policy marks them sensitive
- all sensitive data changes create audit events

