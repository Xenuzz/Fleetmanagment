# 03 – Core Data Model

This is the logical model. Claude Code should translate it into Prisma models plus raw PostgreSQL migrations where required.

## 1. Organization and identity

### Organization

- id UUID
- name
- legal_name
- slug
- default_locale
- timezone
- active
- branding_json
- created_at
- updated_at

### Site

- id
- organization_id
- name
- code
- address fields
- timezone override optional
- contact fields
- active

### UserProfile

- id
- organization_id
- identity_subject
- email
- display_name
- first_name
- last_name
- phone optional
- preferred_locale
- home_site_id optional
- onboarding_status
- active
- last_login_at

Unique: `(organization_id, identity_subject)`.

### Role

- id
- organization_id nullable for built-in role templates
- key
- name
- description
- system_role boolean

### Permission

- key primary semantic identifier
- module
- action
- description

### RolePermission

- role_id
- permission_key

### UserRoleAssignment

- id
- user_id
- role_id
- scope_type: ORGANIZATION | SITE
- site_id nullable
- valid_from optional
- valid_until optional

## 2. Vehicle

### Vehicle

- id
- organization_id
- site_id
- fleet_number
- plate
- vin
- make
- model
- variant
- version
- model_year
- first_registration_date
- vehicle_class_id
- body_type
- fuel_type
- transmission
- drivetrain
- color
- odometer_current
- operating_hours_current optional
- status_manual
- availability_override optional
- active
- acquisition_type
- acquisition_date optional
- acquisition_cost optional
- cost_center optional
- owner_name optional
- lease_end optional
- notes
- created_at
- updated_at
- row_version

Indexes:

- organization/site
- plate normalized
- VIN
- fleet number
- make/model

### VehicleTechnicalSpec

One-to-one or structured tables for common fields plus `extra_json` for uncommon regional values.

Fields include:

- engine_displacement_cc
- power_kw
- rated_rpm
- emissions_class
- co2_g_km
- length_mm
- width_mm
- height_mm
- curb_weight_kg
- technical_max_mass_kg
- registered_max_mass_kg
- tow_braked_kg
- tow_unbraked_kg
- support_load_kg
- seats
- standing_places
- max_speed_kmh
- axles
- driven_axles
- fuel_tank_liters optional
- battery_capacity_kwh optional

### VehicleAxleSpec

- vehicle_id
- axle_index
- technical_max_load_kg
- registered_max_load_kg
- tire_spec

### EquipmentDefinition

- id
- organization_id
- key
- name
- category
- description

### VehicleEquipment

- vehicle_id
- equipment_definition_id
- value_text optional
- installed_at optional
- removed_at optional
- notes

### VehicleStatusHistory

- id
- vehicle_id
- from_status
- to_status
- reason
- source_type
- source_id
- actor_user_id
- created_at

### OdometerReading

- id
- vehicle_id
- reading_km
- source_type: MANUAL | BOOKING_HANDOVER | BOOKING_RETURN | TRIP | FUEL | WORKSHOP | IMPORT
- source_id
- recorded_at
- actor_user_id
- correction_of_id optional
- accepted

## 3. Documents

### FileObject

- id
- organization_id
- storage_driver
- storage_key
- sha256
- original_filename
- mime_type
- size_bytes
- created_by
- created_at
- scan_status
- retention_until optional
- metadata_json

### EntityDocument

- id
- organization_id
- entity_type
- entity_id
- file_object_id
- document_type
- title
- valid_from optional
- valid_until optional
- confidentiality_level
- created_by
- created_at

### OcrJob

- id
- organization_id
- file_object_id
- document_type_expected optional
- status
- provider
- attempts
- error_code optional
- created_at
- completed_at optional

### OcrExtraction

- id
- ocr_job_id
- detected_document_type
- detected_side
- raw_text
- raw_result_json
- parser_version
- average_confidence
- review_status

### OcrField

- extraction_id
- field_key
- raw_value
- normalized_value
- confidence
- bounding_box_json
- validation_status
- corrected_value optional
- corrected_by optional
- corrected_at optional

### VehicleRegistrationCertificate

- id
- vehicle_id
- jurisdiction `DE`
- document_type `ZB1`
- template_version
- front_file_id optional
- back_file_id optional
- extraction_id optional
- issue_date optional
- verification_status
- created_at

### VehicleRegistrationField

- certificate_id
- field_key
- value_text
- source: OCR | MANUAL | VEHICLE
- confidence optional
- verified

## 4. Drivers and licenses

### DriverProfile

- user_id PK/FK
- employee_number optional
- driver_active
- default_site_id
- verification_policy_state
- notes restricted

### DriverLicense

- id
- driver_user_id
- jurisdiction
- document_number optional and protected
- issue_date optional
- document_expiry_date optional
- front_file_id
- back_file_id
- extraction_id optional
- status: UPLOADED | PROCESSING | AUTO_VALIDATED | REVIEW_REQUIRED | VERIFIED | REJECTED | EXPIRED | REPLACED
- verified_by optional
- verified_at optional
- replaced_by_id optional

### DriverLicenseClass

- id
- driver_license_id
- class_code
- valid_from optional
- valid_until optional
- restrictions_json
- source_confidence
- verification_status

### VehicleClass

- id
- organization_id nullable for built-ins
- code
- name
- description

### VehicleClassLicenseRequirement

- vehicle_class_id
- accepted_license_class
- match_mode
- valid_from optional
- policy_json

### DriverEligibilityOverride

- id
- booking_id
- driver_user_id
- reason
- approved_by
- created_at

## 5. Booking

### Booking

- id
- organization_id
- site_id
- vehicle_id
- requested_by
- driver_user_id
- start_at
- end_at
- start_site_id
- end_site_id optional
- purpose
- destination optional
- project_reference optional
- status
- approval_required
- approved_by optional
- approved_at optional
- rejected_by optional
- reject_reason optional
- cancellation_reason optional
- row_version
- created_at
- updated_at

### BookingApproval

- id
- booking_id
- step_order
- approver_role_key optional
- approver_user_id optional
- status
- decision_by optional
- decision_at optional
- reason optional

### BookingBlock

Generalized resource block for manual/workshop/service blocking.

- id
- vehicle_id
- start_at
- end_at
- type
- source_id optional
- reason
- active

### BookingHandover

- id
- booking_id
- type: OUT | RETURN
- performed_by
- performed_at
- odometer_km
- fuel_percent optional
- charge_percent optional
- cleanliness_status
- notes
- signature_file_id optional
- sync_client_id optional

### HandoverChecklistItemResult

- handover_id
- template_item_id
- state: OK | ISSUE | NOT_APPLICABLE
- note optional

### HandoverMedia

- handover_id
- file_object_id
- category
- caption optional

## 6. Damage

### Damage

- id
- vehicle_id
- discovered_at
- discovered_by
- source_type
- source_id
- area
- severity
- description
- status
- workshop_order_id optional

### DamageMedia

- damage_id
- file_object_id

## 7. Workshop, service and parts

### WorkshopOrder

- id
- organization_id
- site_id
- vehicle_id
- number
- title
- description
- diagnosis
- order_type
- priority
- status
- planned_start optional
- due_at optional
- started_at optional
- completed_at optional
- assigned_user_id optional
- assigned_team optional
- external_workshop_name optional
- source_service_schedule_id optional
- source_damage_id optional
- vehicle_blocking
- created_by
- created_at
- updated_at

### WorkshopTask

- id
- workshop_order_id
- position
- title
- description
- status
- required
- completed_by optional
- completed_at optional
- estimated_minutes optional
- actual_minutes optional

### WorkshopLaborEntry

- id
- workshop_order_id
- user_id
- started_at
- ended_at
- minutes
- description

### Part

- id
- organization_id
- manufacturer
- manufacturer_part_number
- oem_numbers_json
- name
- category
- description
- gtin optional
- active

### Supplier

- id
- organization_id
- name
- contact_json

### PartSupplier

- part_id
- supplier_id
- supplier_sku
- url optional
- last_price_net optional
- currency
- last_price_at optional

### PartCompatibility

- id
- part_id
- vehicle_class_id optional
- make optional
- model optional
- variant optional
- vin_pattern optional
- compatibility_status
- notes

### PartInstallationReview

- id
- part_id
- vehicle_id
- workshop_order_id optional
- fit_accuracy_rating 1..5
- installation_accuracy_rating 1..5
- installation_ease_rating 1..5
- overall_rating 1..5
- installation_minutes optional
- description
- author_user_id
- created_at

### WorkshopOrderPart

- workshop_order_id
- part_id
- quantity
- unit_cost_net optional
- supplier_id optional
- installed boolean
- note optional

### ServiceTemplate

- id
- organization_id
- name
- category
- interval_months optional
- interval_km optional
- interval_hours optional
- warning_days
- warning_km optional
- warning_hours optional
- escalation_days optional
- auto_create_workshop_order
- active

### VehicleServiceSchedule

- id
- vehicle_id
- service_template_id
- last_completed_at optional
- last_completed_odometer optional
- last_completed_hours optional
- next_due_at optional
- next_due_odometer optional
- next_due_hours optional
- status
- suspended_until optional

### ServiceCompletion

- id
- vehicle_service_schedule_id
- workshop_order_id optional
- completed_at
- odometer_km optional
- operating_hours optional
- note

## 8. Costs

### Expense

- id
- organization_id
- vehicle_id optional
- booking_id optional
- workshop_order_id optional
- type
- expense_date
- vendor
- net_amount optional
- tax_amount optional
- gross_amount
- currency
- cost_center optional
- invoice_id optional
- created_by

### FuelReceipt

- expense_id PK/FK
- liters optional
- unit_price optional
- fuel_type optional
- odometer_km optional
- station_name optional
- receipt_file_id
- extraction_id optional

### Invoice

- id
- organization_id
- vendor
- invoice_number
- invoice_date
- due_date optional
- net_amount optional
- tax_amount optional
- gross_amount
- currency
- file_object_id
- extraction_id optional
- status

### InvoiceLine

- id
- invoice_id
- description
- quantity optional
- unit_price_net optional
- tax_rate optional
- line_total optional
- part_id optional

## 9. Trips and time

### Trip

- id
- organization_id
- vehicle_id
- driver_user_id
- booking_id optional
- order_reference optional
- purpose
- classification optional
- start_at
- end_at optional
- start_odometer_km
- end_odometer_km optional
- start_location_json
- end_location_json optional
- distance_km computed/validated
- status
- notes

### TripActivity

- id
- trip_id
- activity_type: DRIVING | OTHER_WORK | BREAK | AVAILABILITY | REST | OTHER
- start_at
- end_at
- note optional

### Shift

- id
- driver_user_id
- start_at
- end_at optional
- site_id optional
- source

### ComplianceEvaluation

- id
- driver_user_id
- period_start
- period_end
- rule_pack_id
- result_json
- created_at

### RulePack

- id/key
- jurisdiction
- code
- version
- effective_from
- effective_until optional
- rules_json

## 10. Notifications

### Notification

- id
- organization_id
- recipient_user_id
- type
- severity
- title
- body
- action_url optional
- entity_type optional
- entity_id optional
- read_at optional
- created_at

### NotificationPreference

- user_id
- event_key
- in_app
- email
- push
- desktop
- reminder_offset_json

### DeliveryAttempt

- id
- notification_id
- channel
- status
- attempt
- provider_message_id optional
- error optional
- sent_at optional

### CalendarDelivery

- id
- booking_id
- recipient_user_id
- method: REQUEST | CANCEL
- sequence
- sent_at

## 11. Audit

### AuditEvent

- id UUID/ULID
- organization_id
- occurred_at
- actor_user_id optional
- actor_subject optional
- action
- entity_type
- entity_id
- site_id optional
- correlation_id
- ip_hash_or_address according to privacy policy
- user_agent optional
- reason optional
- before_json sanitized
- after_json sanitized
- metadata_json

Audit storage must never copy raw secrets or full authentication tokens.

## 12. Plugins

### PluginInstallation

- id
- organization_id nullable for system plugin
- plugin_key
- name
- version
- api_version
- status
- manifest_json
- installed_at
- enabled_at optional
- last_health_at optional
- health_status

### PluginPermissionGrant

- plugin_installation_id
- capability
- granted
- granted_by
- granted_at

### PluginSetting

- plugin_installation_id
- key
- value_encrypted_or_json
- secret boolean

## 13. Standard enums

Keep enums centralized and generated into clients where useful.

Never let clients invent string status values.

