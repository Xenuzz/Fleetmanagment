# 14 – Configuration Strategy

## 1. Rule

All non-secret system parameters belong in:

`config/system_config.json`

The main application code must not contain company-specific configuration.

## 2. Secrets

Secrets are referenced by environment-variable names from the central configuration layer.

Feature modules receive a validated runtime configuration object and do not call `process.env` directly.

## 3. Config sections

- meta
- deployment
- organization
- branding
- identity
- database
- storage
- files
- ocr
- bookings
- licenses
- workshop
- service
- trips
- notifications
- email
- push
- reports
- audit
- retention
- plugins
- observability
- features

## 4. Validation

- JSON Schema committed
- startup fails fast on invalid values
- unknown keys are warnings or errors according to strictness mode
- config schema has version
- migrations between config schema versions documented

## 5. Admin UI

Settings editable through admin UI are persisted in the application settings database with explicit precedence over deployment defaults only for keys marked runtime-editable.

Precedence:

1. hard security constraints / managed deployment policy
2. deployment `system_config.json`
3. organization setting overrides for allowed keys
4. site setting overrides for allowed keys
5. user preferences for allowed UI/notification keys

The admin UI must show the effective value and its source.

