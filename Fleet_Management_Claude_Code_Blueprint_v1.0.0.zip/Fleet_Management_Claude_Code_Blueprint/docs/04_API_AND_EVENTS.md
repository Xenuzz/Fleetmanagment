# 04 – API and Event Contract

## 1. General contract

Base path:

`/api/v1`

Rules:

- JSON UTF-8
- ISO-8601 timestamps in UTC
- locale-specific formatting only in clients
- UUID or ULID IDs
- OpenAPI is generated and committed/validated in CI
- API changes are backward compatible within v1 unless explicitly versioned
- errors use RFC-style Problem Details structure
- every mutating request gets a correlation ID
- selected create actions accept `Idempotency-Key`

## 2. Error object

Example logical shape:

```json
{
  "type": "https://docs.example.invalid/problems/booking-conflict",
  "title": "Booking conflict",
  "status": 409,
  "code": "BOOKING_CONFLICT",
  "detail": "The selected vehicle is already blocked in this time range.",
  "correlationId": "...",
  "fieldErrors": []
}
```

## 3. Pagination

Use cursor-based pagination for large, frequently-changing lists.

Query:

- `limit`
- `cursor`
- typed filters
- sort key from allowlist

Response:

- `items`
- `nextCursor`
- optional total only when requested because exact totals can be expensive

## 4. Core endpoint groups

### organization

- GET `/organizations/current`
- PATCH `/organizations/current`
- GET `/sites`
- POST `/sites`
- GET `/sites/:id`
- PATCH `/sites/:id`

### users/roles

- GET `/users`
- GET `/users/:id`
- PATCH `/users/:id`
- GET `/roles`
- POST `/roles`
- PATCH `/roles/:id`
- PUT `/users/:id/roles`
- GET `/permissions`

### vehicles

- GET `/vehicles`
- POST `/vehicles`
- GET `/vehicles/:id`
- PATCH `/vehicles/:id`
- GET `/vehicles/:id/technical-spec`
- PUT `/vehicles/:id/technical-spec`
- GET `/vehicles/:id/equipment`
- POST `/vehicles/:id/equipment`
- GET `/vehicles/:id/status-history`
- POST `/vehicles/:id/odometer-readings`
- GET `/vehicle-classes`

### vehicle documents

- POST `/vehicles/:id/documents`
- GET `/vehicles/:id/documents`
- POST `/vehicles/:id/registration-certificates`
- GET `/vehicles/:id/registration-certificates/:certificateId`
- POST `/vehicles/:id/registration-certificates/:certificateId/accept-extraction`
- PATCH `/vehicles/:id/registration-certificates/:certificateId/fields/:fieldKey`

### driver licenses

- GET `/drivers`
- GET `/drivers/:userId`
- POST `/drivers/:userId/licenses`
- GET `/drivers/:userId/licenses`
- GET `/drivers/:userId/eligibility?vehicleId=&start=&end=`
- POST `/drivers/:userId/licenses/:licenseId/verify`
- POST `/drivers/:userId/licenses/:licenseId/reject`

### bookings

- GET `/bookings`
- POST `/bookings`
- GET `/bookings/:id`
- PATCH `/bookings/:id`
- POST `/bookings/:id/approve`
- POST `/bookings/:id/reject`
- POST `/bookings/:id/cancel`
- GET `/bookings/availability`
- GET `/bookings/eligible-drivers`
- POST `/bookings/:id/handover`
- POST `/bookings/:id/return`

### workshop

- GET `/workshop/orders`
- POST `/workshop/orders`
- GET `/workshop/orders/:id`
- PATCH `/workshop/orders/:id`
- POST `/workshop/orders/:id/tasks`
- PATCH `/workshop/orders/:id/tasks/:taskId`
- POST `/workshop/orders/:id/parts`
- POST `/workshop/orders/:id/labor`
- POST `/workshop/orders/:id/complete`

### parts

- GET `/parts`
- POST `/parts`
- GET `/parts/:id`
- PATCH `/parts/:id`
- POST `/parts/:id/compatibility`
- POST `/parts/:id/reviews`

### service

- GET `/service/templates`
- POST `/service/templates`
- GET `/vehicles/:id/service-schedules`
- POST `/vehicles/:id/service-schedules`
- POST `/service/schedules/:id/complete`

### expenses

- POST `/expenses/fuel-receipts`
- GET `/expenses`
- POST `/invoices`
- GET `/invoices/:id`
- POST `/invoices/:id/link-workshop-order`

### trips/time

- GET `/trips`
- POST `/trips`
- PATCH `/trips/:id`
- POST `/trips/:id/activities`
- POST `/trips/:id/complete`
- GET `/timesheets`
- POST `/compliance/evaluate`

### reports

- POST `/reports/requests`
- GET `/reports/requests/:id`
- GET `/reports/requests/:id/download`

### notifications

- GET `/notifications`
- POST `/notifications/:id/read`
- PUT `/notification-preferences`

### admin/system

- GET `/admin/health`
- GET `/admin/jobs`
- GET `/admin/plugins`
- POST `/admin/plugins/install`
- POST `/admin/plugins/:id/enable`
- POST `/admin/plugins/:id/disable`

## 5. Upload protocol

For small/local deployment:

- multipart upload to API
- streaming, not entire file buffering
- content-size limit
- magic-byte MIME verification

For S3 driver:

- request upload session
- presigned upload
- finalize endpoint verifies checksum/metadata

Files are not considered available until finalization/validation completes.

## 6. Real-time events

WebSocket namespace `/ws`.

Clients subscribe based on authenticated user and organization/site permissions.

Event envelope:

```json
{
  "event": "booking.updated",
  "version": 1,
  "occurredAt": "2026-08-25T20:00:00Z",
  "entityId": "...",
  "data": {}
}
```

Core event names:

- `notification.created`
- `booking.created`
- `booking.updated`
- `booking.approval-required`
- `vehicle.status-changed`
- `vehicle.odometer-updated`
- `workshop.order-updated`
- `service.status-changed`
- `license.status-changed`
- `ocr.review-required`
- `ocr.completed`
- `report.completed`

Do not put sensitive full document payloads in real-time events. Events notify clients to refetch authorized data.

## 7. Plugin events

Integration events exposed to product plugins are versioned separately.

Examples:

- `fleet.vehicle.created.v1`
- `fleet.vehicle.updated.v1`
- `fleet.booking.approved.v1`
- `fleet.booking.completed.v1`
- `fleet.workshop.completed.v1`
- `fleet.service.overdue.v1`

Plugin event payloads contain minimal data plus identifiers. Plugins call the scoped plugin API for additional data if permission is granted.

