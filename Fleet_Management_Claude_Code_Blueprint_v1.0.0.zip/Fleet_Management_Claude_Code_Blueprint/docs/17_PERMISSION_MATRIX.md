# 17 – Permission Model and Role Templates

Authorization is permission-based; roles are templates/bundles, not hard-coded conditionals.

## Permission naming
Use stable keys such as `vehicle.read`, `vehicle.write`, `vehicle.document.read`, `vehicle.document.review`, `booking.create`, `booking.approve`, `booking.override`, `workshop.order.write`, `workshop.qa.complete`, `driver.license.verify`, `report.export`, `plugin.manage`, `system.audit.read`.

Every permission evaluation receives organization, site and optional resource context. Resource ownership/assignment rules may further narrow a granted permission.

## Role templates
- `SYSTEM_ADMIN`: platform deployment/config/identity/plugin health; not an automatic reason to expose every personal document without audit.
- `ORGANIZATION_ADMIN`: organization-wide configuration/users/sites/role assignment.
- `SITE_ADMIN`: site-local administration.
- `FLEET_MANAGER`: vehicles, service plans, booking policy, reports.
- `DISPATCHER`: booking planning/approval/vehicle and driver assignment.
- `WORKSHOP_MANAGER`: work orders, parts, service, QA and workshop reporting.
- `MECHANIC`: assigned work orders/checklists/labor/parts/documentation.
- `DRIVER`: own profile/license, eligible bookings, handover/return, own trips, receipts and notifications.
- `AUDITOR`: read-only business/audit/report access according to scoped policy.
- `READ_ONLY`: non-sensitive read access only.

## Sensitive permissions
Keep separate permissions for reading original driver-license images, registration documents, invoices, audit trails and exporting bulk personal data. Do not bundle these implicitly into broad `read` permissions.

## Policy tests
Maintain a table-driven authorization test suite that covers every endpoint/command for positive, negative, wrong-organization and wrong-site access.
