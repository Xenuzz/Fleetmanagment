# 19 – Target Repository Tree

```text
/
├─ apps/
│  ├─ api/                    # NestJS/Fastify HTTP/WebSocket API
│  ├─ worker/                 # jobs, schedules, outbox, notifications, reports
│  ├─ web/                    # React/Vite web client
│  ├─ desktop/                # Tauri Windows desktop package/adapters
│  ├─ android/                # native Kotlin/Jetpack Compose app
│  └─ ocr-worker/             # Python/FastAPI OCR providers/parsers
├─ packages/
│  ├─ domain/                 # shared pure domain concepts where truly common
│  ├─ contracts/              # generated/versioned API/event contracts
│  ├─ design-system/          # semantic tokens/components for web + token export
│  ├─ config/                 # validated runtime configuration package
│  ├─ events/                 # event envelope/catalog/schema utilities
│  ├─ plugin-sdk/             # product plugin SDK/contracts/tooling
│  ├─ reporting/              # report schemas/templates/helpers
│  └─ test-utils/             # safe fixtures/builders/container helpers
├─ config/
│  ├─ system_config.json
│  └─ system_config.schema.json
├─ prisma/                    # if central schema chosen; otherwise owned module migrations
├─ docs/
│  ├─ adr/
│  └─ ...
├─ wiki/                      # version-controlled GitHub Wiki source
├─ design/                    # supplied DeepBlue kit + generated references
├─ infra/
│  ├─ docker/
│  ├─ linux/
│  └─ windows/
├─ scripts/
├─ .github/
│  ├─ workflows/
│  ├─ ISSUE_TEMPLATE/
│  └─ PULL_REQUEST_TEMPLATE.md
├─ .claude/
│  ├─ settings.json
│  ├─ rules/
│  ├─ agents/
│  └─ skills/
├─ CLAUDE.md
├─ README.md
└─ LICENSE
```

The exact placement of Prisma migration files can be refined in ADR-0001, but module ownership must remain explicit and cross-module repository access is prohibited.
