# 11 – Implementation Roadmap for Claude Code

Claude Code must work phase-by-phase. Do not attempt a single giant implementation commit.

## Phase 0 – Repository foundation

Deliver:

- monorepo
- toolchains
- lint/format/test baseline
- PostgreSQL dev container
- Keycloak dev setup
- config loader/schema
- DeepBlue token ingestion
- initial API/web/android/desktop compile
- CI skeleton
- CLAUDE.md/rules/skills

Gate:

- every app compiles
- CI green
- no feature logic required yet

## Phase 1 – Organization, identity, RBAC, audit

Deliver:

- organization/site
- OIDC integration
- local app profile
- roles/permissions/scopes
- onboarding state
- audit service
- admin user/role pages

Gate:

- horizontal access tests green
- role matrix documented

## Phase 2 – Vehicle core and documents

Deliver:

- vehicle CRUD
- technical data
- equipment
- status
- odometer
- photos/files
- vehicle detail UI

Gate:

- web + Android vehicle read flows
- file authorization tests

## Phase 3 – Digital registration certificate + OCR

Deliver:

- OCR worker
- DE ZB I parser/template
- front/rear digital view
- tooltips
- extraction review/correction
- optional diff-to-vehicle data

Gate:

- fixture OCR tests
- every supported field has description metadata
- low-confidence workflow tested

## Phase 4 – Drivers/licenses/onboarding

Deliver:

- license capture
- OCR parser
- class validity
- verification
- eligibility service
- expiry reminders baseline

Gate:

- booking eligibility API test fixtures ready

## Phase 5 – Booking/approval/handover

Deliver:

- availability
- DB overlap protection
- request/approval
- eligible driver filtering
- calendar UI
- handover/return
- Android offline handover drafts
- ICS generation

Gate:

- concurrent booking race test
- driver expiry edge cases

## Phase 6 – Workshop, damage, parts

Deliver:

- workshop orders/tasks
- vehicle blocks
- damages
- parts catalogue
- compatibility
- installation reviews
- invoices link

Gate:

- order lifecycle tests
- vehicle block state derived correctly

## Phase 7 – Service intervals

Deliver:

- templates
- date/km/hour triggers
- warning/escalation
- auto work-order option
- dashboard due cards

Gate:

- whichever-first test suite

## Phase 8 – Expenses, fuel, invoices

Deliver:

- receipt/invoice uploads
- OCR
- arithmetic validation
- duplicate hints
- vehicle cost views

Gate:

- OCR failure/review states

## Phase 9 – Trips, time and reports

Deliver:

- trips
- activity/break segments
- timesheets
- PDF/XLSX exports
- rule-pack interface for LKW compliance

Gate:

- chronology validation
- export snapshots

## Phase 10 – Notifications and realtime

Deliver:

- notification center
- SMTP
- FCM provider
- desktop notifications
- user preferences
- WebSocket events
- reminder scheduler

Gate:

- delivery retry/dead-letter tests

## Phase 11 – Fleet product plugin system

Deliver:

- manifest
- install/enable/disable
- capabilities
- plugin runtime API
- event delivery
- example plugin
- plugin developer docs

Gate:

- plugin cannot access data without grant
- incompatible plugin rejected

## Phase 12 – Admin/settings/observability

Deliver:

- full settings pages
- health dashboard
- job dashboard
- plugin health
- storage/SMTP/OCR diagnostics
- backup command tooling

## Phase 13 – Deployment and release hardening

Deliver:

- Docker production stack
- Linux installer/service scripts
- Windows Server scripts/services
- Windows desktop release
- Android release
- security scan workflows
- SBOM/checksum
- wiki sync
- release docs

## Phase 14 – Final parity audit

Create a matrix of every function vs:

- Web
- Windows desktop
- Android phone
- Android tablet

Every function must be either implemented or explicitly documented as platform-inapplicable for a technically valid reason. The user requirement is functional parity, so “not implemented yet” is not an acceptable final state.

