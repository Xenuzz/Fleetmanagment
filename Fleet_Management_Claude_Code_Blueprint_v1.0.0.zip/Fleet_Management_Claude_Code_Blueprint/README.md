# Fleet Management Platform – Claude Code Blueprint

Version: 1.0.0  
Date: 2026-08-25  
Language: German-first, internationalizable

This package is the complete planning and execution basis for building an enterprise-capable fleet management platform with Claude Code.

## What is included

- product scope and module boundaries
- architecture and technology decisions
- detailed core data model
- REST/WebSocket contract conventions
- identity, RBAC, SSO, Active Directory and privacy design
- vehicle management, digital registration certificate and OCR workflows
- workshop, parts and service-interval system
- driver-license onboarding and eligibility engine
- vehicle booking, approval, handover and return workflows
- fuel receipt, invoice and document processing
- trip log, shift/time tracking and export model
- notifications, email and calendar integration
- Linux, Windows Server and Docker deployment model
- Windows desktop, web and Android client strategy
- product plugin SDK design
- GitHub Actions / release architecture
- Wiki structure
- Claude Code project configuration, agents, skills and rules
- ready-to-paste Claude Project Knowledge and Custom Knowledge texts
- a master build prompt for Claude Code
- the original DeepBlue Liquid Glass design kit as a required design source

## Important distinction: Claude Project vs Claude Code

This blueprint intentionally supports both layers:

1. **Claude Project settings**
   - Paste `claude-project/PROJECT_KNOWLEDGE.md` into the field named Project Knowledge / Projektwissen, or upload it to the Project knowledge base.
   - Paste `claude-project/CUSTOM_KNOWLEDGE.md` into the field named Custom Instructions / Benutzerdefiniertes Wissen / Project Instructions, depending on the UI wording.

2. **Claude Code repository memory**
   - Keep `CLAUDE.md` in the repository root.
   - Keep `.claude/rules/`, `.claude/agents/`, `.claude/skills/` and `.claude/settings.json` committed.
   - This makes the coding agent behave consistently when working directly in the repository.

## Recommended workflow

1. Create an empty Git repository named `fleet-management-platform`.
2. Copy this blueprint into a temporary planning folder or into `docs/blueprint/` of that repository.
3. Unpack `design/DeepBlue_Liquid_Glass_Kit.zip` into `design/DeepBlue_Liquid_Glass_Kit/`.
4. Configure Claude Project Knowledge and Custom Knowledge with the two files under `claude-project/`.
5. Install the recommended Claude Code plugins from `docs/13_CLAUDE_CODE_PLUGINS.md`.
6. Start Claude Code in the repository root.
7. Give Claude Code `prompts/MASTER_BUILD_PROMPT.md` as the initial implementation order.
8. Do not let the agent build every module in one uncontrolled pass. It must follow the phase gates in `docs/11_IMPLEMENTATION_ROADMAP.md`.
9. Do not merge a phase until its tests and acceptance criteria are green.

## Architectural headline

The recommended implementation is a modular monorepo with:

- **Backend:** NestJS + Fastify + TypeScript
- **Database:** PostgreSQL + Prisma
- **Jobs / scheduling:** pg-boss backed by PostgreSQL
- **Identity:** Keycloak as the bundled identity broker and local identity provider
- **Web:** React + TypeScript
- **Windows desktop:** Tauri using the same React application shell
- **Android:** Kotlin + Jetpack Compose
- **Files:** storage abstraction with filesystem and S3-compatible drivers
- **OCR:** local OCR worker abstraction; PaddleOCR is the preferred local engine, Tesseract is the fallback
- **Real time:** WebSocket/SSE plus PostgreSQL outbox / LISTEN-NOTIFY
- **Reporting:** PDF + XLSX export service
- **Configuration:** `config/system_config.json` for non-secret system settings, environment variables only for secrets and machine-specific credentials

The design deliberately avoids Redis as a mandatory dependency so that native Windows Server and Linux installations remain feasible and PostgreSQL remains the single required stateful infrastructure component besides the identity service.

## Non-negotiable quality rules

- no business logic in UI components
- no duplicated authorization logic
- no hard-coded design values in feature code
- no secrets in source control
- no direct plugin access to core database tables
- no booking eligibility decision on the client only
- no OCR result is treated as unquestionably correct without confidence and validation status
- no production release when migrations, E2E, security scanning or mobile builds fail
- every core state change must be auditable
- every public API is versioned
- every user-facing module must define loading, empty, offline, permission-denied and error states

## Claude project fields
Ready-to-paste files are included for both Claude project text areas:
- `claude-project/PROJECT_KNOWLEDGE.md` → Projektwissen
- `claude-project/CUSTOM_KNOWLEDGE.md` → Benutzerdefiniertes Wissen / Projektanweisungen

The repository-level `CLAUDE.md` is separate and is intended for Claude Code session memory/instructions. Start with `prompts/START_HERE.md`, then use `prompts/MASTER_BUILD_PROMPT.md`.

