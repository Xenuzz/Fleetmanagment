# Start Here – Claude Code

## Einmalige Vorbereitung
1. Neues leeres GitHub-Repository erstellen oder einen leeren lokalen Repository-Ordner öffnen.
2. Den kompletten Inhalt dieses Blueprint-Ordners in das Repository kopieren.
3. Das DeepBlue Design Kit in `design/` unverändert behalten.
4. In Claude/Claude Code das **Projektwissen** aus `claude-project/PROJECT_KNOWLEDGE.md` übernehmen.
5. Das **Benutzerdefinierte Wissen / die Projektanweisungen** aus `claude-project/CUSTOM_KNOWLEDGE.md` übernehmen.
6. Die empfohlenen Plugins aus `docs/13_CLAUDE_CODE_PLUGINS.md` auf Project Scope installieren und Claude Code neu laden.
7. Claude Code im Repository starten. `CLAUDE.md` und `.claude/settings.json` liegen bereits auf Repository-Ebene.
8. `prompts/MASTER_BUILD_PROMPT.md` als ersten großen Arbeitsauftrag verwenden.

## Wichtig
Der Master-Prompt fordert Claude bewusst auf, das System **phasenweise mit ausführbaren Zwischenständen** aufzubauen. Eine einzelne riesige Codegenerierung ohne Tests/Migrationen/Review wäre für dieses Projekt technisch schlechter und soll vermieden werden.
