# MASTER BUILD PROMPT – Fleet Management Repository

Du befindest dich im Root eines neuen Fleet-Management-Repositories. Baue daraus die vollständige, produktionsfähige Anwendung gemäß den vorhandenen Spezifikationen. Die Dateien im Repository sind verbindliche Anforderungen und dürfen nicht stillschweigend reduziert werden.

## 0. Zuerst lesen und verifizieren
Bevor du Quellcode erzeugst:
- Lies `CLAUDE.md` vollständig.
- Lies alle Dateien unter `docs/`.
- Lies `config/system_config.json` und `config/system_config.schema.json`.
- Entpacke/analysiere `design/DeepBlue_Liquid_Glass_Kit.zip` vollständig, einschließlich Referenzbildern, Design-/Motion-Tokens, Komponenten-, Screen-, Plattform- und Accessibility-Spezifikationen.
- Lies `.claude/rules/*`.
- Prüfe die verfügbaren Claude-Code-Plugins/Tools und verwende sie gezielt, insbesondere GitHub, Frontend Design, Feature Dev, Code Review, Playwright, Context7, LSPs und Security-Tools.
- Erzeuge `docs/IMPLEMENTATION_STATUS.md` mit Phase, Status, Abhängigkeiten, Akzeptanzkriterien, Teststatus und offenen Issues.
- Erzeuge ADRs für jede neue Architekturentscheidung, die von den Blueprint-Vorgaben abweicht oder sie konkretisiert.

Erst danach darf die Implementierung beginnen.

## 1. Repository und Toolchain
Erzeuge ein sauberes Monorepo mit mindestens:

```text
apps/
  api/
  worker/
  web/
  desktop/
  android/
  ocr-worker/
packages/
  domain/
  contracts/
  design-system/
  config/
  events/
  plugin-sdk/
  reporting/
  test-utils/
config/
docs/
wiki/
infra/
  docker/
  linux/
  windows/
.github/
  workflows/
.claude/
```

Nutze eine reproduzierbare Node/TypeScript-Workspace-Strategie mit Lockfile. Pinne wichtige Toolversionen. Lege `.editorconfig`, Formatter, Linter, TypeScript-Basiskonfiguration, Commit-Konventionen, Codeowners/PR-Templates, Dependabot/Renovate-Strategie und Development Containers nur dann an, wenn sie dem selbsthostbaren Ziel nicht widersprechen.

## 2. Architektur umsetzen
- Core als modularen Monolith implementieren.
- Backend: NestJS + Fastify.
- PostgreSQL + Prisma mit versionierten Migrationen.
- Worker für Hintergrundjobs, Scheduling, Benachrichtigungen, Reporting und Outbox-Verarbeitung.
- PostgreSQL-basierte Queue (z. B. pg-boss) und Transactional Outbox; Redis darf keine Pflichtabhängigkeit werden.
- OCR als separater Python/FastAPI-Worker mit Provider-Interface; PaddleOCR primär, Tesseract Fallback.
- Storage-Abstraktion für Filesystem und S3-kompatible Stores.
- Keycloak für lokale Accounts/Federation/SSO; Integrationsdokumentation für Active Directory/LDAP, OIDC und SAML.
- Generiere OpenAPI und typsichere Client-Contracts für Web/Desktop/Android oder eine gleichwertige drift-sichere Contract-Strategie.
- Verwende Correlation IDs, strukturierte Logs, Metrics, Tracing und Health/Readiness Checks.

## 3. Domänenmodule vollständig implementieren
Implementiere die in `docs/02_MODULES_AND_WORKFLOWS.md` beschriebenen Module. Mindestens:
- organizations/sites/branding/settings
- users/identities/roles/permissions
- drivers/driver licenses/verification
- vehicles/catalog/equipment/specifications/images/documents/status/history
- digital registration certificate / Zulassungsbescheinigung Teil I
- bookings/approval/calendar/handover/return
- workshop/work orders/issues/checklists/labor/QA
- parts/catalog/fitment/installation experience/vendors/prices
- service schedules/intervals/reminders
- trips/logbook/jobs/work-time/breaks
- fuel receipts/invoices/document OCR
- notifications/preferences/templates/delivery log
- reports/exports
- audit
- product plugin registry/runtime/SDK
- admin/system health

Jedes Modul erhält klare Ownership, Permission-Keys, Events, API, DB-Invarianten, Auditregeln, Tests und Dokumentation.

## 4. Fahrzeugdaten und digitaler Fahrzeugschein
Erstelle ein umfangreiches Vehicle Aggregate mit technischen Daten, Ausstattung, frei erweiterbaren Custom Fields und Historisierung.

Für die Zulassungsbescheinigung Teil I:
- Upload Vorderseite/Rückseite/mehrseitig.
- Bildvorverarbeitung und OCR.
- Extraktion in ein kanonisches Feldschema auf Basis der aktuellen FZV Anlage 6.
- Pro Feld: Feldcode, semantischer Name, normalisierter Wert, Einheit, Raw OCR, Konfidenz, Bounding Box, Quelle/Seite, Parser-/OCR-Version, Validierungsstatus, manuelle Korrektur, Reviewer, Zeitstempel.
- Validierungen für VIN, Datums-/Zahlenformate, HSN/TSN-artige Codes, Maße/Massen/Leistung usw., ohne unzulässige Annahmen.
- Digitales Rendering: Vorderseite, Rückseite und Front-only; responsiv; Tooltips erklären Feldcode, Bedeutung, Einheit und ggf. Datenherkunft.
- Zeige korrigierte/ungeprüfte OCR deutlich.
- Kennzeichne permanent „Digitale interne Ansicht – kein amtliches Originaldokument“ oder semantisch gleichwertig.
- Reproduziere keine Sicherheitsmerkmale und baue keine Funktion, die das digitale Rendering als amtlichen Ersatz ausgibt.

## 5. Fahrerlaubnis und Onboarding
Beim ersten Login erzwinge einen resumierbaren Setup-Wizard:
- Profildaten
- Datenschutz-/Nutzungshinweise
- Führerschein Vorder-/Rückseite hochladen
- OCR: Name, Dokumentinformationen, Klassen, Erteilungs-/Gültigkeitsdaten je Klasse, Ablaufdaten soweit vorhanden
- Normalisierung und Confidence
- automatische Plausibilisierung
- REVIEW_REQUIRED bei Unsicherheit
- Admin/autorisierten Verifier-Workflow
- VERIFIED/REJECTED/EXPIRED/REVIEW_REQUIRED Zustände
- Ablaufwarnungen

Fahrzeug/Fahrzeugklasse definiert notwendige Fahrerlaubnisklassen. Bei Buchung werden nur berechtigte Fahrer angeboten, aber der Server validiert unabhängig davon. Revalidiere beim Speichern, Genehmigen und Handover. Eine Lizenz, die während des Buchungszeitraums abläuft, ist nicht gültig für die gesamte Buchung.

## 6. Buchungssystem
- Kalender-/Listenansicht, Filter, Verfügbarkeitssuche.
- Konfliktfreie Fahrzeugreservierung mit PostgreSQL-Constraint gegen Überschneidungen plus Service-Level-Check.
- Approval Workflow und Statusmaschine.
- Fahrerberechtigung.
- Blockierung wegen Werkstatt/Out-of-Service/Service-Regeln.
- ICS-Einladungen und Erinnerungen.
- Übergabe/Rückgabe mit Kilometerstand, Kraftstoff/Ladezustand, Checkliste, Bilder, neue Schäden, Unterschrift/Bestätigung soweit konfiguriert.
- Vollständige Audit-Historie und Benachrichtigungen.
- Concurrency-Tests mit parallelen Buchungsversuchen.

## 7. Werkstatt, Teile und Service
Implementiere Werkstattauftrag mit Statusmaschine, Prioritäten, Diagnose/Mangel, Aufgaben, Checklisten, Arbeitszeit, Teilen, Kosten, Dokumenten/Bildern, Rechnungen, Verantwortlichen und QA/Abschluss.

Teilekatalog enthält:
- Hersteller/OE-/Vergleichsnummern
- Lieferant/Bezugsquelle/Preis/Währung
- kompatible Fahrzeuge/Varianten
- Einbauverwendung und Historie
- Bewertungen 1..5 für Passgenauigkeit, Einbaugenauigkeit/-qualität, Einbaufreundlichkeit/Einfachheit und Gesamtergebnis
- Freitext, Bilder, dokumentierte Besonderheiten

Serviceplan unterstützt Zeit, km, Betriebsstunden und kombinierte Intervalle. Berechne Fälligkeit transparent und teste Grenzfälle. Warnungen und Eskalationen laufen über den Worker.

## 8. Fahrtenbuch/Lkw-Zeit
- Fahrten/Aufträge, Start/Ziel, Zweck, Fahrer/Fahrzeug, Start-/End-km, Zeiten, Pausen und Aktivitätssegmente.
- Zeitberechnung reproduzierbar und testbar.
- PDF-/XLSX-Stundenzettel und Fahrtenberichte.
- Korrekturen nur mit Begründung/Audit.
- Gesetzliche Lenk-/Ruhezeit-/Arbeitszeitprüfung in eine versionierte Rule-Pack-Schnittstelle kapseln. Eine allgemeine Berechnung darf niemals als verbindliche Rechtskonformitätsbestätigung ausgegeben werden, solange das konkrete Regelwerk nicht vollständig implementiert/verifiziert ist.

## 9. Clients
### Web
React/TypeScript/Vite mit Routing, TanStack Query/Table und zugänglichen UI-Primitives. Implementiere jede Kernfunktion, nicht nur Adminseiten.

### Windows Desktop
Tauri mit gemeinsamem Web-Frontend und nativen Adaptern für Notifications, Datei-/Dialogintegration, Deep Links und Updatefähigkeit. Erzeuge Windows Installer im Release-Workflow.

### Android
Native Kotlin/Jetpack Compose App für Smartphone und Tablet. Featureparität für operative und administrative Funktionen, soweit auf mobil sinnvoll. Implementiere insbesondere:
- Dashboard/Notifications
- Fahrzeuge/Fahrzeugdetails/digitaler Fahrzeugschein
- Buchung/Approval/Handover/Return
- Fahrer/Führerschein
- Werkstattaufträge/Checklisten/Bilder
- Fahrtenbuch/Arbeitszeit
- Beleg-/Rechnungsupload
- Admin-/Einstellfunktionen mit responsiven Tablet-Layouts
- Push und Deep Links
- Offline-Cache/Outbox für zugewiesene operative Datensätze; Idempotency/Conflict UI

## 10. DeepBlue Liquid Glass UI
Implementiere die Design-Tokens als Source of Truth und generiere daraus Web-/Android-kompatible Tokenartefakte. Keine hardcodierten Designwerte in Feature-Screens.

Verwende:
- dunkles Navy-Grundsystem
- kontrolliertes Liquid Glass/Blur
- große abgerundete Flächen
- elektrische blaue Akzente
- Layer/Depth/Glow sparsam und hochwertig
- morphende/floating Navigation, sofern im Kontext sinnvoll
- hochwertige Dialoge/Popover/Bottom Sheets
- Datenhierarchie statt Dekoration
- Motion Tokens und Reduced Motion
- Accessibility, Keyboard, Screenreader, Touch Targets und Kontrast

Führe visuelle Playwright-Prüfungen gegen die Referenzrichtung durch. Android muss dieselbe Designidentität besitzen, aber native Material/Compose-Interaktion verwenden.

## 11. Produkt-Plugin-System
Implementiere ein eigenes, dokumentiertes Plugin-System, getrennt von Claude-Code-Plugins:
- manifest mit id/name/version/core compatibility/permissions/capabilities
- signier-/prüfbarer Installationsprozess
- enable/disable/update/uninstall/health
- settings schema + Admin UI
- event subscriptions
- versionierte Plugin API
- capability-scoped Tokens
- kein direkter DB-Zugriff
- out-of-process execution
- network deny by default
- UI contributions in Sandbox/iframe mit Message Contract
- SDK, Beispielplugin, Test Harness, Generator/Template
- Migration/Compatibility Policy

## 12. Dateien/OCR/Sicherheit
Implementiere Magic-Byte/MIME-Validierung, Größenlimits, Random Storage Keys, SHA-256, EXIF stripping und optional ClamAV. Dokumente werden nie direkt unter vom Benutzer kontrollierten Pfaden veröffentlicht. Zugriffe auf sensible Dokumente werden autorisiert und auditiert.

## 13. Konfiguration und Admin Settings
- `config/system_config.json` bleibt zentrale Deployment-Konfiguration.
- Erzeuge daraus eine vollständige, streng typisierte Schema-/Runtime-Konfiguration.
- Secrets nur per Env-Referenz aus zentralem Config Layer.
- Runtime-editierbare Organization/Site/User Settings liegen separat in DB und folgen der dokumentierten Präzedenz.
- Admin UI zeigt Effective Value + Herkunft + Restart Requirement + Security Impact.
- Keine versteckte Konfiguration in Featurecode.

## 14. Deployment
Erzeuge und teste:
- Docker Compose für PostgreSQL, Keycloak, API, Worker, OCR, Web und optionale Dienste.
- Linux-Installations-/Update-/Backup-/Restore-Skripte und systemd Units.
- Windows-Server-PowerShell-Installer/Services, Update/Backup/Restore-Dokumentation.
- Reverse Proxy/TLS-Konfiguration (z. B. Caddy) mit dokumentierten Alternativen.
- Initial Admin Bootstrap ohne hartcodiertes Passwort.
- Health/readiness und Upgrade/Migration-Prozess.

## 15. GitHub und CI/CD
Richte `.github/workflows` so ein, dass Pull Requests mindestens ausführen:
- formatting/lint/typecheck
- backend unit/integration tests with PostgreSQL
- Prisma migration checks
- web tests/build
- Playwright E2E
- OCR tests
- Android lint/unit/instrumentation where CI infrastructure permits
- desktop/Tauri Windows build validation
- dependency/license/secret/security scans
- generated-contract drift check

Release Workflow:
- semantic version/tag
- Docker multi-arch images
- Web/server artifacts where needed
- Windows Desktop installer
- Android unsigned debug/testing APK on normal CI and signed APK/AAB only when release secrets are present
- checksums + SBOM + release notes
- Wiki sync/publish

Nutze GitHub-Integration, wenn authentifiziert, um Issues/Milestones/Labels/PR-Templates/Actions sauber einzurichten. Keine Secrets in Repository Settings erfinden; dokumentiere die exakten Secret-Namen und den Zweck.

## 16. Wiki
Erzeuge eine vollständige Wiki-Quelle im Repository und synchronisiere sie per CI. Mindestens die Struktur aus `docs/12_WIKI_STRUCTURE.md`. Jede Einstelloption muss auffindbar sein. Dokumentiere zusätzlich Pluginentwicklung mit einem vollständigen Beispiel.

## 17. Test- und Abnahmestrategie
Nutze `docs/10_TESTING_AND_ACCEPTANCE.md`. Für jede Phase:
1. Akzeptanzkriterien definieren.
2. Funktion implementieren.
3. Tests schreiben/ausführen.
4. Security/Permissions prüfen.
5. Design QA durchführen.
6. Docs/Wiki aktualisieren.
7. `IMPLEMENTATION_STATUS.md` aktualisieren.
8. Code Review + Simplification ausführen, ohne Architektur zu verwässern.
9. Erst dann Phase als DONE markieren.

## 18. Bauphasen
Arbeite mindestens in dieser Reihenfolge:
1. Foundation/Monorepo/Config/CI/observability
2. Identity/Organization/Sites/RBAC/Audit
3. Vehicle Core/Documents/Digital Registration
4. Driver Profile/License Verification/Onboarding
5. Booking/Calendar/Handover/Return/Notifications
6. Workshop/Parts/Service
7. Trips/Work Time/Reports
8. Android operational parity/offline
9. Desktop packaging/native integration
10. Product Plugin SDK/runtime/admin
11. Deployment hardening/Linux/Windows Server/Docker
12. Full Wiki/QA/Security/performance/release hardening

Ein Phase darf keine leere Hülle sein. Halte das System nach jeder Phase start- und testbar.

## 19. Qualitätsverbote
- Keine tausenden duplizierten DTOs/Mapper/Stylewerte.
- Keine Businesslogik in React-Komponenten oder Compose-Screens.
- Keine Authentisierung/Autorisierung nur im Client.
- Keine produktiven Default-Passwörter.
- Keine SQLite-Produktionsabkürzung.
- Kein Redis als zwingende Komponente, sofern die dokumentierte PostgreSQL-Queue die Anforderungen erfüllt.
- Keine Microservices nur wegen Projektgröße.
- Keine direkten Plugin-Core-DB-Zugriffe.
- Keine ungeprüfte OCR als „verifiziert“ markieren.
- Keine Veröffentlichung persönlicher Testdokumente.
- Keine Veröffentlichung/Push/Release ohne Freigabe.

## 20. Dein erstes konkretes Ergebnis
Erstelle nach dem Lesen zunächst:
1. `docs/IMPLEMENTATION_STATUS.md`
2. vollständigen finalen Repository-Tree
3. ADR-0001 mit bestätigter Architektur
4. Workspace-/Toolchain-Grundgerüst
5. streng validierte Config-Library aus `system_config.json`
6. Docker Development Stack mit PostgreSQL + Keycloak
7. API-/Worker-/Web-/OCR-Health Skeletons mit echten Tests
8. Design-Token-Pipeline und eine erste Shell/Dashboard-Referenzseite nach dem Kit
9. Basis-CI
10. README mit lokalem Start

Führe die Tests wirklich aus. Wenn ein Tool/SDK nicht installiert ist, dokumentiere den exakten reproduzierbaren Installationsschritt und implementiere alles, was ohne diese Abhängigkeit verifizierbar ist. Danach setze die weiteren Phasen selbstständig gemäß `IMPLEMENTATION_STATUS.md` fort, ohne Features stillschweigend zu streichen.
