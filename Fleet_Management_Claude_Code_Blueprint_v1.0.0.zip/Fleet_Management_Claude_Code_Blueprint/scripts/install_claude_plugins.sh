#!/usr/bin/env bash
set -euo pipefail

# Fleet Management – Claude Code project-scoped plugin installer
claude plugin marketplace update claude-plugins-official || true
claude plugin install frontend-design@claude-plugins-official --scope project
claude plugin install feature-dev@claude-plugins-official --scope project
claude plugin install code-review@claude-plugins-official --scope project
claude plugin install code-simplifier@claude-plugins-official --scope project
claude plugin install playwright@claude-plugins-official --scope project
claude plugin install github@claude-plugins-official --scope project
claude plugin install claude-md-management@claude-plugins-official --scope project
claude plugin install context7@claude-plugins-official --scope project
claude plugin install typescript-lsp@claude-plugins-official --scope project
claude plugin install kotlin-lsp@claude-plugins-official --scope project
claude plugin install pyright-lsp@claude-plugins-official --scope project
claude plugin install rust-analyzer-lsp@claude-plugins-official --scope project
claude plugin install security-guidance@claude-plugins-official --scope project
claude plugin install claude-security@claude-plugins-official --scope project
claude plugin install prisma@claude-plugins-official --scope project
claude plugin install postman@claude-plugins-official --scope project
claude plugin install pr-review-toolkit@claude-plugins-official --scope project
claude plugin install commit-commands@claude-plugins-official --scope project

echo "Core/recommended plugins installed at project scope."
echo "Open Claude Code and run /reload-plugins if the current session was already running."
echo "LSP plugins also require their language-server binaries; see docs/13_CLAUDE_CODE_PLUGINS.md."
