# Projektwissen – Fleet Management

> Diesen Inhalt in Claude unter **Projektwissen** hinterlegen bzw. als Wissensdatei hochladen. Er beschreibt, **was das Projekt ist und welche fachlichen/technischen Fakten dauerhaft gelten**.

## Zielbild
Das Projekt ist eine vollständig selbst hostbare, firmenweite Fuhrparkmanagement-Plattform für Pkw, Transporter, Lkw und weitere Fahrzeugtypen. Sie soll Web, Windows-Desktop und eine native Android-App für Smartphone und Tablet bereitstellen. Serverbetrieb muss per Docker sowie nativ unter Linux und Windows Server möglich sein. Das System ist auf langfristige Erweiterbarkeit, saubere Domänentrennung, hohe Datenintegrität, nachvollziehbare Berechtigungen und umfassende Dokumentation ausgelegt.

## Verbindliche Funktionsbereiche
1. **Fahrzeuge und Fahrzeugkatalog:** Stammdaten, technische Daten, Maße/Massen, Motor/Antrieb, Zulassung, Ausstattung, Kostenstellen, Standort, Verantwortliche, Status, eigene Felder, Bilder, Dokumente und Historie.
2. **Digitale Zulassungsbescheinigung Teil I:** Upload von Vorder-/Rückseite, OCR, strukturierte Extraktion, normalisierte Datenfelder, OCR-Konfidenz, Korrektur/Prüfung, digitale Vorder-/Rückseitenansicht sowie Front-only-Ansicht. Jedes Feld erhält Tooltip/Erklärung. Feldmodell orientiert sich an der aktuellen deutschen FZV Anlage 6. Die Ansicht ist intern/digital und darf nicht als amtliches Ersatzdokument erscheinen.
3. **Werkstatt:** Werkstattaufträge, Priorität, Status, Diagnosen, Mängel/Baustellen, Arbeitspositionen, Checklisten, Bilder, Zeiten, Teile, Rechnungen, Kosten, Abnahme/QA und vollständige Historie.
4. **Teilekatalog:** Hersteller, Hersteller-/OE-/Vergleichsnummern, Lieferanten, Preise, Fahrzeugzuordnung/Kompatibilität, Einbauhistorie sowie Erfahrungsbewertung für Passgenauigkeit, Einbaugenauigkeit/-qualität, Einfachheit und Gesamtergebnis plus Freitext.
5. **Serviceintervalle:** Zeit-, Kilometer- und Betriebsstunden-Intervalle, Kombination nach „was zuerst eintritt“, Warnstufen, Überfälligkeit, Benachrichtigungen und optional automatische Werkstattaufträge.
6. **Buchungen:** Zeitfenster, Fahrzeug, Fahrer, Zweck/Auftrag, Standort, Genehmigung, Konfliktprüfung, Status, E-Mail/Push/In-App-Benachrichtigungen, ICS/Kalendereinladung, Übergabe und Rückgabe mit Kilometerstand, Zustand, Schäden und Bildern.
7. **Fahrer/Führerscheine:** Erstanmelde-Wizard; Profil vervollständigen; Führerscheinbilder hochladen; OCR von Klassen, Gültigkeiten und Metadaten; Validierungs-/Prüfstatus. Ein Fahrer darf für ein Fahrzeug nur angeboten/akzeptiert werden, wenn seine Klassen und Gültigkeit die Fahrzeuganforderung während der gesamten Buchung erfüllen. OCR allein ist keine Echtheitsprüfung; manuelle Verifizierung muss möglich und für sensible Klassen erzwingbar sein.
8. **Fahrtenbuch und Lkw-Arbeitszeit:** Fahrten, Start/Ziel, Zweck/Auftrag, Fahrzeug/Fahrer, Kilometer, Zeiten, Aktivitätssegmente und Pausen. Auswertung als PDF/XLSX/Stundenzettel. Gesetzliche Lenk-/Ruhezeitlogik ist als versioniertes Regelpaket zu behandeln und darf nicht mit bloßer Zeitberechnung verwechselt werden.
9. **Belege/Dokumente:** Tankbelege, Rechnungen, Werkstattbelege und weitere Dokumente mit OCR/Metadaten, Zuordnung, Prüfung und Audit.
10. **Benachrichtigungen:** In-App, SMTP-E-Mail, Android Push, Windows Desktop sowie Webhook/Plugin-Kanäle. Ereignisse umfassen u. a. Buchungen, Freigaben, Übergaben, Werkstattaufträge, Service, Führerscheinablauf und Systemmeldungen.
11. **Organisation/Standorte:** Organisation, mehrere Standorte, Firmenname, Logo, Farben, Zeitzone, Sprache, Betriebsregeln, standortbezogene Einstellungen und Zuordnungen.
12. **Benutzer/Rollen:** lokale Benutzer sowie SSO über OIDC/SAML und Windows-Domain/Active Directory via LDAP-Föderation. Granulare serverseitige RBAC/Permissions. Rollen-Vorlagen: SYSTEM_ADMIN, ORGANIZATION_ADMIN, SITE_ADMIN, FLEET_MANAGER, DISPATCHER, WORKSHOP_MANAGER, MECHANIC, DRIVER, AUDITOR, READ_ONLY.
13. **Admin und Einstellungen:** Admin-Dashboard, Systemzustand, Jobs, Speicher, OCR, Benachrichtigungen, Identität, Rollen, Organisation, Standorte, Branding, Features, Pluginverwaltung, Audit und Konfiguration.
14. **Produkt-Plugin-System:** Plugins können definierte Events abonnieren, APIs verwenden, eigene Einstellungen, Navigation/Widgets oder Hintergrundaktionen bereitstellen. Kein direkter Zugriff auf Core-DB-Tabellen. Out-of-process, capability-scoped, signierte Manifeste im Produktivbetrieb, UI in Sandbox/iframe, Netzwerk standardmäßig gesperrt.
15. **Export/Reporting:** PDF/XLSX für Fahrten, Stunden, Werkstatt, Kosten, Buchungen und weitere Auswertungen; Druckansichten und zeitgesteuerte Reports sollen später erweiterbar sein.

## Architekturentscheidungen
- Monorepo mit klaren Apps/Packages.
- Modularer Monolith als Core; separate Worker für Hintergrundjobs und OCR.
- Backend: TypeScript, NestJS, Fastify.
- Datenbank: PostgreSQL; Prisma ORM; Migrationen im Repository.
- Jobs: PostgreSQL-basiert (z. B. pg-boss) plus Transactional Outbox, damit native Installationen kein Redis zwingend benötigen.
- Identity: Keycloak als Broker/IdP; lokale Konten plus LDAP/AD, OIDC und SAML.
- Web: React + TypeScript + Vite, React Router, TanStack Query/Table, zugängliche headless UI-Primitives, ECharts.
- Windows Desktop: Tauri; Wiederverwendung des Web-Frontends mit nativen Adaptern.
- Android: Kotlin + Jetpack Compose, Hilt, Room, DataStore, WorkManager, CameraX, Coil; adaptive Phone-/Tablet-Layouts und definierter Offline-Outbox-Sync.
- OCR Worker: Python/FastAPI; lokale OCR primär PaddleOCR, Tesseract als Fallback; Provider-Schnittstelle für spätere externe OCR-Plugins.
- Storage: lokales Dateisystem standardmäßig, S3-kompatibel optional; Binärdaten nicht in PostgreSQL speichern.
- Echtzeit: WebSocket/SSE plus Polling-Fallback.
- Suche: PostgreSQL Full Text + pg_trgm; kein Elasticsearch im MVP.
- Reporting: serverseitige asynchrone PDF-/XLSX-Erzeugung.

## Repository-Zielstruktur
`apps/api`, `apps/worker`, `apps/web`, `apps/desktop`, `apps/android`, `apps/ocr-worker`, `packages/domain`, `packages/contracts`, `packages/design-system`, `packages/config`, `packages/events`, `packages/plugin-sdk`, `packages/reporting`, `packages/test-utils`, `config`, `docs`, `wiki`, `infra/docker`, `infra/linux`, `infra/windows`, `.github/workflows`, `.claude`.

## Design – verbindlich
Das mitgelieferte **DeepBlue Liquid Glass Kit** ist die verbindliche UI-/UX-Grundlage. Dark-first; Hintergrund ungefähr `#06101E`; primärer Akzent `#2E7CFF`; dunkle blaue Layer, selektives Glass/Blur, deutliche Tiefenstaffelung, stark gerundete Karten, hochwertige Pop-ups/Sheets, klare Datenhierarchie, subtile Glows und flüssige Animationen. Typische Radien aus dem Kit: Card 26, Hero 30, Modal/Floating Nav 34. Web/Desktop und Android verwenden dieselben semantischen Tokens, aber native Plattforminteraktionen. Keine generische Admin-Template-Optik.

## Konfiguration
Alle nicht geheimen Systemparameter liegen zentral in `config/system_config.json`; Secrets werden nur über referenzierte Umgebungsvariablen eingebunden. Feature-Code greift nicht direkt auf `process.env` zu. Konfiguration im Hauptcode ist verboten.

## Zentrale Datenintegrität
- Buchungen dürfen sich für dasselbe Fahrzeug nicht überschneiden; zusätzlich zur Serviceprüfung wird eine PostgreSQL-Invariante/Constraint verwendet.
- Führerscheinberechtigung wird mindestens beim Speichern, Genehmigen und bei der Fahrzeugübergabe erneut geprüft.
- Geldbeträge nie als Float.
- Zeitpunkte UTC speichern; geschäftlich relevante Zeitzone erhalten.
- Audit-Events sind append-only.
- Mobile Schreibvorgänge verwenden Idempotency Keys und Offline-Outbox.

## Deployment und CI/CD
Docker Compose ist die empfohlene Standardinstallation. Zusätzlich systemd-basierte Linux-Installation und Windows-Server-Services mit PowerShell-Installer. GitHub Actions bauen/testen Backend, Web, OCR, Android und Windows Desktop, führen Playwright/Security/Migrationsprüfungen aus und erzeugen Docker Images, APK/AAB, Windows Installer, Checksummen und SBOM. Release-Publishing erfolgt nur mit konfigurierten Secrets und explizitem Release-Workflow.

## Dokumentation
Das Repository enthält eine vollständig versionierte Wiki-Quelle. Dokumentiert werden Installation, Update/Backup/Restore, alle Einstellungen, Rollen/Berechtigungen, jede Oberfläche, Workflows, API, Datenmodell, OCR, Pluginentwicklung, Events, Designsystem, Android/Offline, Fehlerbehebung und Release-/Upgrade-Hinweise.
