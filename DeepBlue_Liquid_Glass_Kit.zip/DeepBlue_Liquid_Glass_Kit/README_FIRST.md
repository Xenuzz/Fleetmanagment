# DeepBlue Liquid Glass Kit

Dieses Paket ist die verbindliche Designgrundlage für alle Apps, die im selben visuellen Stil gebaut oder überarbeitet werden sollen.

## So benutzt du das Paket mit einer anderen KI

1. Lade den kompletten Ordner oder die ZIP hoch.
2. Lade die drei Bilder aus `01_REFERENCE_IMAGES/` als visuelle Referenzen mit hoch.
3. Sage der KI ausdrücklich, dass die Bilder **nur visuelle Referenzen** sind. Text, Beispielwerte, Appname und konkrete Inhalte in den Bildern dürfen **nicht** kopiert werden.
4. Gib anschließend genau einen passenden Prompt aus `03_AI_PROMPTS/` mit.
5. Die Dateien in `02_DESIGN_SYSTEM/` sind verbindlich. `design_tokens.json` und `motion_tokens.json` sind die Single Source of Truth.

## Wichtig

- Primäre Referenz ist `01_DARK_BUDGET_REFERENCE.png`.
- Die hellen Screens dienen nur als zusätzliche Referenz für Rundungen, Abstände, Informationshierarchie und Kartenaufbau.
- Keine Texte, Beispielbeträge, Kontonamen oder Markennamen aus den Bildern übernehmen.
- Keine Screens als starre Kopie nachbauen. Das Designsystem auf die Funktionen der Ziel-App übertragen.
- Dark-First, tiefes Dunkelblau, hochwertiges Liquid Glass, starke Rundungen, weiche Übergänge und morphende Interaktionen.

## Ordner

- `01_REFERENCE_IMAGES/` – ausschließlich visuelle Vorlagen
- `02_DESIGN_SYSTEM/` – komplette Spezifikation und Tokens
- `03_AI_PROMPTS/` – fertige Befehle für verschiedene Aufgaben
