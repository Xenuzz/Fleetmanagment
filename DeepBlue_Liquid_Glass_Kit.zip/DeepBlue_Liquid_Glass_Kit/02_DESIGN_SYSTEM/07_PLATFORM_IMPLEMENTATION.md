# 07 – Platform Implementation

## Android / Jetpack Compose
Empfohlen:
- Material 3 / Material 3 Expressive als semantische Basis
- eigene `DeepBlueTheme` Tokens
- Edge-to-edge
- Predictive Back unterstützen
- Animation: `AnimatedContent`, `updateTransition`, `SharedTransitionLayout` wo stabil
- Blur nur dort einsetzen, wo Plattform/Performance vertretbar; sonst simulierte transluzente Tonfläche

Wichtig: nicht versuchen, iOS-UI 1:1 auf Android zu kopieren. Das visuelle Material bleibt markeneigen, Verhalten folgt Android-Konventionen.

## Flutter
- ThemeExtension für Glass/Depth/Motion Tokens
- `BackdropFilter` sparsam
- `AnimatedContainer`, `TweenAnimationBuilder`, `Hero` für Morphs
- 60 fps auf Mittelklassegeräten als QA-Ziel

## React Native
- Tokens zentral in TypeScript
- Reanimated für Shared/Morph Motion
- BlurView nur auf Floating/Modal Layern
- reduzierte Motion respektieren

## Web
- CSS custom properties aus `design_tokens.json`
- `backdrop-filter` mit Fallback
- `prefers-reduced-motion`
- `color-scheme: dark light`
- 44–48 px interaktive Zielgrößen

## iOS / SwiftUI
- native Materials bevorzugen, wenn passend
- visuelles Branding über Tint, Shape, Spacing und Hierarchie
- systemeigene Gesten und Navigation respektieren
