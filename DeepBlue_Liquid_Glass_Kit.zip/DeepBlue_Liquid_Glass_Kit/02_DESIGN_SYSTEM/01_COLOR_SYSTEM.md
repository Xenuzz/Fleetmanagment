# 01 – Color System

## Core Dark Palette
| Token | Wert | Rolle |
|---|---|---|
| `bg.base` | `#06101E` | App-Hintergrund |
| `bg.elevated` | `#091728` | erhöhte Flächen |
| `bg.deep` | `#030A13` | tiefe Hintergründe |
| `surface.1` | `#0C1C2F` | Standard Card |
| `surface.2` | `#10243A` | hervorgehobene Card |
| `glass.tint` | `rgba(20,45,72,0.58)` | Glass Material |
| `glass.tintStrong` | `rgba(18,42,68,0.76)` | stärkere Modals |
| `stroke.glass` | `rgba(255,255,255,0.10)` | Glass Stroke |
| `stroke.active` | `rgba(87,157,255,0.36)` | aktive Kante |

## Brand Blue
- Primary 700: `#0A52FF`
- Primary 600: `#1769FF`
- Primary 500: `#2E7CFF`
- Primary 400: `#59A0FF`
- Primary Glow: `rgba(46,124,255,0.28)`

## Accent
- Cyan: `#46D7FF`
- Violet: `#9B6CFF`
- Teal: `#3FE2C5`

Akzente nicht gleichzeitig maximal einsetzen. Pro Screen maximal zwei nicht-semantische Akzentfamilien.

## Semantic
- Success: `#43D67B`
- Warning: `#FFB547`
- Error: `#FF5C76`
- Info: `#4EA2FF`

## Text Dark
- Text Primary: `#F4F8FF`
- Text Secondary: `#B6C4D6`
- Text Tertiary: `#7F91A8`
- Disabled: `rgba(182,196,214,0.38)`

## Light Theme
- Base: `#F4F8FF`
- Elevated: `#FFFFFF`
- Glass: `rgba(255,255,255,0.62)`
- Text Primary: `#0B1625`
- Text Secondary: `#5E6D82`
- Primary: `#1769FF`

## Gradients
### Primary Interactive
`linear-gradient(135deg, #0A52FF 0%, #2E7CFF 56%, #59A0FF 100%)`

### Deep Hero
`linear-gradient(145deg, #0C1E39 0%, #0B2A57 54%, #0A52FF 130%)`

### Glass Highlight
`linear-gradient(160deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0.02) 38%, rgba(255,255,255,0.00) 75%)`
