# 06 – Screen Archetypes

## Dashboard
- Top App Bar transparent
- Greeting/Title + Statusaction
- eine Hero Card
- 2–4 KPI Mini-Cards
- horizontale Quick-Action-/Account-Reihe
- ein datenreicher Abschnitt mit Chart oder Statusgruppen
- letzte Aktivitäten
- Floating Nav

## Detail Screen
- großer Titel oder Objektname
- Hero Status Card
- primäre Steuerung direkt sichtbar
- sekundäre Werte als 2-Spalten-Grid
- Verlauf/Chart
- Aktionen am unteren Ende oder persistent, wenn häufig genutzt

## Liste
- Top Title + Search/Filter
- segmentierte Filter
- Card Rows mit führendem Icon und Status
- Swipe Actions nur ergänzend; Hauptaktionen nicht verstecken

## Editor / Einstellungen
- Abschnittsweise Glass Panels
- Controls immer mit erklärender Secondary-Line, wenn Wirkung nicht offensichtlich
- destruktive Aktionen getrennt am Ende

## Dialog / Popup
- kurze Entscheidungen als Popup
- komplexe Bearbeitung als Bottom Sheet
- bestätigungskritische Aktion als Modal

## Empty State
- kein riesiges Illustrationsloch
- kleines Icon in Tone Bubble
- Titel + 1 Satz
- eine klare Primary Action
