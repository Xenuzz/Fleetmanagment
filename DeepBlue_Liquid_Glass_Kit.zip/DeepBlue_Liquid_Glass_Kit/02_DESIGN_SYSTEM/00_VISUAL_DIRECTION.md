# 00 – Visual Direction

## Stilname
**DeepBlue Liquid Glass**

## Charakter
Premium, ruhig, technisch, modern, tief, weich, datenorientiert, hochwertig.

## Verhältnis
- 60 % Deep Navy / Ink UI
- 25 % transluzente Liquid-Glass-Layer
- 10 % kräftiges Electric Blue als aktiver Akzent
- 5 % semantische Akzente / Glow / Statusfarben

## Hintergrund
Standard Dark:
- Basis: `#06101E`
- obere Hintergrundzone: `#071527`
- sekundäre Fläche: `#0B1A2B`
- optionaler radialer Hintergrundakzent: sehr weiche blaue Lichtwolke mit 6–12 % Deckkraft

Kein reines Schwarz als Hauptfläche. Schwarz nur für tiefe Schatten oder OLED-Fallback.

## Glass-Layer
Glass darf niemals nur `opacity` sein. Es besteht aus:
- getönter semitransparenter Fläche
- Background Blur
- innenliegendem Highlight
- sehr feinem Außenstroke
- weichem Schatten
- optionalem lokalem blauen Glow

## Hero-Momente
Nur 1 starker Hero-Moment pro Screen:
- Hauptsaldo
- Primärstatus
- große Gerätekontrolle
- aktive Navigation
- zentrales FAB

## Informationshierarchie
1. Screen-Titel / Kontext
2. Primärwert oder Hauptstatus
3. Hauptaktionen
4. Sekundärdaten
5. Historie / Details / Meta

## Visuelle Verbote
- keine harten 1px grauen Boxen um jede Komponente
- keine 8–12 dp Radien als Default
- keine dichten Schatten mit harter Kante
- kein permanenter Glow um alle Elemente
- kein grelles Cyan als Vollflächen-Hintergrund
- keine volltransparenten Glass-Cards über unruhigem Content ohne Tint
- keine abrupten Dialoge ohne Scale/Fade/Blur-Übergang
