# DeepBlue Liquid Glass Design System

Ein plattformübergreifendes Designsystem für mobile Apps, Dashboards und Tools.

Zielbild: dunkles, hochwertiges Liquid-Glass-Interface mit tiefem Dunkelblau, stark abgerundeten Geometrien, schwebenden Flächen, klarer Informationshierarchie, weichen Layer-Übergängen und präziser Motion.

## Verbindliche Designprinzipien

1. **Dark-first**: Primärthema ist ein tiefes Navy/Ink-Dark-Theme. Light Mode ist sekundär.
2. **Glas nur als Material, nicht als Effekt-Show**: Blur, Transparenz und Highlights werden gezielt für Navigation, Floating Controls, Modals und Hero Cards eingesetzt.
3. **Große Radien**: Karten 24–32 dp, Modals 28–36 dp, Floating Navigation 28–36 dp, Chips 16–24 dp.
4. **Tiefe statt harter Rahmen**: Abgrenzung über Tonwerte, Blur, subtile 1 px Light-Strokes und sehr weiche Schatten.
5. **Dunkelblau ist die Markenfarbe**: elektrisches Blau dient als Interaktionsfarbe; Cyan/Violett nur als sekundäre Akzente.
6. **Motion verbindet Flächen**: Elemente morphen, expandieren und fließen räumlich ineinander statt abrupt zu wechseln.
7. **Clean, aber datenreich**: Informationen werden nicht versteckt, sondern sauber gruppiert und progressiv offengelegt.
8. **Semantische Farben bleiben eindeutig**: Grün = positiv/erfolgreich, Rot = Fehler/negativ, Orange = Warnung, Blau = neutral/primär.
9. **Keine übertriebenen Neon-Glows**: Glow ist subtil und nur an aktivem Fokus, FAB, Selektion oder Hero-Momenten.
10. **Touch-first**: Mindestzielgröße 48 dp; wichtige Aktionen bevorzugt im unteren Daumenbereich.

## Dateien

- `00_VISUAL_DIRECTION.md` – visuelle Richtung und Gestaltungsregeln
- `01_COLOR_SYSTEM.md` – Farbrollen und Verwendungsregeln
- `02_SHAPE_DEPTH_GLASS.md` – Radien, Layer, Blur, Stroke, Schatten
- `03_TYPOGRAPHY.md` – Typografie und Zahlenhierarchie
- `04_COMPONENT_SPECS.md` – Komponenten
- `05_MOTION_SYSTEM.md` – Animationen und Interaktionsmotion
- `06_SCREEN_ARCHETYPES.md` – wiederverwendbare Screen-Muster
- `07_PLATFORM_IMPLEMENTATION.md` – Android / Flutter / React Native / Web / iOS Mapping
- `08_ACCESSIBILITY_QA.md` – Accessibility und visuelle QA
- `design_tokens.json` – maschinenlesbare Tokens
- `motion_tokens.json` – maschinenlesbare Motion-Tokens
- `MASTER_AI_IMPLEMENTATION_PROMPT.md` – universeller Prompt für andere KIs

## Referenzrichtung

Das System orientiert sich an aktuellen, offiziellen Plattformprinzipien für expressive Formen, Motion, Material-Theming und moderne Navigation, ohne eine Plattform 1:1 zu kopieren.
