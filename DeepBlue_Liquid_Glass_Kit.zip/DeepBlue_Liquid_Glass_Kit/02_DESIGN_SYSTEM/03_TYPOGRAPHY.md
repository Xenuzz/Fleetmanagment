# 03 – Typography

## Font Strategy
Android/Web: `Roboto Flex` oder `Inter`.
iOS: System San Francisco.
Keine dekorative Display-Schrift im Kern-UI.

## Scale
| Rolle | Größe | Gewicht | Line Height |
|---|---:|---:|---:|
| Display XL | 40 | 700 | 46 |
| Display | 34 | 700 | 40 |
| Title XL | 28 | 700 | 34 |
| Title | 22 | 650 | 28 |
| Section | 18 | 650 | 24 |
| Body L | 16 | 500 | 23 |
| Body | 15 | 450 | 22 |
| Label | 13 | 600 | 18 |
| Caption | 12 | 500 | 16 |
| Micro | 11 | 550 | 14 |

## Zahlen
Finanzwerte, Messwerte, Prozentwerte:
- tabular/monospaced numerals aktivieren, wenn verfügbar
- große Kennzahlen 30–40 sp
- Währung optisch mit Zahl gruppieren, nicht winzig absetzen

## Regeln
- Maximal 3 klar unterschiedliche Schriftgrößen in einer Card
- Primärwerte nie im gleichen Gewicht wie Hilfetext
- Sekundärtext bevorzugt Tonwert statt nur kleinere Schrift
