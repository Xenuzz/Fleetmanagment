# Sources / Design References

Offizielle Referenzen zur technischen/plattformgerechten Einordnung:

- Android Developers – Material Design 3 in Compose: https://developer.android.com/develop/ui/compose/designsystems/material3
- Android Developers – Predictive Back design: https://developer.android.com/design/ui/mobile/guides/patterns/predictive-back
- Android Developers – Material 3 Expressive design language: https://developer.android.com/design/ui/wear/guides/get-started/design-language
- Android Developers – Levels of expression / Motion & Shape: https://developer.android.com/design/ui/wear/guides/get-started/levels-expression
- Apple Human Interface Guidelines: https://developer.apple.com/design/human-interface-guidelines/

Hinweis: Das Paket nutzt keine Apple Design Resources oder geschützten Vorlagen. Es definiert ein eigenständiges, plattformübergreifendes Designsystem.
