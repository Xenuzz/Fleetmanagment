# 04 – Component Specifications

## 1. Floating Bottom Navigation
- schwebend, 18–24 dp über Safe Area
- Glass Floating Rezept
- Radius 32–36 dp
- aktive Destination erhält eine morphende Blue-Pill
- Icon + Label bei aktivem Item; inaktive Labels dürfen auf kleinen Screens ausgeblendet werden
- Auswahl-Pill bewegt sich mit federnder Translation und leichter Breitenmorphung
- zentraler FAB optional als separate kreisförmige Ebene, visuell mit Nav verzahnt

## 2. FAB
- 58–68 dp
- Primary Gradient
- innenliegender weißer Highlight-Ring 8–12 %
- Schatten + Blue Glow nur im aktiven Zustand
- Press: Scale 0.94; Release: Spring auf 1.0
- Long press: Kontextmenu als radiale/vertikale Glass-Actions

## 3. Cards
Standard:
- Radius 26 dp
- 18–22 dp Innenabstand
- keine harte Outline; Glass Stroke oder Surface-Kontrast

Hero:
- Radius 30 dp
- Hintergrund kann Deep Hero Gradient + Glass Overlay sein
- eine zentrale Kennzahl oder Statusdarstellung

## 4. Buttons
Primary:
- Höhe 52–56 dp
- Radius 18–22 dp
- Primary Gradient
- Icon optional links

Secondary:
- Glass Surface + 1 px Stroke

Tertiary:
- keine Vollfläche, nur Label/Icon mit aktivem Tint

## 5. Chips / Segmented Control
- Höhe 38–44 dp
- Radius 18–22 dp
- aktiv: Blue Pill + heller Text
- inaktiv: Glass oder Tonfläche
- Auswahl animiert Hintergrundposition, nicht kompletter Hard-Swap

## 6. List Rows
- 64–82 dp Höhe je Dichte
- führendes Icon in 38–44 dp Ton-Container
- optionaler Status rechts
- Chevron nur wenn tatsächlich Navigation folgt

## 7. Popups / Context Menus
- Ursprung visuell am Trigger verankern
- 20–28 dp Radius
- Blur 28–34 px
- erscheinen mit Scale 0.94 → 1.0 + Fade + Blur-Interpolation
- Items 48–52 dp hoch
- destruktive Aktion erst im letzten Bereich

## 8. Bottom Sheets
- Radius oben 30–36 dp
- Hintergrund starkes Glass
- Dim-Layer `rgba(0,0,0,0.42)` + Hintergrund leicht defokussieren
- Sheet wächst aus dem unteren Interaktionsbereich
- Drag Handle sehr subtil

## 9. Toast / Command Feedback
- schwebende Mini-Glass-Pill nahe unterer Navigation
- Icon links, Text max. 2 Zeilen
- 1.8–3.0 s Auto-dismiss
- Erfolg grün nur im Icon/Statuspunkt, nicht als komplette grüne Fläche

## 10. Charts
- Linien 2.5–3 px
- Blue-to-Cyan nur für primäre Datenreihe
- Area fill 8–18 %
- Grid sehr schwach
- aktive Punkte mit Glow + 2px Innenring
- Donut-Ringe 8–12 dp dick, mit abgerundeten Enden
