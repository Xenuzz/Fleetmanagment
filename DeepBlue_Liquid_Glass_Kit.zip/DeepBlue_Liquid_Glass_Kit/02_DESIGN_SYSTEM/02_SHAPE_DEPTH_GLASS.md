# 02 – Shape, Depth & Glass

## Corner Radius
| Rolle | Radius |
|---|---:|
| micro/chip | 14 dp |
| input/button | 18 dp |
| compact card | 22 dp |
| standard card | 26 dp |
| hero card | 30 dp |
| modal/bottom sheet | 32 dp |
| floating nav | 34 dp |
| circular FAB | 999 dp |

## Padding
- Screen horizontal: 20 dp compact / 24 dp standard
- Card: 18–22 dp
- Hero card: 22–28 dp
- Row: 14–18 dp vertical
- Section gap: 22–30 dp

## Glass Recipes

### Glass / Standard
- tint: `rgba(20,45,72,0.58)`
- backdrop blur: 22 px
- saturation: 125 %
- stroke: 1 px `rgba(255,255,255,0.10)`
- inner highlight: 1 px `rgba(255,255,255,0.06)`
- shadow: y 10, blur 32, `rgba(0,0,0,0.24)`

### Glass / Floating
- tint: `rgba(17,37,61,0.72)`
- blur: 28 px
- stroke: 1 px `rgba(255,255,255,0.13)`
- shadow: y 14, blur 40, `rgba(0,0,0,0.34)`
- optional active glow: 18–28 px `rgba(46,124,255,0.22)`

### Glass / Modal
- tint: `rgba(10,24,41,0.88)`
- blur: 34 px
- stroke: 1 px `rgba(255,255,255,0.12)`
- radius: 32–36 dp

## Elevation Layers
0. Background
1. Static content card
2. Highlight card / sticky UI
3. Floating nav / contextual control
4. Modal / sheet
5. Toast / command feedback
6. Critical confirmation

Keine mehr als 3 gleichzeitig sichtbar dominanten Tiefenebenen.
