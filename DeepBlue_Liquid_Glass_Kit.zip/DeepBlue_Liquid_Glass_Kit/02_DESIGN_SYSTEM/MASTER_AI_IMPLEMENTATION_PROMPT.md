# MASTER AI IMPLEMENTATION PROMPT – DeepBlue Liquid Glass

Du implementierst oder redesignst eine bestehende App vollständig im Designsystem **DeepBlue Liquid Glass**. Dieses Designsystem ist verbindlich. Funktionalität darf nicht entfernt oder vereinfacht werden, nur um das Design leichter umzusetzen.

## 1. Designziel
Erzeuge eine hochwertige, dunkle, tiefblaue, stark abgerundete, räumlich geschichtete Oberfläche mit gezieltem Liquid-Glass-Material. Die UI soll clean wirken, aber detaillierte Daten und Funktionen klar zugänglich halten. Sie darf nicht wie ein generisches Material-Theme oder eine reine iOS-Kopie aussehen.

## 2. Verbindliche Tokens
Lies und verwende `design_tokens.json` und `motion_tokens.json` als Single Source of Truth. Keine zufälligen Hex-Werte, Radien, Schatten oder Animationszeiten in einzelnen Screens.

## 3. Visuelle Regeln
- Primärer Hintergrund: `#06101E`.
- Standardfläche: `#0C1C2F`.
- Primärblau: `#2E7CFF`, aktive/kräftige Varianten `#1769FF` und `#0A52FF`.
- Text Primary: `#F4F8FF`.
- Standard Card Radius: 26 dp.
- Hero Radius: 30 dp.
- Modals / Bottom Sheets / Floating Nav: 32–36 dp.
- Glass: getönte halbtransparente Fläche + Blur + feiner heller Stroke + weicher Schatten.
- Kein permanenter Neon-Look.
- Semantische Farben nur für Bedeutung verwenden.

## 4. Navigation
Primäre mobile Navigation ist eine schwebende Bottom Navigation mit stark gerundeter Glass-Fläche. Das aktive Ziel besitzt eine morphende blaue Pill. Wechsel müssen mit Shared-Axis/Fade und leichter räumlicher Translation animiert sein. Falls ein zentraler Hauptbefehl existiert, darf ein kreisförmiger FAB mittig oder leicht integriert schweben.

## 5. Popups / Dialoge / Sheets
Popup immer optisch vom auslösenden Element entstehen lassen: Scale 0.94→1, Fade, Blur-Interpolation, 220–280 ms. Komplexe Bearbeitung in Bottom Sheet. Kritische Bestätigung als Modal. Hintergrund dimmen und leicht visuell zurücknehmen.

## 6. Cards und Daten
Hero-Card enthält nur den wichtigsten Screenwert oder Hauptstatus. Sekundäre Daten in klaren Gruppen, Grid oder kompakten Cards. Charts sind ruhig: Primary Blue, schwache Grid-Lines, 2.5–3 px Linien, 8–18 % Area Fill, aktive Punkte mit subtilem Glow.

## 7. Motion
Verwende `motion_tokens.json`.
- Press Feedback ca. 90–120 ms
- State Change ca. 160–220 ms
- Standard Transition ca. 240–320 ms
- Morph 320–420 ms
- Modal 360–480 ms
- natürliche Federbewegung bei Auswahl, FAB und Morphs
- `prefers-reduced-motion` bzw. OS Reduced Motion respektieren

## 8. Accessibility
- Mindest-Touchfläche 48 dp auf Android und vergleichbar plattformgerecht.
- Textkontrast prüfen.
- Status nicht nur farblich darstellen.
- Dynamic Type / Font Scaling darf keine Kernaktionen abschneiden.
- Reduced Motion implementieren.

## 9. Technische Implementierung
Erstelle zentrale Theme-/Token-Dateien. Keine Stylingwerte direkt verstreut im Feature-Code. Komponenten müssen wiederverwendbar sein.

Empfohlene Struktur:

```text
ui/
  theme/
    colors
    typography
    shapes
    spacing
    motion
    glass
  components/
    GlassCard
    FloatingNavigation
    MorphingNavItem
    PrimaryButton
    SecondaryButton
    GlassChip
    GlassPopup
    GlassBottomSheet
    HeroMetricCard
    StatusRow
    ChartContainer
  screens/
  animation/
  accessibility/
```

## 10. Screen-Redesign-Prozess
Für jeden Screen:
1. Bestehende Funktionen inventarisieren.
2. Primäre Nutzeraufgabe identifizieren.
3. Eine Hero-Zone definieren.
4. Sekundärdaten gruppieren.
5. Primary Action sichtbar halten.
6. Glass nur für Layer mit echter Tiefenbedeutung verwenden.
7. Zustände definieren: loading, empty, error, offline, disabled, pressed, selected.
8. Navigation und Rückverhalten plattformgerecht implementieren.
9. Motion definieren.
10. Accessibility und kleine Displays testen.

## 11. Akzeptanzkriterien
Die Implementierung ist erst fertig, wenn:
- alle Screens dieselben zentralen Tokens verwenden,
- Dark Theme tiefblau statt schwarz wirkt,
- große abgerundete Formen konsistent sind,
- Navigation und Popups fließend/morphend reagieren,
- kein Layout bei Font Scaling oder kleinen Screens bricht,
- kein unnötiger Full-Screen-Blur Performance kostet,
- Reduced Motion funktioniert,
- keine bestehende Funktion durch das Redesign verloren geht.

## 12. Ausgabeanforderung an die KI
Liefere nicht nur Mockups. Implementiere produktionsnah: Theme, Komponenten, Screens, Zustände und Motion. Bei bestehendem Projekt zuerst Codebasis analysieren und anschließend schrittweise integrieren, ohne Businesslogik unnötig umzuschreiben.
