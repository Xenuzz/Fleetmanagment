# 05 – Motion System

## Grundsatz
Motion erklärt räumliche Beziehung. Keine zufälligen Animationen.

## Durations
- micro feedback: 90–140 ms
- chip/button state: 160–220 ms
- standard transition: 240–320 ms
- card expand/morph: 320–420 ms
- modal/sheet: 360–480 ms

## Easing
- Standard enter: cubic-bezier(0.16, 1, 0.3, 1)
- Standard exit: cubic-bezier(0.4, 0, 1, 1)
- Morph: cubic-bezier(0.2, 0.9, 0.2, 1)
- Spring expressive: damping 0.78–0.86, moderate stiffness

## Core Motions

### Navigation Morph
1. aktiver Pill-Hintergrund translatiert zum Ziel
2. Breite morpht passend zum Label
3. Icon verschiebt sich 2–4 dp und skaliert 0.96→1.0
4. Content wechselt mit shared-axis slide 12–18 dp + fade

### Card → Detail
- Karte expandiert aus eigener Position
- Radius 26→0/24 je Zielscreen
- Titel/Icon übernehmen Startposition
- Hintergrundlayer blenden versetzt ein
- 320–420 ms

### Popup
- Transform origin = Trigger
- scale 0.94 → 1
- opacity 0 → 1
- blur 8 → 0
- 220–280 ms

### FAB Press
- press scale 0.94 / 90 ms
- release spring
- Glow nimmt kurz +20 % zu

### Success
- kurze Ring-/Check-Draw Animation 320–450 ms
- kein konfettiartiger Effekt als Default

### Reduced Motion
Bei aktivierter Bewegungsreduktion:
- Morphing durch Fade + kurzer Crossfade ersetzen
- keine großen Translationen
- keine parallaxartigen Background-Bewegungen
