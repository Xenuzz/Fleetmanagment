# 08 – Accessibility & QA

## Mindestanforderungen
- Textkontrast WCAG AA anstreben: 4.5:1 normaler Text, 3:1 große Schrift
- Touch Targets mindestens 48 dp Android / ca. 44 pt iOS
- Status nie ausschließlich über Farbe kommunizieren
- Schriftvergrößerung darf keine Kernaktionen abschneiden
- Reduced Motion berücksichtigen
- Dark Mode: keine grauen Texte unter ~60 % wahrgenommener Helligkeit auf sehr dunklen Flächen ohne Kontrastprüfung

## Glass QA
- Text muss unabhängig vom darunterliegenden Content lesbar bleiben
- bei hoher visueller Hintergrundkomplexität Tint erhöhen
- Blur nie als einzige Abgrenzung
- modale Ebenen müssen visuell klar vor Hintergrund liegen

## Performance QA
- keine Full-Screen-Blur-Kaskaden
- maximal 2–3 aktive Blur-Layer gleichzeitig
- Animationen auf echten Mittelklassegeräten testen
- Charts und Scrolling während Animationen profilieren

## Acceptance Checklist
- [ ] Dark Theme entspricht Navy statt Schwarz
- [ ] Primary Blue ist konsistent
- [ ] Standard Cards 26 dp Radius
- [ ] Floating Nav 32–36 dp Radius
- [ ] Modal/Sheet 32–36 dp Radius
- [ ] Keine übermäßigen Glow-Effekte
- [ ] Navigation morpht statt hart umzuschalten
- [ ] Popup Ursprung ist am Trigger verankert
- [ ] Reduced Motion vorhanden
- [ ] Touch Targets >= 48 dp
- [ ] Semantische Farben sind konsistent
- [ ] Alle Screens verwenden zentrale Tokens
