# Regeln für Referenzbilder

Die Bilder in `01_REFERENCE_IMAGES/` sind **nur visuelle Vorlagen**.

## Primäre Referenz
`01_DARK_BUDGET_REFERENCE.png`

Davon übernehmen:
- dunkle tiefblaue Grundstimmung
- stark gerundete Karten
- subtile Border/Strokes
- weiche Layer
- schwebende Bottom Navigation
- blaue aktive Zustände
- kompakte, aber klare Datenhierarchie
- dezente Glows
- hochwertige dunkle Glass-Flächen

## Ergänzende Referenzen
`02_LIGHT_DASHBOARD_REFERENCE.png`
`03_LIGHT_ACCOUNTS_REFERENCE.png`

Davon übernehmen:
- großzügige Rundungen
- klare Card-Hierarchie
- horizontale Karten/Chips
- strukturierte Informationsblöcke
- saubere Abstände
- visuelle Ruhe

## Nicht übernehmen
- Texte
- Namen
- Kontodaten
- Beträge
- Marken
- konkrete Icons, wenn sie semantisch nicht passen
- iOS-spezifische Systemelemente 1:1
- Dynamic Island oder Hardware-Rahmen
