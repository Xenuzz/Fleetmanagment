# Befehl – Design- und Implementierungsprüfung

Prüfe die komplette App gegen das mitgelieferte `DeepBlue Liquid Glass` Designsystem.

Erstelle eine konkrete Abweichungsliste mit Dateipfad, Screen/Komponente, Problem, Sollzustand und Priorität.

Prüfe mindestens:
- Farben und Theme
- Radien
- Abstände
- Typografie
- Glass/Blur-Einsatz
- Schatten und Layering
- Navigation
- Popups, Dialoge und Bottom Sheets
- Pressed/Selected/Disabled States
- Loading/Empty/Error/Offline States
- Animationen und Timing
- Reduced Motion
- Accessibility
- Font Scaling
- kleine Displays
- Performance durch Blur/Schatten
- wiederverwendbare Komponenten
- verstreute Magic Values

Behebe danach alle gefundenen Abweichungen direkt im Projekt.
