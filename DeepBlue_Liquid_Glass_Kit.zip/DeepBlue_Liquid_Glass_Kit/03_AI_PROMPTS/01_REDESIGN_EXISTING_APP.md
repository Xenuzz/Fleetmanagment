# Befehl – bestehende App vollständig redesignen

Analysiere zuerst die gesamte bestehende App und inventarisiere alle Screens, Funktionen, Zustände, Navigation, Dialoge, Listen, Formulare, Widgets, Diagramme und Sonderfälle.

Redesigne anschließend die komplette UI auf Basis des mitgelieferten `DeepBlue Liquid Glass` Designsystems.

Verbindlich:

- bestehende Businesslogik erhalten
- keine Funktion entfernen
- keine Datenmodelle unnötig verändern
- Theme und Design-Tokens zentralisieren
- sämtliche Screens auf dieselbe visuelle Sprache umstellen
- schwebende, stark gerundete Bottom Navigation verwenden, sofern sie zur App-Struktur passt
- aktive Navigation morphend hervorheben
- Dialoge, Popups und Bottom Sheets mit Material-/Glass-Übergängen animieren
- Loading-, Empty-, Error-, Offline-, Disabled-, Pressed- und Selected-Zustände definieren
- Reduced Motion berücksichtigen
- kleine Displays und Font Scaling testen
- keine Texte oder Beispielwerte aus den Referenzbildern übernehmen

Arbeite produktionsnah direkt im Projekt. Erstelle nicht nur Mockups.

Bevor du Code änderst, liefere kurz:
1. Screen-Inventar
2. Komponenten-Inventar
3. geplante Theme-/Token-Struktur
4. Migrationsreihenfolge

Danach implementiere die Änderungen vollständig.
