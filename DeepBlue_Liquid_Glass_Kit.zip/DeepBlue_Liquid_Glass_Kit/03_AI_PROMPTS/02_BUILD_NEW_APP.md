# Befehl – neue App in diesem Design bauen

Baue die neue App vollständig im mitgelieferten `DeepBlue Liquid Glass` Designsystem.

Nutze die Referenzbilder ausschließlich als visuelle Vorlage. Übernimm keine Texte, Beispielwerte oder App-spezifische Inhalte aus den Bildern.

Erstelle zuerst:
- Informationsarchitektur
- Screen-Liste
- Navigationsmodell
- Komponentenstruktur
- Zustandsmodell
- Theme-/Token-Struktur

Implementiere danach die App mit zentralen Design-Tokens und wiederverwendbaren Komponenten.

Pflicht:
- Dark-First
- tiefes Dunkelblau als Grundton
- elektrische Blautöne als primäre Interaktionsfarbe
- große, organisch gerundete Flächen
- gezieltes Liquid Glass statt überall Blur
- visuelle Tiefenstaffelung
- morphende Navigation und Controls
- weiche, physikalisch glaubwürdige Animationen
- hochwertige Bottom Sheets, Dialoge und Popups
- klare Informationshierarchie
- vollständige Accessibility-Zustände
- Reduced Motion
- responsive Layouts

Ergebnis muss produktionsnah sein und nicht wie ein statisches UI-Mockup.
