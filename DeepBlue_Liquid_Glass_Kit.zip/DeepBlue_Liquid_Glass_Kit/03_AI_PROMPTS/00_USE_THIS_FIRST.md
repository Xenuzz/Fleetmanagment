# Basisbefehl – immer zuerst verwenden

Ich habe dir einen Ordner namens `DeepBlue_Liquid_Glass_Kit` und drei Referenzbilder bereitgestellt.

Behandle die Bilder ausschließlich als visuelle Referenzen für Design, Formensprache, Materialwirkung, Abstände, Karten, Navigation, Farbwirkung, Tiefenstaffelung und Animationen. Übernimm **keine** Texte, Beträge, Kontonamen, Appnamen oder Beispielinhalte aus den Bildern.

Lies zuerst vollständig:

1. `README_FIRST.md`
2. alle Dateien in `02_DESIGN_SYSTEM/`
3. besonders `design_tokens.json`
4. besonders `motion_tokens.json`
5. `MASTER_AI_IMPLEMENTATION_PROMPT.md`

Die dunkle Budget-Referenz ist die primäre visuelle Richtung. Die beiden hellen Screens sind nur ergänzende Referenzen.

Das Designsystem ist verbindlich. Nutze zentrale Tokens und wiederverwendbare Komponenten. Keine frei erfundenen Farben, Radien, Schatten, Blur-Werte oder Animationszeiten im Feature-Code.

Funktionalität der Ziel-App darf beim Redesign nicht entfernt oder vereinfacht werden.
