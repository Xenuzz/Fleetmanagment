# Kurze Befehle für Folgeänderungen

## Neue Funktion
`Implementiere diese Funktion vollständig und integriere sie visuell in das vorhandene DeepBlue Liquid Glass Designsystem. Verwende ausschließlich die bestehenden Tokens und Komponenten oder erweitere sie zentral.`

## Screen neu gestalten
`Redesigne diesen Screen vollständig nach DeepBlue Liquid Glass, ohne Funktionalität zu entfernen. Nutze die mitgelieferten Referenzbilder nur als visuelle Orientierung.`

## Popup / Bottom Sheet
`Ersetze diesen Dialog durch ein hochwertiges DeepBlue-Liquid-Glass Popup bzw. Bottom Sheet mit morphendem Übergang vom auslösenden Element, korrektem Backdrop, Fokusführung und Reduced-Motion-Fallback.`

## Navigation
`Überarbeite die Navigation zur schwebenden DeepBlue-Liquid-Glass Navigation. Aktiver Tab als morphende blaue Pill, weiche Zustandsübergänge, korrekte Insets und vollständige Accessibility.`

## Karte / Dashboard
`Überarbeite diese Karten-/Dashboard-Struktur nach dem DeepBlue-Liquid-Glass System: klare Hero-Hierarchie, große Radien, ruhige Layer, präzise Abstände, subtile Glass-Tiefe und keine unnötigen Effekte.`

## Animationen
`Prüfe alle Interaktionen dieses Screens gegen motion_tokens.json und ersetze harte oder inkonsistente Übergänge durch die definierten DeepBlue-Liquid-Glass Motion Patterns.`
