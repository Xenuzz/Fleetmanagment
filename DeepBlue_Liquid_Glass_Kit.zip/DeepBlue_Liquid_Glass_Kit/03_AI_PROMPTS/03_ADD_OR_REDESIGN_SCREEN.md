# Befehl – einzelnen Screen hinzufügen oder redesignen

Erstelle bzw. überarbeite den angeforderten Screen nach dem mitgelieferten `DeepBlue Liquid Glass` Designsystem.

Analysiere vorher:
- Zweck des Screens
- wichtigste Nutzeraktion
- primäre Information
- sekundäre Informationen
- benötigte Interaktionen
- States und Fehlerfälle

Nutze für den Screen eine klare Hero-Zone, gruppierte Sekundärinformationen, starke Rundungen, gezielte Glass-Layer und die zentralen Tokens.

Alle Übergänge zu bestehenden Screens müssen visuell und motion-technisch konsistent sein.

Keine neuen lokalen Hex-Werte, Radien, Schatten oder Animationszeiten erfinden. Nutze ausschließlich die zentralen Tokens bzw. erweitere diese sauber, falls wirklich nötig.
